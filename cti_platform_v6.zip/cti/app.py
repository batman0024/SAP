"""
CTI Platform v5 — Streamlit Dashboard
Fixes from v4:
  - Reset button for multi-study sessions
  - Excel download in sidebar
  - WinError 267 safe temp cleanup (spaces in filenames)
  - PK outputs no longer misclassified as Efficacy
  - Full text (no truncation) in outputs
  - Output class filter in Outputs tab
  - Domain variable breakdown table in ADaM Spec tab
  - Output class / dataset charts for programmers
  - Clearer optional document labels
  - Hyperlinks between outputs and populations
  - SAS code blocks (copyable)
  - Fixed HTML rendering in header (raw HTML bug)
"""
from __future__ import annotations
import hashlib, io, json, os, sys, tempfile, time
from collections import Counter, defaultdict
from pathlib import Path
from typing import List, Optional

import streamlit as st

sys.path.insert(0, str(Path(__file__).parent))

from src.models.schema import ClinicalIntelligenceSchema, OutputType, QCSeverity
from src.services import ExtractionPipeline, PipelineConfig
from src.export import ExportManager

st.set_page_config(page_title="CTI Platform v5", page_icon="⬡",
                   layout="wide", initial_sidebar_state="expanded")

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600&family=IBM+Plex+Sans:wght@300;400;600;700&display=swap');
html,body,[class*="css"]{font-family:'IBM Plex Sans',sans-serif;}
.stApp{background:#0a0e1a;color:#e2e8f0;}
.main .block-container{padding:1.5rem 2rem;max-width:1400px;}
[data-testid="stSidebar"]{background:#0f172a;border-right:1px solid #1e293b;}
[data-testid="stMetricValue"]{color:#06b6d4;font-family:'IBM Plex Mono',monospace;font-size:1.8rem;}
[data-testid="stMetricLabel"]{color:#64748b;font-size:.7rem;text-transform:uppercase;letter-spacing:.05em;}
[data-testid="stMetric"]{background:#0f172a;border:1px solid #1e293b;border-radius:10px;padding:.8rem;}
.stTabs [data-baseweb="tab-list"]{background:#0f172a;border-bottom:1px solid #1e293b;}
.stTabs [data-baseweb="tab"]{color:#64748b;padding:.65rem 1.1rem;font-size:.82rem;}
.stTabs [aria-selected="true"]{color:#06b6d4;border-bottom:2px solid #06b6d4;}
.streamlit-expanderHeader{background:#0f172a;border:1px solid #1e293b;border-radius:8px;color:#e2e8f0;}
.stProgress>div>div{background:linear-gradient(90deg,#06b6d4,#6366f1);}
[data-testid="stFileUploaderDropzone"]{background:#0f172a;border:2px dashed #334155;border-radius:10px;}
.stButton>button{background:linear-gradient(135deg,#06b6d4,#6366f1);color:#fff;border:none;border-radius:8px;font-weight:600;padding:.5rem 1.2rem;}
.stButton>button:hover{opacity:.85;}
.stDownloadButton>button{background:#1e293b;color:#94a3b8;border:1px solid #334155;border-radius:6px;font-size:12px;}
.badge-e{background:#ef444422;color:#ef4444;border:1px solid #ef444433;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600;}
.badge-w{background:#f59e0b22;color:#f59e0b;border:1px solid #f59e0b33;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600;}
.badge-i{background:#06b6d422;color:#06b6d4;border:1px solid #06b6d433;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600;}
.badge-ok{background:#10b98122;color:#10b981;border:1px solid #10b98133;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600;}
.sec-hdr{font-family:'IBM Plex Mono',monospace;font-size:.65rem;font-weight:600;color:#475569;
         text-transform:uppercase;letter-spacing:.1em;margin-bottom:.4rem;
         border-bottom:1px solid #1e293b;padding-bottom:3px;}
.tracked-ok{background:rgba(16,185,129,.08);border:1px solid rgba(16,185,129,.3);
            border-radius:6px;padding:.4rem .8rem;font-size:12px;color:#6ee7b7;margin-bottom:.75rem;}
.annotation-tag{background:#1e1b4b;color:#a5b4fc;border:1px solid #4338ca33;
                padding:2px 7px;border-radius:3px;font-family:monospace;font-size:10px;margin:1px;}
.upload-label{font-size:10px;color:#f59e0b;font-weight:600;text-transform:uppercase;
              letter-spacing:.06em;margin-bottom:2px;padding:2px 6px;
              background:rgba(245,158,11,.1);border-radius:3px;display:inline-block;}
.reset-btn>button{background:#1e293b!important;color:#ef4444!important;border:1px solid #ef444433!important;
                  font-size:11px!important;padding:.3rem .8rem!important;}
.var-row{font-family:'IBM Plex Mono',monospace;font-size:10px;padding:3px 0;border-bottom:1px solid #1e293b11;}
</style>
""", unsafe_allow_html=True)

# ── Session state ─────────────────────────────────────────────────────────────
for k, v in {"schema": None, "error": None, "file_hash": None,
              "html_report": None, "excel_bytes": None}.items():
    if k not in st.session_state:
        st.session_state[k] = v


def _fhash(*files) -> str:
    h = hashlib.md5()
    for f in files:
        if f:
            h.update(f.getvalue()[:8192])
    return h.hexdigest()[:12]


def _conf_badge(s: float) -> str:
    if s >= .88: return f'<span class="badge-ok">✓ {s:.0%}</span>'
    elif s >= .70: return f'<span class="badge-i">~ {s:.0%}</span>'
    elif s >= .55: return f'<span class="badge-w">! {s:.0%}</span>'
    return f'<span class="badge-e">✗ {s:.0%}</span>'


def _rc(score: float) -> str:
    return "#10b981" if score >= .80 else "#f59e0b" if score >= .60 else "#ef4444"


def _safe_tempdir_cleanup(tmp_path: str) -> None:
    """Safe recursive cleanup that handles filenames with spaces/dots (WinError 267)."""
    import shutil
    try:
        shutil.rmtree(tmp_path, ignore_errors=True)
    except Exception:
        pass


# ── Sidebar ───────────────────────────────────────────────────────────────────
def _sidebar():
    with st.sidebar:
        col_logo, col_title = st.columns([1, 4])
        with col_logo:
            st.markdown("### ⬡")
        with col_title:
            st.markdown("""
            <div style="padding-top:4px;">
              <div style="font-weight:700;font-size:13px;color:#f1f5f9;">CTI Platform v5</div>
              <div style="font-size:10px;color:#475569;">SAP Intelligence · Multi-Document</div>
            </div>""", unsafe_allow_html=True)
        st.divider()

        # ── PRIMARY SAP ──
        st.markdown('<div class="sec-hdr">📄 Primary SAP Document <span style="color:#ef4444">*required</span></div>',
                    unsafe_allow_html=True)
        sap_file = st.file_uploader("SAP document (DOCX / RTF / TXT)",
                                    type=["docx", "rtf", "txt"],
                                    key="sap_up", label_visibility="collapsed",
                                    help="Main Statistical Analysis Plan — required to run extraction")

        # ── OPTIONAL DOCS ──
        st.markdown('<div class="sec-hdr" style="margin-top:.9rem;">📎 Optional Documents</div>',
                    unsafe_allow_html=True)

        # Shell document
        st.markdown('<span class="upload-label">🔗 TFL Shell / Mock Shell (DOCX)</span>',
                    unsafe_allow_html=True)
        st.markdown('<div style="font-size:9px;color:#475569;margin-bottom:4px;">'
                    'Annotated mock shell with Table/Listing/Figure structure. '
                    'Adds 55+ outputs from real shell document.</div>',
                    unsafe_allow_html=True)
        shell_file = st.file_uploader("TFL Shell DOCX or RTF",
                                      type=["docx", "rtf"],
                                      key="shell_up", label_visibility="collapsed")

        # ADaM spec
        st.markdown('<span class="upload-label" style="margin-top:6px;display:inline-block;">'
                    '📊 ADaM Variable Specification (XLSX)</span>',
                    unsafe_allow_html=True)
        st.markdown('<div style="font-size:9px;color:#475569;margin-bottom:4px;">'
                    'CDISC ADaM spec Excel (Define-XML source or sponsor spec). '
                    'Improves dataset inference and generates variable-level rules.</div>',
                    unsafe_allow_html=True)
        adam_file = st.file_uploader("ADaM Spec Excel (.xlsx / .xls)",
                                     type=["xlsx", "xls"],
                                     key="adam_up", label_visibility="collapsed")

        # ── PIPELINE OPTIONS ──
        st.markdown('<div class="sec-hdr" style="margin-top:.9rem;">⚙️ Pipeline Options</div>',
                    unsafe_allow_html=True)
        run_qc    = st.checkbox("Run QC Engine", True,
                                help="Run 17 QC checks and compute readiness score")
        run_shell = st.checkbox("Parse Mock Shells", True,
                                help="Extract column structure from shell tables")
        parallel  = st.checkbox("Parallel Extraction", True,
                                help="Run entity extractors concurrently (faster for large SAPs)")
        conf      = st.slider("Confidence Threshold", 0.50, 0.95, 0.65, 0.05,
                              format="%.2f",
                              help="Outputs below this threshold shown with warning badge")

        # ── EXPORT OPTIONS ──
        st.markdown('<div class="sec-hdr" style="margin-top:.9rem;">📤 Export Options</div>',
                    unsafe_allow_html=True)
        exp_json = st.checkbox("Export JSON",  False)
        exp_xl   = st.checkbox("Export Excel", True,
                               help="Multi-sheet Excel: Outputs, Populations, Rules, Visits, QC")
        exp_html = st.checkbox("Export HTML",  True)
        exp_sas  = st.checkbox("Export SAS",   False)

        st.markdown("")
        run_btn  = st.button("⬡ Run Extraction", use_container_width=True,
                             disabled=not bool(sap_file),
                             help="Upload a SAP document first")
        demo_btn = st.button("⚡ Demo SAP", use_container_width=True,
                             help="Run on built-in 150-page mock SAP")

        # ── RESET button ──
        st.markdown("")
        st.markdown('<div class="reset-btn">', unsafe_allow_html=True)
        reset_btn = st.button("🔄 Reset / New Study", use_container_width=True,
                              help="Clear results to run extraction on a different study")
        st.markdown('</div>', unsafe_allow_html=True)

        # ── RESULTS SUMMARY ──
        schema = st.session_state.get("schema")
        if schema:
            meta  = schema.get("study_metadata", {})
            qc    = schema.get("qc_report", {}) or {}
            rs    = qc.get("overall_readiness_score", 0)
            color = _rc(rs)
            st.divider()
            pid   = meta.get("protocol_id", "N/A")
            phase = meta.get("phase", "?")
            ver   = meta.get("sap_version", "")
            st.markdown(f"""
            <div style="font-size:11px;color:#94a3b8;line-height:2;">
              <b style="color:#f1f5f9;">{pid}</b><br>
              Phase {phase}&nbsp;·&nbsp;{"v" + ver if ver else "vN/A"}<br>
              {len(schema.get("outputs_master",[]))} outputs &nbsp;·&nbsp;
              {len(schema.get("populations",[]))} pops<br>
              {len(schema.get("endpoints",[]))} endpoints &nbsp;·&nbsp;
              {len(schema.get("rule_engine_output",[]))} rules
            </div>
            <div style="margin-top:.5rem;padding:7px 10px;background:#0a0e1a;
                        border:1px solid #1e293b;border-left:3px solid {color};border-radius:0 5px 5px 0;">
              <div style="font-size:9px;color:#64748b;text-transform:uppercase;">QC Readiness</div>
              <div style="font-size:1.5rem;font-family:'IBM Plex Mono',monospace;
                          color:{color};font-weight:700;">{rs:.0%}</div>
            </div>""", unsafe_allow_html=True)

            st.divider()
            st.markdown('<div class="sec-hdr">⬇ Downloads</div>', unsafe_allow_html=True)

            # JSON download
            st.download_button(
                "⬇ JSON Schema",
                data=json.dumps(schema, indent=2, default=str),
                file_name=f"cti_{pid}.json",
                mime="application/json",
                use_container_width=True)

            # HTML report download
            html_rpt = st.session_state.get("html_report")
            if html_rpt:
                st.download_button(
                    "⬇ HTML Report",
                    data=html_rpt,
                    file_name=f"cti_report_{pid}.html",
                    mime="text/html",
                    use_container_width=True)

            # Excel download — generate on demand
            excel_bytes = st.session_state.get("excel_bytes")
            if excel_bytes:
                st.download_button(
                    "⬇ Excel Workbook",
                    data=excel_bytes,
                    file_name=f"cti_{pid}.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    use_container_width=True)

    return (sap_file, shell_file, adam_file, run_btn, demo_btn, reset_btn,
            run_qc, run_shell, parallel, conf,
            exp_json, exp_xl, exp_html, exp_sas)


# ── Pipeline runners ──────────────────────────────────────────────────────────
def _run(sap_file, shell_file, adam_file, conf, run_qc, run_shell, parallel,
         exp_json, exp_xl, exp_html, exp_sas):
    key = _fhash(sap_file, shell_file, adam_file)
    if st.session_state.get("file_hash") == key and st.session_state.get("schema"):
        st.info("Using cached result. Click 'Reset / New Study' then re-upload to re-run.")
        return

    progress = st.progress(0.0, text="Starting…")
    status = st.empty()

    def cb(msg, pct):
        progress.progress(min(pct, 1.0), text=msg)
        status.markdown(f"<div style='font-size:11px;color:#64748b;'>{msg}</div>",
                        unsafe_allow_html=True)

    tmp_dir = tempfile.mkdtemp()   # Manual tempdir — avoids WinError 267 on cleanup
    try:
        paths = []
        for uf in [sap_file, shell_file, adam_file]:
            if uf:
                # Sanitise filename: replace spaces with underscores to prevent WinError 267
                safe_name = uf.name.replace(" ", "_")
                p = Path(tmp_dir) / safe_name
                p.write_bytes(uf.getvalue())
                paths.append(p)

        export_dir = Path(tmp_dir) / "exports"
        export_dir.mkdir(exist_ok=True)

        config = PipelineConfig(
            confidence_threshold=conf,
            run_qc=run_qc,
            run_mock_shell=run_shell,
            parallel_extraction=parallel,
            export_json=exp_json,
            export_excel=exp_xl,
            export_html=exp_html,
            export_sas=exp_sas,
            output_dir=export_dir,
            progress_callback=cb,
        )
        pipeline = ExtractionPipeline(config)
        schema_obj = pipeline.run(paths)
        schema_dict = json.loads(schema_obj.model_dump_json())

        # Generate HTML report
        html_content = None
        excel_content = None
        try:
            tmp2 = tempfile.mkdtemp()
            em2 = ExportManager(Path(tmp2))
            html_path = em2.export_html_report(schema_obj)
            html_content = html_path.read_text(encoding="utf-8")
            # Always generate Excel for download regardless of checkbox
            xl_path = em2.export_excel(schema_obj)
            excel_content = xl_path.read_bytes()
            _safe_tempdir_cleanup(tmp2)
        except Exception as exc:
            pass  # non-fatal; downloads just won't be available

        st.session_state["schema"]      = schema_dict
        st.session_state["file_hash"]   = key
        st.session_state["html_report"] = html_content
        st.session_state["excel_bytes"] = excel_content
        st.session_state["error"]       = None
        progress.progress(1.0, text="Complete ✓")
        status.empty()

    except Exception as exc:
        import traceback
        st.session_state["error"] = f"{exc}\n{traceback.format_exc()[-600:]}"
        progress.empty()
        status.empty()
    finally:
        _safe_tempdir_cleanup(tmp_dir)


def _run_demo():
    sap = Path("tests/fixtures/mock_saps/sap_large_150page.docx")
    if not sap.exists():
        candidates = sorted(Path("tests/fixtures/mock_saps").glob("*.docx"))
        sap = candidates[-1] if candidates else None
    if not sap:
        st.error("No demo fixture found.")
        return

    config = PipelineConfig(run_qc=True, run_mock_shell=True, parallel_extraction=True)
    schema_obj = ExtractionPipeline(config).run([sap])
    schema_dict = json.loads(schema_obj.model_dump_json())

    html_content = None
    excel_content = None
    try:
        tmp = tempfile.mkdtemp()
        em = ExportManager(Path(tmp))
        html_path = em.export_html_report(schema_obj)
        html_content = html_path.read_text(encoding="utf-8")
        xl_path = em.export_excel(schema_obj)
        excel_content = xl_path.read_bytes()
        _safe_tempdir_cleanup(tmp)
    except Exception:
        pass

    st.session_state["schema"]      = schema_dict
    st.session_state["html_report"] = html_content
    st.session_state["excel_bytes"] = excel_content
    st.session_state["file_hash"]   = "demo"
    st.session_state["error"]       = None


# ── Render helpers ────────────────────────────────────────────────────────────
def _header(schema):
    if schema:
        meta    = schema.get("study_metadata", {})
        sys_ms  = schema.get("execution_time_ms", 0)
        tracked = schema.get("tracked_changes_stripped", False)
        annots  = schema.get("inline_annotations_count", 0)
        pid     = meta.get("protocol_id", "N/A")
        phase   = meta.get("phase", "?")
        sap_ver = meta.get("sap_version") or ""
        amend   = meta.get("amendment_number") or ""
        nct     = meta.get("nct_number") or "N/A"
        title   = meta.get("study_title") or "Clinical Trial SAP Analysis"
        agencies = ", ".join(meta.get("regulatory_agencies", [])) or "—"

        # Build metadata line without f-string HTML issues
        meta_parts = [
            f'Protocol: <span style="color:#94a3b8;">{pid}</span>',
            f'Phase: <span style="color:#94a3b8;">{phase}</span>',
        ]
        if sap_ver:
            meta_parts.append(f'SAP v<span style="color:#94a3b8;">{sap_ver}</span>')
        if amend:
            meta_parts.append(f'Amend: <span style="color:#94a3b8;">{amend}</span>')
        meta_parts.append(f'NCT: <span style="color:#94a3b8;">{nct}</span>')
        meta_parts.append(f'Agencies: <span style="color:#94a3b8;">{agencies}</span>')
        meta_line = " &nbsp;·&nbsp; ".join(meta_parts)

        tracked_html = ""
        if tracked:
            tracked_html = "<div class='tracked-ok' style='margin-top:.6rem;'>✓ Tracked changes (strikethrough deleted text) stripped from extraction</div>"
        annot_html = ""
        if annots:
            annot_html = f"<div style='margin-top:.4rem;font-size:11px;color:#a5b4fc;'>📎 {annots} inline ADaM variable annotations extracted</div>"
        time_html = f"Extracted in {sys_ms:,} ms" if sys_ms else ""

        st.markdown(f"""
        <div style="background:linear-gradient(135deg,#0f172a,#1e1b4b);border:1px solid #1e293b;
                    border-radius:12px;padding:1.1rem 1.5rem;margin-bottom:1.2rem;">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;">
            <div>
              <div style="font-size:1rem;font-weight:700;color:#f1f5f9;margin-bottom:3px;">
                {title[:120]}</div>
              <div style="font-size:11px;color:#64748b;">{meta_line}</div>
            </div>
            <div style="text-align:right;font-size:10px;color:#475569;">{time_html}</div>
          </div>
          {tracked_html}{annot_html}
        </div>""", unsafe_allow_html=True)
    else:
        st.markdown("""
        <div style="background:linear-gradient(135deg,#0f172a,#1e1b4b);border:1px solid #1e293b;
                    border-radius:12px;padding:2rem;text-align:center;margin-bottom:1.2rem;">
          <div style="font-size:2rem;margin-bottom:.4rem;">⬡</div>
          <div style="font-size:1.2rem;font-weight:700;color:#f1f5f9;margin-bottom:.4rem;">
            Clinical Trial Intelligence Platform v5</div>
          <div style="font-size:12px;color:#64748b;max-width:600px;margin:0 auto;">
            Upload a SAP document (DOCX/RTF/TXT) + optionally a TFL Shell DOCX and/or ADaM Spec Excel.
            Extracts endpoints from structured tables, dynamic populations, tracked changes,
            inline ADaM annotations, SAP versioning, and generates per-output programming rules.
          </div>
        </div>""", unsafe_allow_html=True)


def _metrics(schema):
    qc   = schema.get("qc_report") or {}
    rs   = qc.get("overall_readiness_score", 0)
    color = _rc(rs)
    cols = st.columns(9)
    vals = [
        ("Outputs",     len(schema.get("outputs_master", []))),
        ("Populations", len(schema.get("populations", []))),
        ("Endpoints",   len(schema.get("endpoints", []))),
        ("Rules",       len(schema.get("rule_engine_output", []))),
        ("Visits",      len(schema.get("visit_schedule", []))),
        ("Sections",    len(schema.get("sections", []))),
        ("ADaM Annots", schema.get("inline_annotations_count", 0)),
        ("QC Errors",   qc.get("errors", 0)),
        ("Readiness",   f"{rs:.0%}"),
    ]
    for col, (lbl, val) in zip(cols, vals):
        with col:
            st.metric(lbl, val)


# ── Tab: Outputs ──────────────────────────────────────────────────────────────
def _tab_outputs(schema):
    import pandas as pd

    outs = schema.get("outputs_master", [])
    if not outs:
        st.warning("No outputs extracted. Verify SAP contains 'Table X.X.X:' / 'Listing X.X.X:' entries.")
        return

    # Filters row
    c1, c2, c3, c4 = st.columns([2, 2, 2, 2])
    with c1:
        type_f = st.multiselect("Type", ["Table", "Listing", "Figure"],
                                default=["Table", "Listing", "Figure"], key="tf")
    with c2:
        pops_avail = sorted({(o.get("population") or {}).get("abbreviation", "?")
                             for o in outs if o.get("population")})
        pop_f = st.multiselect("Population", pops_avail, default=pops_avail, key="pf")
    with c3:
        all_classes = sorted({o.get("output_class", "Other") for o in outs})
        cls_f = st.multiselect("Output Class", all_classes, default=all_classes, key="clf")
    with c4:
        conf_f = st.slider("Min Confidence", 0.0, 1.0, 0.0, 0.05, key="cf")

    filtered = [o for o in outs
                if o.get("output_type", "Table") in type_f
                and o.get("output_class", "Other") in cls_f
                and (not pops_avail or (o.get("population") or {}).get("abbreviation", "?") in pop_f)
                and o.get("confidence_score", 0) >= conf_f]

    # Summary bar
    type_counts = Counter(o.get("output_type", "Table") for o in filtered)
    st.caption(
        f"Showing **{len(filtered)}/{len(outs)}** outputs — "
        f"Tables: {type_counts.get('Table', 0)}, "
        f"Listings: {type_counts.get('Listing', 0)}, "
        f"Figures: {type_counts.get('Figure', 0)}"
    )

    # Class breakdown quick chart
    if len(filtered) > 0:
        cls_counts = Counter(o.get("output_class", "Other") for o in filtered)
        with st.expander("📊 Output Class Breakdown", expanded=False):
            chart_df = pd.DataFrame(
                {"Class": list(cls_counts.keys()), "Count": list(cls_counts.values())}
            ).sort_values("Count", ascending=False)
            st.bar_chart(chart_df.set_index("Class"), height=200)

    for o in filtered:
        pop      = (o.get("population") or {}).get("abbreviation", "—")
        pop_flag = (o.get("population") or {}).get("adam_flag_variable", "")
        ds_list  = (o.get("data_specification") or {}).get("input_datasets", [])
        ds_str   = ", ".join(ds_list[:6]) or "—"
        mth_list = (o.get("analysis") or {}).get("methods", [])
        mth_str  = ", ".join(mth_list[:3]) or "—"
        icon     = {"Table": "▦", "Listing": "≡", "Figure": "◈"}.get(
                       o.get("output_type", "Table"), "▦")
        shell_flag = " 🔗" if o.get("from_shell_doc") else ""
        cls_badge  = o.get("output_class", "Other")
        title_full = o.get("title") or ""   # No truncation

        with st.expander(
            f"{icon} **{o.get('output_number','?')}** — {title_full}{shell_flag}"
        ):
            ca, cb, cc = st.columns([3, 2, 1])
            with ca:
                st.markdown(f"""
                <div style="font-size:11px;line-height:2.2;">
                  <b style="color:#94a3b8;">Type:</b>
                  {o.get('output_type','—')}
                  <span style="background:#1e293b;padding:1px 6px;border-radius:3px;
                               font-size:10px;margin-left:4px;">{cls_badge}</span><br>
                  <b style="color:#94a3b8;">Population:</b>
                  {pop}
                  {"<code style='font-size:9px;color:#06b6d4;background:#0a0e1a;padding:1px 4px;border-radius:2px;margin-left:4px;'>"
                   + pop_flag + "='Y'</code>" if pop_flag else ""}<br>
                  <b style="color:#94a3b8;">Methods:</b> {mth_str}<br>
                  <b style="color:#94a3b8;">Datasets:</b>
                  {" ".join(f'<code style="font-size:9px;background:#1e293b;padding:1px 4px;border-radius:3px;">{d}</code>'
                             for d in ds_list[:8]) or "—"}<br>
                  <b style="color:#94a3b8;">Full Title:</b> {title_full}
                </div>""", unsafe_allow_html=True)
            with cb:
                rules = o.get("programming_rules", [])[:6]
                if rules:
                    st.markdown('<div style="font-size:10px;color:#64748b;margin-bottom:4px;">⚡ Programming Rules</div>',
                                unsafe_allow_html=True)
                    for r in rules:
                        sas = r.get("sas_hint", "")
                        rule_txt = r.get("rule", "")
                        st.markdown(
                            f'<div style="font-family:monospace;font-size:10px;'
                            f'background:#0a0e1a;padding:4px 7px;border-radius:4px;'
                            f'border-left:2px solid #f97316;margin-bottom:3px;color:#cbd5e1;">'
                            f'{rule_txt}</div>',
                            unsafe_allow_html=True)
                        if sas:
                            st.code(sas, language="sas")
            with cc:
                st.markdown(_conf_badge(o.get("confidence_score", 0)), unsafe_allow_html=True)
                if o.get("from_shell_doc"):
                    st.markdown('<span style="font-size:9px;color:#6ee7b7;">From Shell Doc</span>',
                                unsafe_allow_html=True)
                st.markdown(
                    f'<div style="font-size:9px;color:#475569;margin-top:4px;">'
                    f'Page ~{(o.get("traceability") or {}).get("page_number","?")}</div>',
                    unsafe_allow_html=True)


# ── Tab: Populations ──────────────────────────────────────────────────────────
def _tab_populations(schema):
    pops = schema.get("populations", [])
    if not pops:
        st.warning("No populations extracted.")
        return

    n_fixed   = sum(1 for p in pops if not p.get("is_dynamic"))
    n_dynamic = sum(1 for p in pops if p.get("is_dynamic"))
    st.caption(f"{n_fixed} fixed canonical populations + {n_dynamic} dynamically extracted")

    # Summary table
    import pandas as pd
    tbl_rows = []
    for p in pops:
        tbl_rows.append({
            "Abbrev":     p.get("abbreviation", ""),
            "Label":      p.get("label", ""),
            "Flag Var":   p.get("adam_flag_variable", ""),
            "Dataset":    p.get("adam_dataset", "ADSL"),
            "Derivation": p.get("derivation_rule", ""),
            "Confidence": f"{p.get('confidence', 0):.0%}",
            "Dynamic":    "✓" if p.get("is_dynamic") else "",
        })
    st.dataframe(pd.DataFrame(tbl_rows), use_container_width=True, hide_index=True)
    st.markdown("")

    for pop in pops:
        dyn_tag = " 🏷️ DYNAMIC" if pop.get("is_dynamic") else ""
        with st.expander(f"👥 **{pop.get('abbreviation')}** — {pop.get('label')}{dyn_tag}"):
            ca, cb = st.columns([3, 1])
            with ca:
                flag = pop.get("adam_flag_variable", "N/A")
                deriv = pop.get("derivation_rule", "N/A")
                st.markdown(f"""
                <div style="font-size:11px;line-height:2.4;">
                  <b style="color:#94a3b8;">ADaM Flag:</b>
                  <code style="background:#0a0e1a;padding:2px 8px;border-radius:3px;color:#06b6d4;">
                    {flag} = 'Y'
                  </code><br>
                  <b style="color:#94a3b8;">Dataset:</b> {pop.get("adam_dataset","ADSL")}<br>
                  <b style="color:#94a3b8;">Derivation:</b>
                  <code style="background:#0a0e1a;padding:2px 6px;border-radius:3px;
                               color:#10b981;font-size:10px;">{deriv}</code>
                </div>""", unsafe_allow_html=True)
                st.code(f"where {flag} = 'Y';  /* {pop.get('label','')} */", language="sas")
                if pop.get("formal_definition"):
                    st.markdown(
                        f'<div style="background:#0a0e1a;border-left:3px solid #ec4899;'
                        f'border-radius:0 5px 5px 0;padding:6px 10px;margin-top:6px;'
                        f'font-size:10px;color:#94a3b8;font-style:italic;">'
                        f'{pop["formal_definition"][:400]}</div>',
                        unsafe_allow_html=True)
            with cb:
                st.markdown(_conf_badge(pop.get("confidence", 0)), unsafe_allow_html=True)


# ── Tab: Endpoints ────────────────────────────────────────────────────────────
def _tab_endpoints(schema):
    eps = schema.get("endpoints", [])
    if not eps:
        st.warning(
            "No endpoints extracted. Check SAP has an objective/endpoint section "
            "or a 2-column 'Primary Objective | Primary Endpoint' table.")
        return

    from_tbl = sum(1 for e in eps if e.get("from_table"))
    st.caption(f"{from_tbl} from structured tables (high accuracy), "
               f"{len(eps) - from_tbl} from prose — {len(eps)} total")

    cls_colors = {
        "Primary": "#ec4899", "Key Secondary": "#f97316",
        "Secondary": "#06b6d4", "Exploratory": "#8b5cf6",
        "Safety": "#ef4444", "PK": "#f59e0b", "PD": "#10b981",
    }

    # Group by classification
    from collections import defaultdict
    grouped = defaultdict(list)
    order   = ["Primary", "Key Secondary", "Secondary", "PK", "PD", "Safety", "Exploratory"]
    for ep in eps:
        grouped[ep.get("classification", "Secondary")].append(ep)

    for cls in order + [c for c in grouped if c not in order]:
        cls_eps = grouped.get(cls, [])
        if not cls_eps:
            continue
        color = cls_colors.get(cls, "#94a3b8")
        st.markdown(
            f'<div style="font-size:11px;font-weight:700;color:{color};'
            f'margin:12px 0 6px;border-left:3px solid {color};padding-left:8px;">'
            f'{cls} Endpoints ({len(cls_eps)})</div>',
            unsafe_allow_html=True)

        for ep in cls_eps:
            src = "📊 Table" if ep.get("from_table") else "📄 Prose"
            desc_full = ep.get("description", "")  # No truncation
            with st.expander(f"🎯 {src} | {desc_full[:90]}"):
                st.markdown(
                    f'<div style="font-size:11px;color:#cbd5e1;line-height:1.7;">'
                    f'<b>Full description:</b><br>{desc_full}</div>',
                    unsafe_allow_html=True)
                if ep.get("timepoints"):
                    st.markdown(
                        f'<div style="font-size:10px;color:#6ee7b7;margin-top:6px;">'
                        f'⏱ Timepoints: {", ".join(ep["timepoints"][:6])}</div>',
                        unsafe_allow_html=True)
                if ep.get("adam_variables"):
                    st.markdown(
                        f'<div style="font-size:10px;color:#a5b4fc;margin-top:4px;">'
                        f'ADaM variables: '
                        f'{", ".join(ep["adam_variables"][:8])}</div>',
                        unsafe_allow_html=True)
                st.markdown(_conf_badge(ep.get("confidence", 0)), unsafe_allow_html=True)


# ── Tab: Rules ────────────────────────────────────────────────────────────────
def _tab_rules(schema):
    rules = schema.get("rule_engine_output", [])
    if not rules:
        st.warning("No programming rules extracted.")
        return

    rt_all = sorted({r.get("rule_type", "") for r in rules})
    sel    = st.multiselect("Filter by Rule Type", rt_all, default=rt_all, key="rt_sel")
    ds_all = sorted({d for r in rules for d in r.get("applies_to_datasets", [])})
    ds_sel = st.multiselect("Filter by Dataset", ["All"] + ds_all,
                            default=["All"], key="ds_sel")

    filtered = [r for r in rules if r.get("rule_type", "") in sel]
    if "All" not in ds_sel and ds_sel:
        filtered = [r for r in filtered
                    if any(d in ds_sel for d in r.get("applies_to_datasets", []))]

    st.caption(f"{len(filtered)} rules")

    colors = {
        "baseline_definition": "#8b5cf6", "date_imputation": "#f97316",
        "censoring": "#ef4444", "filter": "#06b6d4", "derivation": "#10b981",
        "flag": "#6366f1", "LOCF": "#ec4899", "BOCF": "#f59e0b",
        "inline_annotation": "#a5b4fc", "study_day": "#94a3b8",
        "pk_rule": "#fbbf24", "visit_window": "#22d3ee",
    }

    for r in filtered:
        rt     = r.get("rule_type", "")
        color  = colors.get(rt, "#94a3b8")
        snippet = r.get("rule_text_verbatim", "")[:70]
        vars_s = ", ".join(r.get("applies_to_variables", [])[:6]) or "N/A"
        ds_s   = ", ".join(r.get("applies_to_datasets", [])[:5]) or "N/A"

        with st.expander(f"[{rt}] {snippet}…"):
            ca, cb = st.columns([3, 1])
            with ca:
                st.markdown(
                    f'<div style="font-size:11px;color:#94a3b8;font-style:italic;'
                    f'margin-bottom:6px;">{r.get("rule_text_verbatim","")}</div>',
                    unsafe_allow_html=True)
                if r.get("pseudocode"):
                    st.code(r["pseudocode"], language="sas")
                st.markdown(
                    f'<div style="font-size:10px;color:#64748b;margin-top:4px;">'
                    f'Variables: <span style="color:{color};">{vars_s}</span>'
                    f' &nbsp;·&nbsp; Datasets: {ds_s}</div>',
                    unsafe_allow_html=True)
            with cb:
                st.markdown(_conf_badge(r.get("confidence", 0)), unsafe_allow_html=True)


# ── Tab: Visits ───────────────────────────────────────────────────────────────
def _tab_visits(schema):
    import pandas as pd
    visits = schema.get("visit_schedule", [])
    if not visits:
        st.info("No visit schedule extracted.")
        return
    rows = [{
        "Label":    v.get("visit_label", ""),
        "Type":     v.get("visit_type", ""),
        "Nominal":  v.get("nominal_day", "—"),
        "Window":   (f"-{v['window_pre_days']}/+{v['window_post_days']}"
                     if v.get("window_pre_days") is not None else "—"),
        "AVISIT":   v.get("adam_visit_value", ""),
        "AVISITN":  v.get("adam_visitnum", ""),
        "Analysis": "✓" if v.get("analysis_visit_flag") else "",
        "Primary":  "⭐" if v.get("primary_timepoint") else "",
        "Conf":     f"{v.get('confidence', 0):.2f}",
    } for v in visits]
    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)


# ── Tab: QC Report ────────────────────────────────────────────────────────────
def _tab_qc(schema):
    import pandas as pd
    qc = schema.get("qc_report")
    if not qc:
        st.warning("QC not run.")
        return

    rs    = qc.get("overall_readiness_score", 0)
    color = _rc(rs)

    # Readiness gauge + metrics
    c1, c2, c3, c4, c5, c6 = st.columns(6)
    with c1:
        st.markdown(f"""
        <div style="background:#0f172a;border:2px solid {color};border-radius:8px;
                    padding:10px;text-align:center;">
          <div style="font-size:1.6rem;font-family:'IBM Plex Mono',monospace;
                      color:{color};font-weight:700;">{rs:.0%}</div>
          <div style="font-size:9px;color:#64748b;text-transform:uppercase;">Readiness</div>
        </div>""", unsafe_allow_html=True)
    for col, val, lbl in [
        (c2, f"{qc.get('completeness_pct', 0):.0f}%", "Completeness"),
        (c3, qc.get("errors", 0), "Errors"),
        (c4, qc.get("warnings", 0), "Warnings"),
        (c5, qc.get("infos", 0), "Info"),
        (c6, qc.get("low_confidence_count", 0), "Low Conf"),
    ]:
        with col:
            st.metric(lbl, val)

    st.markdown("")

    issues  = qc.get("issues", [])
    sev_f   = st.multiselect("Severity", ["ERROR", "WARNING", "INFO"],
                              default=["ERROR", "WARNING"], key="qc_sev")
    cat_all = sorted({i.get("category", "") for i in issues})
    cat_f   = st.multiselect("Category", ["All"] + cat_all, default=["All"], key="qc_cat")

    shown = [i for i in issues if i.get("severity", "") in sev_f]
    if "All" not in cat_f and cat_f:
        shown = [i for i in shown if i.get("category", "") in cat_f]

    sev_map = {"ERROR": "badge-e", "WARNING": "badge-w", "INFO": "badge-i"}
    for i in shown:
        sev = i.get("severity", "INFO")
        bd  = sev_map.get(sev, "badge-i")
        fix = i.get("suggested_fix", "")
        st.markdown(f"""
        <div style="background:#0f172a;border:1px solid #1e293b;border-radius:6px;
                    padding:.5rem .75rem;margin-bottom:.4rem;font-size:11px;">
          <span class="{bd}">{sev}</span>
          <span style="color:#64748b;margin-left:.5rem;font-size:10px;">
            {i.get("category","")}</span>
          <span style="color:#cbd5e1;margin-left:.75rem;">{i.get("message","")}</span>
          {"<div style='font-size:10px;color:#475569;margin-top:2px;'>💡 " + fix + "</div>" if fix else ""}
        </div>""", unsafe_allow_html=True)

    if not shown:
        st.success("✓ No issues at selected severity/category.")

    # Category breakdown
    if issues:
        with st.expander("📊 Issues by Category"):
            cat_counts = Counter(i.get("category", "Other") for i in issues)
            df = pd.DataFrame({"Category": list(cat_counts.keys()),
                               "Count": list(cat_counts.values())}).sort_values("Count", ascending=False)
            st.bar_chart(df.set_index("Category"), height=200)


# ── Tab: ADaM Spec ────────────────────────────────────────────────────────────
def _tab_adam(schema):
    import pandas as pd
    from collections import defaultdict

    # 1. Dataset usage summary
    ds_map = defaultdict(lambda: {"outputs": [], "pops": set(), "rules": 0})
    for o in schema.get("outputs_master", []):
        ds_spec  = o.get("data_specification") or {}
        pop_abbr = (o.get("population") or {}).get("abbreviation", "")
        for ds in (ds_spec.get("input_datasets") or []):
            ds_map[ds]["outputs"].append(o.get("output_number", "?"))
            if pop_abbr:
                ds_map[ds]["pops"].add(pop_abbr)
    for r in schema.get("rule_engine_output", []):
        for ds in r.get("applies_to_datasets", []):
            ds_map[ds]["rules"] += 1

    icons = {
        "ADSL": "👤", "ADAE": "⚠️", "ADLB": "🧪", "ADEFF": "🎯",
        "ADTTE": "⏱️", "ADPK": "💊", "ADVS": "❤️", "ADQS": "📋",
        "ADCM": "💉", "ADEX": "📊", "ADPC": "🔬", "ADPP": "📈",
        "ADRS": "🏥", "ADIE": "🔬", "ADEG": "💓", "ADNCA": "⚗️",
    }

    st.markdown(f"**{len(ds_map)} ADaM datasets** referenced across "
                f"{len(schema.get('outputs_master',[]))} outputs")

    # Dataset usage bar chart
    if ds_map:
        df_usage = pd.DataFrame([
            {"Dataset": ds, "Outputs": len(info["outputs"]), "Rules": info["rules"]}
            for ds, info in sorted(ds_map.items(), key=lambda x: -len(x[1]["outputs"]))
        ])
        with st.expander("📊 Dataset Usage Chart", expanded=True):
            st.bar_chart(df_usage.set_index("Dataset")[["Outputs", "Rules"]], height=220)

    # Per-dataset detail with variable breakdown
    for ds_name, info in sorted(ds_map.items(), key=lambda x: -len(x[1]["outputs"])):
        icon = icons.get(ds_name, "🗃️")
        with st.expander(
            f"{icon} **{ds_name}** — {len(info['outputs'])} outputs, "
            f"{info['rules']} rules, pops: {', '.join(sorted(info['pops'])) or '—'}"
        ):
            ca, cb = st.columns([3, 1])
            with ca:
                if info["outputs"]:
                    nums = sorted(info["outputs"])[:20]
                    html = " ".join(
                        f'<code style="font-size:10px;background:#1e293b;'
                        f'padding:1px 4px;border-radius:3px;">{n}</code>'
                        for n in nums)
                    more = f" +{len(info['outputs'])-20} more" if len(info["outputs"]) > 20 else ""
                    st.markdown(
                        f'<div style="font-size:11px;margin-bottom:.4rem;">'
                        f'Outputs: {html}{more}</div>',
                        unsafe_allow_html=True)
            with cb:
                if info["pops"]:
                    st.markdown(
                        f'<div style="font-size:11px;color:#94a3b8;">'
                        f'Populations:<br>{"<br>".join(sorted(info["pops"]))}</div>',
                        unsafe_allow_html=True)

            # Variable-level breakdown from rules
            ds_rules = [r for r in schema.get("rule_engine_output", [])
                        if ds_name in r.get("applies_to_datasets", [])]
            if ds_rules:
                st.markdown(
                    '<div style="font-size:10px;color:#64748b;margin-top:6px;">'
                    'Variables referenced by rules:</div>',
                    unsafe_allow_html=True)
                var_set = sorted({v for r in ds_rules
                                  for v in r.get("applies_to_variables", [])})
                html_vars = " ".join(
                    f'<code style="font-size:9px;background:#0f172a;'
                    f'color:#a5b4fc;padding:1px 5px;border-radius:3px;'
                    f'border:1px solid #4338ca33;">{v}</code>'
                    for v in var_set)
                st.markdown(html_vars, unsafe_allow_html=True)

            # Programming rules for this dataset
            if ds_rules:
                with st.expander(f"  ⚡ {len(ds_rules)} Programming Rules for {ds_name}"):
                    for r in ds_rules[:10]:
                        rt = r.get("rule_type", "")
                        st.markdown(
                            f'<div style="font-family:monospace;font-size:10px;'
                            f'background:#0a0e1a;padding:4px 8px;border-radius:4px;'
                            f'border-left:2px solid #06b6d4;margin-bottom:3px;'
                            f'color:#cbd5e1;">[{rt}] {r.get("rule_text_verbatim","")[:80]}</div>',
                            unsafe_allow_html=True)
                        if r.get("pseudocode"):
                            st.code(r["pseudocode"], language="sas")

    # ADaM spec registry (if ADaM Excel was uploaded)
    adam_reg = schema.get("adam_spec_registry")
    if adam_reg and adam_reg.get("datasets"):
        st.divider()
        st.markdown("### 📊 ADaM Spec Excel — Variable Registry")
        st.caption(
            f"Loaded from: {adam_reg.get('file_name','unknown')} — "
            f"{len(adam_reg.get('datasets',{}))} datasets, "
            f"{sum(len(v) for v in adam_reg.get('datasets',{}).values())} variables")

        for ds_name, ds_spec in sorted(adam_reg.get("datasets", {}).items()):
            variables = ds_spec if isinstance(ds_spec, list) else (
                ds_spec.get("variables", []) if isinstance(ds_spec, dict) else [])
            if not variables:
                continue
            with st.expander(f"🗃️ **{ds_name}** — {len(variables)} variables"):
                rows = []
                for var in variables[:50]:
                    if isinstance(var, dict):
                        rows.append({
                            "Variable": var.get("variable", ""),
                            "Label":    var.get("label", "")[:50],
                            "Type":     var.get("type", ""),
                            "Origin":   var.get("origin", ""),
                            "Core":     var.get("core", ""),
                            "Derivation": (var.get("derivation_text", "") or "")[:60],
                        })
                if rows:
                    st.dataframe(pd.DataFrame(rows),
                                 use_container_width=True, hide_index=True)
                if len(variables) > 50:
                    st.caption(f"Showing 50/{len(variables)} variables")


# ── Tab: Structure & TOC ──────────────────────────────────────────────────────
def _tab_structure(schema):
    import pandas as pd
    secs = schema.get("sections", [])
    n_app  = len([s for s in secs if s.get("is_appendix")])
    n_main = len(secs) - n_app
    st.caption(f"{n_main} main sections · {n_app} appendix sections")

    df = pd.DataFrame([{
        "ID":    s.get("section_id", ""),
        "Lv":    s.get("level", 0),
        "Title": s.get("title", "")[:90],
        "Page":  s.get("page_start", ""),
        "App":   "✓ " + (s.get("appendix_label") or "") if s.get("is_appendix") else "",
        "ADaM":  len(s.get("adam_annotations", [])),
    } for s in secs])

    st.dataframe(df, use_container_width=True, hide_index=True, height=450)

    cr = schema.get("cross_refs", {})
    if cr:
        with st.expander(f"Cross-References ({len(cr)})"):
            st.dataframe(
                pd.DataFrame([{"Number": k, "Section": v}
                              for k, v in list(cr.items())[:50]]),
                use_container_width=True, hide_index=True)


# ── Charts / Analytics tab ────────────────────────────────────────────────────
def _tab_analytics(schema):
    import pandas as pd

    outs = schema.get("outputs_master", [])
    if not outs:
        st.info("No outputs to analyse.")
        return

    c1, c2 = st.columns(2)

    with c1:
        st.markdown("**Output Type Distribution**")
        tc = Counter(o.get("output_type", "Table") for o in outs)
        st.bar_chart(pd.DataFrame({"Count": tc}).T, height=180)

        st.markdown("**Output Class Distribution**")
        cc = Counter(o.get("output_class", "Other") for o in outs)
        df_cc = pd.DataFrame({"Class": list(cc.keys()), "Count": list(cc.values())}
                             ).sort_values("Count", ascending=False)
        st.bar_chart(df_cc.set_index("Class"), height=220)

    with c2:
        st.markdown("**Population Coverage**")
        pc = Counter(
            (o.get("population") or {}).get("abbreviation", "None") for o in outs)
        df_pc = pd.DataFrame({"Population": list(pc.keys()), "Outputs": list(pc.values())}
                             ).sort_values("Outputs", ascending=False)
        st.bar_chart(df_pc.set_index("Population"), height=180)

        st.markdown("**Confidence Distribution**")
        bins = {"<55%": 0, "55-70%": 0, "70-88%": 0, "≥88%": 0}
        for o in outs:
            s = o.get("confidence_score", 0)
            if s < .55:   bins["<55%"] += 1
            elif s < .70: bins["55-70%"] += 1
            elif s < .88: bins["70-88%"] += 1
            else:          bins["≥88%"] += 1
        st.bar_chart(pd.DataFrame({"Outputs": bins}).T, height=180)

    # Dataset × Population heatmap
    st.markdown("**Dataset × Population Matrix**")
    ds_pop: dict = defaultdict(lambda: defaultdict(int))
    pops_seen: set = set()
    for o in outs:
        ds_list  = (o.get("data_specification") or {}).get("input_datasets", [])
        pop_abbr = (o.get("population") or {}).get("abbreviation", "None")
        pops_seen.add(pop_abbr)
        for ds in ds_list[:4]:
            ds_pop[ds][pop_abbr] += 1

    if ds_pop:
        all_pops = sorted(pops_seen)
        matrix   = {ds: [counts.get(p, 0) for p in all_pops]
                    for ds, counts in sorted(ds_pop.items())}
        df_mat   = pd.DataFrame(matrix, index=all_pops).T
        st.dataframe(df_mat, use_container_width=True)


# ── Welcome features grid ─────────────────────────────────────────────────────
def _welcome():
    features = [
        ("📄", "Large SAPs", "O(n) XML parsing, parallel extraction. Handles 277-page shell docs."),
        ("✂️", "Tracked Changes", "Strikethrough (w:del) stripped. Only accepted text extracted."),
        ("📊", "Table Endpoints", "Primary/Secondary 2-column objective-endpoint tables parsed directly."),
        ("🔗", "Multi-Document", "SAP + TFL Shell + ADaM Spec Excel combined for higher accuracy."),
        ("🏷️", "Dynamic Populations", "DLT, All Enrolled, Immunogenicity — no fixed-list assumption."),
        ("📎", "ADaM Annotations", "Inline ADSL.SAFFL='Y' green-text annotations extracted as rules."),
        ("📋", "SAP Versioning", "Version, Amendment extracted from document header."),
        ("🗂️", "Table Rules", "Censoring rule tables (Table 5-1 style) parsed row-by-row."),
        ("📈", "Analytics", "Output class, confidence, dataset × population charts."),
        ("✓",  "QC Engine", "17 checks targeting >80% readiness on real-world SAPs."),
    ]
    cols = st.columns(5)
    for i, (icon, title, desc) in enumerate(features):
        with cols[i % 5]:
            st.markdown(f"""
            <div style="background:#0f172a;border:1px solid #1e293b;border-radius:10px;
                        padding:1rem;margin-bottom:.75rem;min-height:130px;">
              <div style="font-size:1.4rem;margin-bottom:.3rem;">{icon}</div>
              <div style="font-size:11px;font-weight:700;color:#f1f5f9;margin-bottom:.25rem;">
                {title}</div>
              <div style="font-size:10px;color:#64748b;">{desc}</div>
            </div>""", unsafe_allow_html=True)


# ── Main ──────────────────────────────────────────────────────────────────────
def main():
    (sap_file, shell_file, adam_file, run_btn, demo_btn, reset_btn,
     run_qc, run_shell, parallel, conf,
     exp_json, exp_xl, exp_html, exp_sas) = _sidebar()

    # Reset
    if reset_btn:
        for k in ("schema", "error", "file_hash", "html_report", "excel_bytes"):
            st.session_state[k] = None
        st.rerun()

    # Run extraction
    if run_btn and sap_file:
        _run(sap_file, shell_file, adam_file, conf, run_qc, run_shell, parallel,
             exp_json, exp_xl, exp_html, exp_sas)
        st.rerun()

    # Demo
    if demo_btn:
        with st.spinner("Running demo pipeline on built-in 150-page SAP…"):
            try:
                _run_demo()
            except Exception as exc:
                import traceback
                st.session_state["error"] = f"{exc}\n{traceback.format_exc()[-600:]}"
        st.rerun()

    # Error display
    if st.session_state.get("error"):
        st.error(f"Pipeline error:\n\n{st.session_state['error']}")
        if st.button("Clear Error"):
            st.session_state["error"] = None
            st.rerun()

    schema = st.session_state.get("schema")
    _header(schema)

    if schema is None:
        _welcome()
        return

    _metrics(schema)
    st.markdown("")

    tabs = st.tabs([
        "📊 Outputs",
        "📑 Structure & TOC",
        "👥 Populations",
        "🎯 Endpoints",
        "⚡ Rules",
        "📅 Visits",
        "✓ QC Report",
        "🗃️ ADaM Spec",
        "📈 Analytics",
    ])

    with tabs[0]: _tab_outputs(schema)
    with tabs[1]: _tab_structure(schema)
    with tabs[2]: _tab_populations(schema)
    with tabs[3]: _tab_endpoints(schema)
    with tabs[4]: _tab_rules(schema)
    with tabs[5]: _tab_visits(schema)
    with tabs[6]: _tab_qc(schema)
    with tabs[7]: _tab_adam(schema)
    with tabs[8]: _tab_analytics(schema)


if __name__ == "__main__":
    main()
