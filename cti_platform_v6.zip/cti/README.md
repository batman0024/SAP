# Clinical Trial Intelligence Platform v5

Semantic extraction of clinical trial programming specifications from SAP documents.
Pattern-based, domain-aware, CDISC-compliant. No LLM required.

## v5 Changes (7 bugs fixed + dashboard improvements)

| Fix | Description |
|-----|-------------|
| 🐛 WinError 267 | ADaM Excel upload no longer crashes on Windows filenames with spaces |
| 🐛 PK→Efficacy | PK outputs no longer misclassified as Efficacy |
| 🐛 Raw HTML | Study header renders correctly (no escaped HTML tags) |
| 🐛 Excel DL | Excel workbook download always available in sidebar |
| 🐛 Reset | "Reset / New Study" button clears session for a different study |
| 🐛 Truncation | Full titles and descriptions shown (not cut at 75 chars) |
| 🐛 Pop default | _match_pop() no longer assigns ITT to PK/biomarker outputs |
| ✨ Analytics | New tab: output class/type/population/confidence charts + dataset matrix |
| ✨ Class filter | 4th filter column in Outputs tab for Output Class |
| ✨ ADaM table | Variable registry table shown when ADaM Spec Excel uploaded |
| ✨ SAS blocks | st.code(language="sas") for all pseudocode — copyable |
| ✨ Pop table | Population summary table before expanders |
| ✨ QC categories | QC issues filterable by Category as well as Severity |

## Quick Start

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Upload

1. **Primary SAP** (required) — DOCX, RTF, or TXT
2. **TFL Shell / Mock Shell** (optional DOCX) — adds 40–100+ outputs from shell structure
3. **ADaM Variable Spec** (optional XLSX) — improves dataset inference, adds variable tables

## Programmatic Use

```python
from src.services import ExtractionPipeline, PipelineConfig
from pathlib import Path

schema = ExtractionPipeline(PipelineConfig(run_qc=True)).run([
    Path("MY_SAP.docx"),
    Path("TFL_Shell.docx"),   # optional
    Path("ADaM_Spec.xlsx"),   # optional
])
print(f"{len(schema.outputs_master)} outputs, readiness: {schema.qc_report.overall_readiness_score:.0%}")
```

## Extensibility

All pattern lists are in `src/utils/normalization.py` — extend without touching business logic:

```python
from src.utils.normalization import OUTPUT_CLASS_HINTS, POPULATION_NORMALIZATION
OUTPUT_CLASS_HINTS["Ophthalmology"] = ["IOP", "BCVA", "intraocular pressure"]
POPULATION_NORMALIZATION[r"\bOLE\b"] = ("OLE Population", "OLE", 7)
```

## Documentation

Open `docs/full_documentation.html` in a browser for the full technical reference.
