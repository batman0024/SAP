"""CTI v4 Pipeline Service — parallel extraction, multi-doc, progress callbacks."""
from __future__ import annotations
import time, hashlib, json
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from src.models.schema import ClinicalIntelligenceSchema, DocumentMetadata
from src.parsers import parse_document, ParsedDocument, ExcelParser
from src.adam_spec import ADaMSpecExcelParser
from src.entity_extraction import (
    StudyMetadataExtractor, PopulationExtractor, EndpointExtractor,
    VisitScheduleExtractor, OutputExtractor, SAPVersionExtractor,
)
from src.rule_engine import RuleEngine
from src.mock_shell import MockShellParser
from src.qc_engine import QCEngine
from src.export import ExportManager
from src.utils import get_logger, STUDY_DAY_PATTERNS, clean_text, truncate
logger = get_logger(__name__)

# Inline timing extractor — avoids a new file dependency
import re as _re_timing

_TIMING_PATS = [
    (r"[Dd]ay\s+1\s*[=:]\s*(?:first\s+(?:dose|dosing)|date\s+of\s+(?:first|initial))",
     "study_day_anchor", "Study Day 1 = first dose date",
     ["ADY","TRTSDT"], "ADY = ADT - TRTSDT + 1; /* if ADT >= TRTSDT */ ADY = ADT - TRTSDT; /* pre-dose */"),
    (r"ADY\s*=\s*ADT\s*[-\u2013]\s*TRTSDT",
     "ady_formula", "ADY derivation: ADY = ADT - TRTSDT [+1]",
     ["ADY","TRTSDT","ADT"], "if ADT >= TRTSDT then ADY = ADT - TRTSDT + 1; else ADY = ADT - TRTSDT;"),
    (r"(?:treatment.emergent|TEAE|treatment\s+emergent).{0,100}(?:on\s+or\s+after\s+first\s+dose|first\s+dose|TRTSDT)",
     "teae_window", "TEAE window: onset on/after first dose",
     ["TRTEMFL","ASTDT","TRTSDT","LDRELD"],
     "if ASTDT >= TRTSDT then TRTEMFL = \'Y\'; /* onset after first dose */"),
    (r"(\d+)\s*(?:calendar\s+)?days?\s+after\s+(?:the\s+)?last\s+(?:dose|administration|treatment)",
     "days_after_last_dose", "N days after last dose of study drug",
     ["LDRELD","ADT","TRTEDTM"],
     "/* End of observation window: LDRELD + N; used for TEAE, SAE, safety follow-up */"),
    (r"follow.?up\s+(?:period|window|phase|visit).{0,80}(?:\d+\s*days?|\d+\s*weeks?|\d+\s*months?)",
     "followup_definition", "Follow-up period length definition",
     ["ADT","LDRELD","FUENDT"], "FUENDT = LDRELD + N_DAYS;"),
    (r"on.treatment\s+(?:period|phase|window).{0,100}(?:first\s+dose|TRTSDT|Day\s*1)",
     "on_treatment_period", "On-treatment period: Day 1 through last dose/EOT",
     ["TRTSDT","TRTEDTM","ONTRTFL","ADT"],
     "if TRTSDT <= ADT <= TRTEDTM then ONTRTFL = \'Y\';"),
    (r"washout\s+(?:period|phase).{0,100}(\d+).{0,20}(?:days?|weeks?|half.?lives?)",
     "washout_definition", "Washout period after last dose",
     ["ADT","LDRELD"], "/* N days/half-lives washout from last dose */"),
    (r"(?:ADY|study\s+day)\s*=\s*ADT\s*-\s*TRTSDT",
     "ady_formula", "ADY calculation from ADT and TRTSDT",
     ["ADY","ADT","TRTSDT"], "ADY = (ADT >= TRTSDT) ? ADT-TRTSDT+1 : ADT-TRTSDT;"),
    (r"LDRELD|last\s+dose\s+(?:relative\s+end\s+date|date).{0,60}(?:ADSL|EX\s+domain|exposure)",
     "ldreld_derivation", "LDRELD: last dose date derivation from EX domain",
     ["LDRELD","EXENDTC","ADSL"], "LDRELD = max(EXSTDTC) where EXDOSE > 0; /* from EX domain, stored in ADSL */"),
]


class _TimingExtractor:
    """Extract study day, TEAE window, follow-up, and washout definitions."""

    def extract(self, document) -> list:
        results = []
        seen = set()
        for section in document.sections:
            text = section.get_text()
            if not text:
                continue
            for pat, category, description, adam_vars, pseudocode in _TIMING_PATS:
                try:
                    for m in _re_timing.finditer(pat, text, _re_timing.IGNORECASE | _re_timing.DOTALL):
                        verbatim = truncate(clean_text(m.group(0)), 250)
                        key = f"{category}:{verbatim[:50]}"
                        if key in seen:
                            continue
                        seen.add(key)
                        from src.models.schema import TimingDefinition
                        results.append(TimingDefinition(
                            category=category,
                            description=description,
                            sas_pseudocode=pseudocode,
                            adam_variables=adam_vars,
                            source_section=section.section_id,
                            confidence=0.88,
                        ))
                except Exception:
                    pass
        return results


class PipelineConfig:
    def __init__(
        self,
        confidence_threshold: float = 0.65,
        run_qc: bool = True,
        run_mock_shell: bool = True,
        export_json: bool = False,
        export_excel: bool = False,
        export_html: bool = False,
        export_sas: bool = False,
        output_dir: Optional[Path] = None,
        parallel_extraction: bool = True,
        progress_callback: Optional[Callable[[str, float], None]] = None,
    ) -> None:
        self.confidence_threshold = confidence_threshold
        self.run_qc = run_qc
        self.run_mock_shell = run_mock_shell
        self.export_json = export_json
        self.export_excel = export_excel
        self.export_html = export_html
        self.export_sas = export_sas
        self.output_dir = output_dir or Path("./exports")
        self.parallel_extraction = parallel_extraction
        self.progress_callback = progress_callback or (lambda m, p: None)


class ExtractionPipeline:
    def __init__(self, config: Optional[PipelineConfig] = None) -> None:
        self.config = config or PipelineConfig()
        self.rule_engine = RuleEngine(self.config.confidence_threshold)
        self.qc_engine = QCEngine(self.config.confidence_threshold)
        self.mock_shell_parser = MockShellParser()
        self.export_manager = ExportManager(self.config.output_dir)
        self._cb = self.config.progress_callback

    def run(self, file_paths: List[Path]) -> ClinicalIntelligenceSchema:
        t0 = time.time()
        logger.info("CTI v4 Pipeline: %d files", len(file_paths))
        self._cb("Initialising", 0.0)
        schema = ClinicalIntelligenceSchema()

        # ── 1. Parse all documents ─────────────────────────────────────────────
        self._cb("Parsing documents", 0.05)
        parsed_docs: List[ParsedDocument] = []
        sap_doc: Optional[ParsedDocument] = None
        shell_docs: List[ParsedDocument] = []
        adam_excel_path: Optional[Path] = None

        for path in file_paths:
            if not path.exists():
                logger.warning("Not found: %s", path)
                continue
            suffix = path.suffix.lower()
            try:
                if suffix in (".xlsx", ".xls"):
                    adam_excel_path = path          # FIX: was never assigned; pass path to ADaMSpecExcelParser
                    schema.documents.append(DocumentMetadata(
                        file_name=path.name, file_type=suffix.lstrip("."),
                        file_size_bytes=path.stat().st_size, role="ADaM_Template",
                    ))
                    continue
                doc = parse_document(path)
                role = self._detect_role(path.name)
                schema.documents.append(DocumentMetadata(
                    file_name=path.name, file_type=suffix.lstrip("."),
                    file_size_bytes=path.stat().st_size, role=role,
                ))
                parsed_docs.append(doc)
                if role == "Shell":
                    shell_docs.append(doc)
                elif sap_doc is None:
                    sap_doc = doc
                    logger.info("Primary SAP: %s — %d secs, %d tbls, tracked_changes=%s, annots=%d, ver=%s",
                                doc.file_name, len(doc.sections), len(doc.tables),
                                doc.tracked_changes_stripped, len(doc.all_adam_annotations),
                                doc.sap_version)
            except Exception as exc:
                logger.error("Parse failed %s: %s", path.name, exc)

        if not parsed_docs:
            logger.error("No documents parsed")
            return schema

        primary = sap_doc or parsed_docs[0]
        schema.tracked_changes_stripped = primary.tracked_changes_stripped
        schema.inline_annotations_count = len(primary.all_adam_annotations)

        # ── 2. Entity extraction (parallel) ────────────────────────────────────
        self._cb("Extracting entities (parallel)", 0.15)
        if self.config.parallel_extraction:
            self._extract_parallel(schema, primary)
        else:
            self._extract_sequential(schema, primary)

        # ── 2.5 Study Timing (TEAE, ADY, follow-up, study day) ───────────────────
        self._cb("Extracting timing definitions", 0.50)
        try:
            schema.timing_definitions = _TimingExtractor().extract(primary)
            logger.info("  Timing definitions: %d", len(schema.timing_definitions))
        except Exception as exc:
            logger.warning("Timing extraction failed: %s", exc)
            if not hasattr(schema, 'timing_definitions'):
                schema.timing_definitions = []

        # ── 3. Outputs ─────────────────────────────────────────────────────────
        self._cb("Extracting outputs (TLFs)", 0.55)
        schema.outputs_master = OutputExtractor().extract(
            primary, schema.populations, schema.endpoints
        )
        # Also extract from shell doc if provided
        if shell_docs:
            shell_outs = OutputExtractor().extract(
                shell_docs[0], schema.populations, schema.endpoints
            )
            seen_nums = {o.output_number for o in schema.outputs_master}
            for so in shell_outs:
                if so.output_number not in seen_nums:
                    so.from_shell_doc = True
                    schema.outputs_master.append(so)
            schema.outputs_master.sort(key=lambda o: (o.output_type.value, o.output_number or ""))

        logger.info("Outputs: %d total (%d from shell)", len(schema.outputs_master),
                    sum(1 for o in schema.outputs_master if o.from_shell_doc))

        # ── 4. Mock shells ─────────────────────────────────────────────────────
        if self.config.run_mock_shell:
            self._cb("Parsing mock shells", 0.65)
            shell_src = shell_docs[0] if shell_docs else primary
            self._attach_shells(schema, shell_src)

        # ── 5. ADaM Excel integration ──────────────────────────────────────────
        if adam_excel_path:
            self._cb("Integrating ADaM Excel", 0.70)
            self._integrate_adam_excel(schema, adam_excel_path)

        # ── 6. Sections + TOC ─────────────────────────────────────────────────
        schema.sections = [
            {"section_id": s.section_id, "title": s.title, "level": s.level,
             "parent_id": s.parent_id, "page_start": s.page_start,
             "is_appendix": s.is_appendix, "appendix_label": s.appendix_label,
             "adam_annotations": s.adam_annotations[:5]}
            for s in primary.sections
        ]
        schema.toc_map = primary.toc_map
        schema.cross_refs = primary.cross_refs
        schema.appendix_sections = primary.appendix_sections
        schema.has_study_schema_diagram = primary.has_study_schema_diagram

        # ── 7. QC ──────────────────────────────────────────────────────────────
        if self.config.run_qc:
            self._cb("Running QC engine", 0.82)
            schema.qc_report = self.qc_engine.run(schema)

        # ── 8. Exports ─────────────────────────────────────────────────────────
        self._cb("Exporting", 0.92)
        if self.config.export_json:
            self.export_manager.export_json(schema)
        if self.config.export_excel:
            self.export_manager.export_excel(schema)
        if self.config.export_html:
            self.export_manager.export_html_report(schema)
        if self.config.export_sas:
            self.export_manager.export_sas_metadata(schema)

        elapsed = int((time.time() - t0) * 1000)
        schema.execution_time_ms = elapsed
        self._cb("Complete", 1.0)
        logger.info("Pipeline complete: %d ms", elapsed)
        return schema

    def _extract_parallel(self, schema, primary):
        jobs = {
            "study_meta":  lambda: StudyMetadataExtractor().extract(primary),
            "sap_versions":lambda: SAPVersionExtractor().extract(primary),
            "populations": lambda: PopulationExtractor().extract(primary),
            "endpoints":   lambda: EndpointExtractor().extract(primary),
            "visits":      lambda: VisitScheduleExtractor().extract(primary),
            "rules":       lambda: self.rule_engine.extract_all(primary),
        }
        results: Dict[str, Any] = {}
        with ThreadPoolExecutor(max_workers=4) as pool:
            futs = {pool.submit(fn): name for name, fn in jobs.items()}
            for fut in as_completed(futs):
                name = futs[fut]
                try:
                    results[name] = fut.result()
                    logger.info("  [parallel] %s done", name)
                except Exception as exc:
                    logger.error("  [parallel] %s FAILED: %s", name, exc)
                    results[name] = None
        schema.study_metadata = results.get("study_meta") or schema.study_metadata
        schema.sap_versions = results.get("sap_versions") or []
        schema.populations = results.get("populations") or []
        schema.endpoints = results.get("endpoints") or []
        schema.visit_schedule = results.get("visits") or []
        schema.rule_engine_output = results.get("rules") or []
        logger.info("  Parallel complete: pops=%d eps=%d rules=%d",
                    len(schema.populations), len(schema.endpoints), len(schema.rule_engine_output))

    def _extract_sequential(self, schema, primary):
        schema.study_metadata = StudyMetadataExtractor().extract(primary)
        schema.sap_versions = SAPVersionExtractor().extract(primary)
        schema.populations = PopulationExtractor().extract(primary)
        schema.endpoints = EndpointExtractor().extract(primary)
        schema.visit_schedule = VisitScheduleExtractor().extract(primary)
        schema.rule_engine_output = self.rule_engine.extract_all(primary)

    def _attach_shells(self, schema, shell_doc):
        tbl_idx = 0
        for out in schema.outputs_master:
            if out.mock_shell is not None: continue
            if tbl_idx < len(shell_doc.tables):
                shell = self.mock_shell_parser.parse_for_output(
                    shell_doc.tables[tbl_idx], f"{out.output_id}_shell"
                )
                if shell: out.mock_shell = shell
                tbl_idx += 1

    def _integrate_adam_excel(self, schema, adam_excel_path: "Path"):
        """Parse ADaM spec Excel and attach registry to schema."""
        try:
            registry = ADaMSpecExcelParser().parse(adam_excel_path)
            schema.adam_spec_registry = registry
            # Use ContextualDatasetResolver with registry to improve dataset inference
            from src.utils.classification import ContextualDatasetResolver
            resolver = ContextualDatasetResolver()
            for out in schema.outputs_master:
                improved_ds = resolver.resolve(out, registry)
                if improved_ds and out.data_specification:
                    out.data_specification.input_datasets = improved_ds
            logger.info("ADaM spec integrated: %d datasets", len(registry.datasets))
        except Exception as exc:
            logger.error("ADaM spec integration failed: %s", exc)

    @staticmethod
    def _detect_role(filename: str) -> str:
        lower = filename.lower()
        if "shell" in lower: return "Shell"
        if "adam" in lower or "adm" in lower: return "ADaM_Template"
        if "sdtm" in lower: return "SDTM"
        return "SAP"

    @staticmethod
    def _hash_file(path: Path) -> str:
        h = hashlib.sha256()
        with path.open("rb") as f:
            for chunk in iter(lambda: f.read(65536), b""): h.update(chunk)
        return h.hexdigest()
