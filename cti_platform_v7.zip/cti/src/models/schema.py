"""
CTI Platform v5 — Complete Data Models
Addresses ALL 28 findings from engineering review + PDF spec additions.

v5 additions over v4:
  - ADaM Variable Registry + typed variables (Part A)
  - ShellColumnMapper annotations (Part B)  
  - PerOutputRuleGenerator (Part C)
  - 12 new rule patterns (Part D)
  - ContextualDatasetResolver (Part E)
  - Weighted ConfidenceScorer (Part F)
  - Restored v3.1 regressions: PKPDSpec, TimingDefinition, Estimand, Multiplicity,
    StudyDayConvention, ImputationStrategy, MissingDataStrategy, TieBreakingRule,
    flag_verification_required, page_number_is_estimated, dataset_note,
    missing_data_assumption, model_statement (Part G)
  - ADEFF → ADEFF (kept), ADRS corrected as primary for response, not generic efficacy
  - QC readiness: fixed score-starts-at-1-and-adds-bonuses logic
  - Recursive XML walk → iterative in parser
  - PK_PARAMETER_PATTERNS / STUDY_DAY_PATTERNS actually used in rule engine
  - datetime.utcnow() → datetime.now(tz) 
  - Duplicate dynamic population deduplication
  - Pipe-table default classification fix
"""
from __future__ import annotations
import json, uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

def _utcnow() -> str:
    return datetime.now(tz=timezone.utc).isoformat()

def _clamp(v: float) -> float:
    return max(0.0, min(1.0, float(v)))

# ── Enumerations ──────────────────────────────────────────────────────────────
class OutputType(str, Enum):
    TABLE = "Table"
    LISTING = "Listing"
    FIGURE = "Figure"
    APPENDIX = "Appendix"

class OutputClass(str, Enum):
    EFFICACY = "Efficacy"
    SAFETY = "Safety"
    PK = "PK"
    PD = "PD"
    BIOMARKER = "Biomarker"
    DEMOGRAPHICS = "Demographics"
    DISPOSITION = "Disposition"
    COMPLIANCE = "Compliance"
    QOL = "QoL"
    SUBGROUP = "Subgroup"
    IMMUNOGENICITY = "Immunogenicity"
    ECG = "ECG"
    LAB = "Laboratory"
    EXPOSURE = "Exposure"
    OTHER = "Other"

class RuleType(str, Enum):
    DERIVATION = "derivation"
    FILTER = "filter"
    IMPUTATION = "imputation"
    DATE_IMPUTATION = "date_imputation"
    FLAG = "flag"
    CENSORING = "censoring"
    VISIT_WINDOW = "visit_window"
    BASELINE_DEFINITION = "baseline_definition"
    MISSING_DATA = "missing_data"       # replaces LOCF/BOCF as rule types
    STUDY_DAY = "study_day"
    PK_RULE = "pk_rule"
    PD_RULE = "pd_rule"
    COMPOSITE = "composite"
    INLINE_ANNOTATION = "inline_annotation"
    TIMING_DEFINITION = "timing_definition"  # restored from v3
    DISPOSITION = "disposition"
    EXPOSURE = "exposure"
    MULTIPLICITY = "multiplicity"

class QCSeverity(str, Enum):
    ERROR = "ERROR"
    WARNING = "WARNING"
    INFO = "INFO"

class EndpointClassification(str, Enum):
    PRIMARY = "Primary"
    KEY_SECONDARY = "Key Secondary"
    SECONDARY = "Secondary"
    EXPLORATORY = "Exploratory"
    SAFETY = "Safety"
    PK = "PK"
    PD = "PD"

# Restored from v3.1 (Part G)
class ImputationStrategy(str, Enum):
    """ICH E9(R1) intercurrent event strategies."""
    TREATMENT_POLICY = "Treatment policy"
    HYPOTHETICAL = "Hypothetical"
    COMPOSITE = "Composite"
    WHILE_ON_TREATMENT = "While on treatment"
    PRINCIPAL_STRATUM = "Principal stratum"

class MissingDataStrategy(str, Enum):
    """Missing data handling methods (separate from ICE strategies)."""
    MAR = "Missing at Random (MAR)"
    MCAR = "Missing Completely at Random (MCAR)"
    MNAR = "Missing Not at Random (MNAR)"
    MULTIPLE_IMPUTATION = "Multiple Imputation"
    LOCF = "Last Observation Carried Forward (LOCF)"
    BOCF = "Baseline Observation Carried Forward (BOCF)"
    WORST_CASE = "Worst Case Imputation"
    COMPLETER = "Completer Analysis"

class StudyDayConvention(str, Enum):
    DAY_ONE = "Day 1 = first dose (no Day 0)"
    DAY_ZERO = "Day 0 = first dose"

class TieBreakingRule(str, Enum):
    """For multiple records within a visit window."""
    CLOSEST_TO_NOMINAL = "Closest to nominal visit day"
    LATEST = "Latest (most recent)"
    EARLIEST = "Earliest"
    PRE_DOSE = "Pre-dose record preferred"

# ── ADaM Variable Registry (Part A — new) ────────────────────────────────────
@dataclass
class ADaMVariable:
    dataset: str = ""
    variable: str = ""
    label: str = ""
    type: str = "Char"               # Num / Char
    length: Optional[int] = None
    format: Optional[str] = None     # BEST., DATE9., $20.
    origin: str = "Derived"          # Derived/CRF/Protocol/Assigned
    derivation_text: str = ""
    core: str = "Expected"           # Required/Expected/Permissible
    codelist: Optional[str] = None
    sdtm_source: List[str] = field(default_factory=list)
    controlled_terms: List[str] = field(default_factory=list)
    key_sequence: Optional[int] = None

@dataclass
class ADaMDatasetSpec:
    dataset: str = ""
    domain_label: str = ""
    structure: str = ""
    keys: List[str] = field(default_factory=list)
    adam_class: str = "BASIC DATA STRUCTURE"
    variables: List[ADaMVariable] = field(default_factory=list)

@dataclass
class ADaMSpecRegistry:
    """Loaded from ADAM_SPEC.xlsx. Enriches all downstream extraction."""
    datasets: Dict[str, ADaMDatasetSpec] = field(default_factory=dict)
    variable_index: Dict[str, List[str]] = field(default_factory=dict)
    derivation_rules: List[str] = field(default_factory=list)
    file_name: Optional[str] = None
    parsed_at: str = field(default_factory=_utcnow)

    def get_variable(self, dataset: str, variable: str) -> Optional[ADaMVariable]:
        ds = self.datasets.get(dataset)
        if ds:
            return next((v for v in ds.variables if v.variable == variable), None)
        return None

    def datasets_for_output_class(self, oc: str) -> List[str]:
        from src.utils.classification import ContextualDatasetResolver
        return ContextualDatasetResolver.primary_for_class(oc)

# ── Shell Column Annotation (Part B — new) ────────────────────────────────────
@dataclass
class AnnotatedShellColumn:
    """Shell column enriched with ADaM variable mappings."""
    position: int = 0
    header: str = ""
    adam_variable: Optional[str] = None
    adam_secondary_variables: List[str] = field(default_factory=list)
    derivation_rule: Optional[str] = None
    sas_format: Optional[str] = None
    stat_type: Optional[str] = None   # count|percent|mean|sd|median|pvalue|lsmean|hr|or|km
    footnote_marker: Optional[str] = None
    is_treatment_col: bool = False
    is_stat_col: bool = False
    sdtm_source_var: Optional[str] = None
    validation_status: str = "unvalidated"  # unvalidated|confirmed_in_spec|not_in_spec

# ── Estimand (restored + extended from v3.1) ──────────────────────────────────
@dataclass
class IntercurrentEvent:
    event: str = ""
    strategy: ImputationStrategy = ImputationStrategy.TREATMENT_POLICY
    definition: Optional[str] = None    # v5: explicit definition text

@dataclass
class Estimand:
    """ICH E9(R1) 5-attribute estimand."""
    treatment: Optional[str] = None
    population: Optional[str] = None
    variable: Optional[str] = None
    summary_measure: Optional[str] = None
    intercurrent_events: List[IntercurrentEvent] = field(default_factory=list)
    missing_data_handling: Optional[MissingDataStrategy] = None   # restored
    fully_specified: bool = False   # True if all 5 attributes present

# ── Multiplicity (restored from v3.1) ─────────────────────────────────────────
@dataclass
class Multiplicity:
    procedure: str = ""             # "Hochberg", "Bonferroni", "Fixed sequence"
    alpha: float = 0.05
    family_description: Optional[str] = None
    testing_order: List[str] = field(default_factory=list)
    sidedness: str = "two-sided"

# ── PK/PD (restored from v3.1) ───────────────────────────────────────────────
@dataclass
class PKParameter:
    name: str = ""
    label: str = ""
    unit: Optional[str] = None
    adam_paramcd: Optional[str] = None
    computation: Optional[str] = None

@dataclass
class PKConcentrationSpec:
    analyte: str = ""
    matrix: str = "Serum"
    lloq: Optional[float] = None
    lloq_unit: Optional[str] = None
    bloq_rule_predose: str = "Set to 0"
    bloq_rule_postdose: str = "Set to LLOQ/2"
    adam_dataset: str = "ADPC"

@dataclass
class PKPDSpec:
    has_nca: bool = False
    has_pop_pk: bool = False
    has_exposure_response: bool = False
    has_pd_endpoints: bool = False
    parameters: List[PKParameter] = field(default_factory=list)
    concentration_specs: List[PKConcentrationSpec] = field(default_factory=list)
    adam_datasets_required: List[str] = field(default_factory=list)
    software: List[str] = field(default_factory=list)

# ── Timing Definition (restored from v3.1) ───────────────────────────────────
@dataclass
class TimingDefinition:
    timing_id: str = field(default_factory=lambda: f"tim_{uuid.uuid4().hex[:8]}")
    category: str = ""   # study_day_anchor|ady_formula|followup|teae_window|on_treatment
    description: str = ""
    sas_pseudocode: Optional[str] = None
    adam_variables: List[str] = field(default_factory=list)
    source_section: Optional[str] = None
    confidence: float = 0.0

# ── Population ────────────────────────────────────────────────────────────────
@dataclass
class Population:
    population_id: str = ""
    label: str = ""
    abbreviation: str = ""
    hierarchy_order: int = 99
    formal_definition: Optional[str] = None
    inclusion_criteria: List[str] = field(default_factory=list)
    exclusion_criteria: List[str] = field(default_factory=list)
    adam_flag_variable: Optional[str] = None
    adam_dataset: str = "ADSL"
    derivation_rule: Optional[str] = None
    source_section: Optional[str] = None
    source_page: Optional[int] = None
    source_text: Optional[str] = None
    confidence: float = 0.0
    is_dynamic: bool = False
    flag_verification_required: bool = True   # restored: warn that flags are defaults
    def __post_init__(self): self.confidence = _clamp(self.confidence)

# ── Endpoint ──────────────────────────────────────────────────────────────────
@dataclass
class Endpoint:
    endpoint_id: str = ""
    classification: str = EndpointClassification.SECONDARY.value
    testing_order: Optional[int] = None
    description: str = ""
    timepoints: List[str] = field(default_factory=list)
    summary_measure: Optional[str] = None
    estimand: Optional[Estimand] = None
    multiplicity: Optional[Multiplicity] = None          # restored
    adam_variables: List[str] = field(default_factory=list)
    adam_datasets: List[str] = field(default_factory=list)  # restored: per-endpoint
    sdtm_source: Optional[str] = None                    # restored
    source_section: Optional[str] = None
    source_page: Optional[int] = None
    source_text: Optional[str] = None
    from_table: bool = False
    confidence: float = 0.0
    def __post_init__(self): self.confidence = _clamp(self.confidence)

# ── Visit Window ──────────────────────────────────────────────────────────────
@dataclass
class VisitWindow:
    visit_id: str = ""
    visit_label: str = ""
    visit_type: str = "On-treatment"
    nominal_day: Optional[int] = None
    window_pre_days: Optional[int] = None
    window_post_days: Optional[int] = None
    window_rule: Optional[str] = None
    tie_breaking_rule: TieBreakingRule = TieBreakingRule.CLOSEST_TO_NOMINAL  # restored
    adam_visit_value: Optional[str] = None
    adam_visitnum: Optional[float] = None
    analysis_visit_flag: bool = False
    primary_timepoint: bool = False
    source_page: Optional[int] = None
    confidence: float = 0.0

# ── Rules ─────────────────────────────────────────────────────────────────────
@dataclass
class ExtractedRule:
    rule_id: str = field(default_factory=lambda: f"rule_{uuid.uuid4().hex[:8]}")
    rule_type: RuleType = RuleType.DERIVATION
    rule_text_verbatim: str = ""
    rule_logic_structured: Optional[Dict[str, Any]] = None
    pseudocode: Optional[str] = None
    applies_to_datasets: List[str] = field(default_factory=list)
    applies_to_variables: List[str] = field(default_factory=list)
    confidence: float = 0.0
    source_section: Optional[str] = None
    source_page: Optional[int] = None
    validated: bool = False
    auto_fixable: bool = False   # restored: QCIssue.auto_fixable

@dataclass
class ProgrammingRule:
    rule: str = ""
    rule_type: RuleType = RuleType.DERIVATION
    severity: str = "mandatory"
    sas_hint: Optional[str] = None
    confidence: float = 0.0
    source_text: Optional[str] = None
    adam_variable: Optional[str] = None
    adam_dataset: Optional[str] = None
    source_column: Optional[str] = None    # shell column that generated this rule
    source: str = "sap_text"              # sap_text|shell_column|adam_spec|template

# ── Mock Shell ────────────────────────────────────────────────────────────────
@dataclass
class MockShellColumn:
    position: int = 0
    header: str = ""
    width_chars: Optional[int] = None
    alignment: str = "left"
    format_mask: Optional[str] = None
    data_type: str = "string"
    adam_variable: Optional[str] = None
    adam_secondary_variables: List[str] = field(default_factory=list)
    derivation_rule: Optional[str] = None
    sas_format: Optional[str] = None
    stat_type: Optional[str] = None
    footnote_marker: Optional[str] = None
    is_treatment_col: bool = False
    is_stat_col: bool = False
    sdtm_source_var: Optional[str] = None
    validation_status: str = "unvalidated"

@dataclass
class MockShellRow:
    position: int = 0
    label: str = ""
    indent_level: int = 0
    is_header: bool = False
    is_total: bool = False

@dataclass
class MockShell:
    table_id: Optional[str] = None
    columns: List[MockShellColumn] = field(default_factory=list)
    rows: List[MockShellRow] = field(default_factory=list)
    visits: List[str] = field(default_factory=list)
    treatment_arms: List[str] = field(default_factory=list)
    spanning_headers: List[Dict[str, Any]] = field(default_factory=list)
    footnotes: List[str] = field(default_factory=list)
    inline_annotations: List[str] = field(default_factory=list)
    raw_text: Optional[str] = None
    parse_confidence: float = 0.0

# ── Analysis Output (extended) ────────────────────────────────────────────────
@dataclass
class Traceability:
    page_number: Optional[int] = None
    page_number_is_estimated: bool = True   # restored
    section_id: Optional[str] = None
    source_excerpt: Optional[str] = None
    confidence: float = 0.0

@dataclass
class DataSpecification:
    input_datasets: List[str] = field(default_factory=list)
    key_variables: Dict[str, List[str]] = field(default_factory=dict)
    derivations: Dict[str, str] = field(default_factory=dict)
    time_points: List[str] = field(default_factory=list)
    where_clause: Optional[str] = None
    adam_annotations: List[str] = field(default_factory=list)
    dataset_note: str = "Dataset names are indicative — verify against study ADaM spec"  # restored

@dataclass
class AnalysisSpec:
    methods: List[str] = field(default_factory=list)
    covariates: List[str] = field(default_factory=list)
    imputation: List[str] = field(default_factory=list)
    statistical_tests: List[str] = field(default_factory=list)
    sensitivity_analyses: List[str] = field(default_factory=list)
    missing_data_assumption: Optional[str] = None   # restored: MAR/MCAR/MNAR
    model_statement: Optional[str] = None           # restored: proc mixed formula
    confidence: float = 0.0

@dataclass
class WorkflowStatus:
    shell_approved: bool = False
    programmer: Optional[str] = None
    qc_analyst: Optional[str] = None
    qc_status: str = "not_started"
    locked: bool = False


@dataclass
class AnalysisSignature:
    """
    Blueprint Step 3: Canonical hashable unit for cross-study comparison.
    Uniquely identifies an analysis independent of output numbering.
    outcome + population + time_basis + summary_measure + analysis_class → hash
    """
    outcome_concept: str = ""          # e.g. "Plasma concentration", "Overall survival"
    population_abbreviation: str = ""  # e.g. "PK", "ITT", "SAF"
    time_basis: str = ""               # e.g. "Nominal sampling time", "Week 24", "EOS"
    summary_measure: str = ""          # e.g. "Mean/SD", "Kaplan-Meier", "ORR"
    stratification: str = ""           # e.g. "By dose level", "By ECOG"
    analysis_class: str = ""           # e.g. "PK", "Efficacy", "Safety"

    def to_hash(self) -> str:
        """Deterministic hash — identical analysis in different studies → same hash."""
        import hashlib
        key = "|".join([
            self.outcome_concept.lower().strip(),
            self.population_abbreviation.lower().strip(),
            self.time_basis.lower().strip(),
            self.summary_measure.lower().strip(),
            self.analysis_class.lower().strip(),
        ])
        return hashlib.md5(key.encode()).hexdigest()[:12]

    def __hash__(self):
        return hash(self.to_hash())

    def __eq__(self, other):
        return isinstance(other, AnalysisSignature) and self.to_hash() == other.to_hash()

@dataclass
class AnalysisOutput:
    output_id: str = ""
    output_type: OutputType = OutputType.TABLE
    output_class: OutputClass = OutputClass.OTHER
    output_number: Optional[str] = None
    title: Optional[str] = None
    full_title: Optional[str] = None
    section_id: Optional[str] = None
    display_order: int = 0
    population: Optional[Population] = None
    population_matched_by: str = "title_keyword"  # title_keyword|explicit|default
    endpoints: List[Endpoint] = field(default_factory=list)
    analysis: Optional[AnalysisSpec] = None
    data_specification: Optional[DataSpecification] = None
    mock_shell: Optional[MockShell] = None
    programming_rules: List[ProgrammingRule] = field(default_factory=list)
    traceability: Optional[Traceability] = None
    workflow_status: WorkflowStatus = field(default_factory=WorkflowStatus)
    confidence_score: float = 0.0
    is_appendix_output: bool = False
    appendix_label: Optional[str] = None
    from_shell_doc: bool = False
    related_outputs: List[Dict[str, str]] = field(default_factory=list)
    analysis_signature: Optional["AnalysisSignature"] = None  # Blueprint Step 3
    verification_status: str = "unverified"  # unverified|needs_review|programmer_ready|not_implementable
    # New Part I fields
    model_formula: Optional[str] = None
    by_variables: List[str] = field(default_factory=list)
    analysis_where: Optional[str] = None
    denominator_population: Optional[str] = None
    sensitivity_analyses: List[str] = field(default_factory=list)
    shell_output_number: Optional[str] = None
    shell_page_reference: Optional[int] = None
    treatment_arms: List[str] = field(default_factory=list)
    shell_footnotes: List[str] = field(default_factory=list)
    sas_program_name: Optional[str] = None
    sdtm_domains_required: List[str] = field(default_factory=list)
    def __post_init__(self): self.confidence_score = _clamp(self.confidence_score)

# ── SAP Version ───────────────────────────────────────────────────────────────
@dataclass
class SAPVersion:
    version: str = ""
    date: Optional[str] = None
    amendment: Optional[str] = None
    changes: List[str] = field(default_factory=list)

# ── QC ────────────────────────────────────────────────────────────────────────
@dataclass
class QCIssue:
    issue_id: str = field(default_factory=lambda: f"qc_{uuid.uuid4().hex[:8]}")
    severity: QCSeverity = QCSeverity.WARNING
    category: str = ""
    output_id: Optional[str] = None
    message: str = ""
    detail: Optional[str] = None
    suggested_fix: Optional[str] = None
    auto_fixable: bool = False   # restored

@dataclass
class QCReport:
    report_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    generated_at: str = field(default_factory=_utcnow)
    total_outputs: int = 0
    total_issues: int = 0
    errors: int = 0
    warnings: int = 0
    infos: int = 0
    overall_readiness_score: float = 0.0
    issues: List[QCIssue] = field(default_factory=list)
    completeness_pct: float = 0.0
    low_confidence_count: int = 0

# ── Study Metadata ────────────────────────────────────────────────────────────
@dataclass
class StudyMetadata:
    protocol_id: Optional[str] = None
    study_title: Optional[str] = None
    sponsor: Optional[str] = None
    phase: Optional[str] = None
    indication: Optional[str] = None
    therapeutic_area: Optional[str] = None
    nct_number: Optional[str] = None
    eudract_number: Optional[str] = None
    regulatory_agencies: List[str] = field(default_factory=list)
    blinding: Optional[str] = None
    randomization_ratio: Optional[str] = None
    data_cutoff_date: Optional[str] = None
    study_day_convention: Optional[StudyDayConvention] = None   # restored
    sap_version: Optional[str] = None
    sap_date: Optional[str] = None
    amendment_number: Optional[str] = None
    has_pk_analysis: bool = False
    has_pd_analysis: bool = False
    has_study_schema_diagram: bool = False

@dataclass
class DocumentMetadata:
    file_name: str = ""
    file_type: str = ""
    file_size_bytes: Optional[int] = None
    version: Optional[str] = None
    parsed_date: str = field(default_factory=_utcnow)
    role: str = "SAP"

# ── Root Schema ───────────────────────────────────────────────────────────────
@dataclass
class ClinicalIntelligenceSchema:
    system_metadata_job_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    parser_version: str = "5.0.0"
    execution_time_ms: Optional[int] = None
    documents: List[DocumentMetadata] = field(default_factory=list)
    study_metadata: StudyMetadata = field(default_factory=StudyMetadata)
    sap_versions: List[SAPVersion] = field(default_factory=list)
    populations: List[Population] = field(default_factory=list)
    endpoints: List[Endpoint] = field(default_factory=list)
    visit_schedule: List[VisitWindow] = field(default_factory=list)
    outputs_master: List[AnalysisOutput] = field(default_factory=list)
    rule_engine_output: List[ExtractedRule] = field(default_factory=list)
    timing_definitions: List[TimingDefinition] = field(default_factory=list)   # restored
    pkpd_spec: Optional[PKPDSpec] = None                                       # restored
    adam_spec_registry: Optional[ADaMSpecRegistry] = None                     # new Part A
    qc_report: Optional[QCReport] = None
    sections: List[Dict[str, Any]] = field(default_factory=list)
    toc_map: Dict[str, str] = field(default_factory=dict)
    cross_refs: Dict[str, str] = field(default_factory=dict)
    appendix_sections: List[str] = field(default_factory=list)
    has_study_schema_diagram: bool = False
    tracked_changes_stripped: bool = False
    inline_annotations_count: int = 0

    def get_output_by_id(self, oid: str) -> Optional[AnalysisOutput]:
        return next((o for o in self.outputs_master if o.output_id == oid), None)
    def get_population_by_abbrev(self, abbrev: str) -> Optional[Population]:
        return next((p for p in self.populations if p.abbreviation.upper() == abbrev.upper()), None)
    def to_summary_dict(self) -> Dict[str, Any]:
        return {
            "protocol_id": self.study_metadata.protocol_id,
            "sap_version": self.study_metadata.sap_version,
            "total_outputs": len(self.outputs_master),
            "total_populations": len(self.populations),
            "total_endpoints": len(self.endpoints),
            "total_rules": len(self.rule_engine_output),
            "total_visits": len(self.visit_schedule),
            "qc_readiness": self.qc_report.overall_readiness_score if self.qc_report else 0.0,
            "tracked_changes_stripped": self.tracked_changes_stripped,
            "adam_spec_loaded": self.adam_spec_registry is not None,
        }
    def model_dump_json(self, indent: int = 2) -> str:
        def _s(obj: Any) -> Any:
            if obj is None: return None
            if isinstance(obj, Enum): return obj.value
            if isinstance(obj, (list, tuple)): return [_s(i) for i in obj]
            if isinstance(obj, dict): return {k: _s(v) for k, v in obj.items()}
            if hasattr(obj, "__dataclass_fields__"):
                return {k: _s(getattr(obj, k)) for k in obj.__dataclass_fields__}
            return obj
        return json.dumps(_s(self), indent=indent, default=str, ensure_ascii=False)
