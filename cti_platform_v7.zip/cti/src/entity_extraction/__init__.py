"""
CTI v4 Entity Extraction — Complete rewrite for real-world SAP accuracy.

KEY v4 IMPROVEMENTS:
1. Endpoint extraction from STRUCTURED TABLES (Primary/Secondary columns)
2. DYNAMIC population extraction — no fixed list assumption
3. SAP version/amendment metadata
4. ADaM inline annotation capture
5. Visit windows from complex tables (PK sampling, dose schedules)
6. Broader NLP patterns for all entity types
7. Table-based censoring rule extraction (Table 5-1 style)
"""
from __future__ import annotations
import re, uuid
from typing import Dict, List, Optional, Tuple, Set

from src.models.schema import (
    AnalysisOutput, AnalysisSpec, DataSpecification, Endpoint,
    EndpointClassification, Estimand, MockShell, OutputClass, OutputType,
    Population, ProgrammingRule, RuleType, StudyMetadata, Traceability,
    VisitWindow, SAPVersion,
)
from src.parsers import ParsedDocument, ParsedSection, ParsedTable
from src.utils import (
    clean_text, classify_output, compute_confidence, extract_number_from_title,
    get_logger, infer_adam_datasets, normalize_population, normalize_method,
    normalize_population_dynamic, slugify, truncate,
    POPULATION_NORMALIZATION, POPULATION_FLAG_MAP, POPULATION_DATASET_MAP,
)

logger = get_logger(__name__)

# ── Output number pattern (supports up to 6-level: 15.8.1.3.1.x) ─────────────
_TLF_SPLIT_RE = re.compile(
    r"(?=(?:Table|Listing|Figure|Appendix|Exhibit)\s+\d+\.\d)",
    re.IGNORECASE
)
_TLF_ENTRY_RE = re.compile(
    r"(Table|Listing|Figure|Appendix|Exhibit)\s+"
    r"(\d+(?:\.\d+){0,5}[a-zA-Z]?)\s*[:.]?\s*(.{5,300})",
    re.IGNORECASE | re.DOTALL
)
_TOC_PATTERN = re.compile(
    r"table\s+of\s+contents|list\s+of\s+(?:tables|figures|listings)|contents",
    re.IGNORECASE
)

# ── ADaM inline annotation pattern ───────────────────────────────────────────
_ADAM_ANN_RE = re.compile(
    r"(ADSL?)\.[A-Z][A-Z0-9]{2,15}\s*(?:=\s*['\"]?[YN\d]+['\"]?)?",
    re.IGNORECASE
)

# ── Objective/endpoint TABLE patterns (real SAP: 2-col table) ────────────────
_OBJ_EP_TABLE_KEYWORDS = [
    "primary objective", "primary endpoint", "secondary objective",
    "secondary endpoint", "exploratory objective", "exploratory endpoint",
    "study objective", "study endpoint",
]


class StudyMetadataExtractor:
    _PROTOCOL_PATTERNS = [
        r"(?:protocol|study)\s+(?:number|no\.?|id)[:\s]+([A-Z0-9][A-Z0-9\-_\.]{2,25})",
        r"(?:protocol|study)\s+([A-Z]{2,5}-(?:US-)?[\d\-]{3,20})",
        r"([A-Z]{2,4}-\d{3,5}-\d{3,5}-\d{3,5})",  # GS-US-616-6291 style
    ]
    _NCT_RE = re.compile(r"NCT\d{8}")
    _EUDRACT_RE = re.compile(r"\d{4}-\d{6}-\d{2}")
    _PHASE_RE = re.compile(r"[Pp]hase\s+([123456IV]+(?:/[123IV]+)?(?:[ab])?)")
    _SPONSOR_RE = re.compile(r"[Ss]ponsor[:\s]+([A-Z][A-Za-z\s,\.]{5,60}?)(?:\n|\.|\|)", re.IGNORECASE)
    _BLIND_RE = re.compile(r"(open.label|single.blind|double.blind|triple.blind|unblinded)", re.IGNORECASE)
    _RAND_RE = re.compile(r"randomized?\s+(?:in\s+(?:a\s+)?)?(\d+:\d+(?::\d+)?\s*(?::\d+)?)\s*ratio", re.IGNORECASE)
    _VER_RE = re.compile(r"[Vv]ersion\s+([\d]+\.[\d]+(?:\.[\d]+)?)")
    _AMEND_RE = re.compile(r"[Aa]mendment\s+(\d+|[A-Z])\b")
    _DATE_RE = re.compile(r"(\d{1,2}\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{4}|\d{4}-\d{2}-\d{2})")

    def extract(self, document: ParsedDocument) -> StudyMetadata:
        preamble = document.full_text[:6000]
        meta = StudyMetadata()

        # Protocol ID
        for pat in self._PROTOCOL_PATTERNS:
            m = re.search(pat, preamble, re.IGNORECASE)
            if m:
                meta.protocol_id = m.group(1).strip()
                break

        # NCT, EudraCT
        m = self._NCT_RE.search(preamble)
        if m: meta.nct_number = m.group(0)
        m = self._EUDRACT_RE.search(preamble)
        if m: meta.eudract_number = m.group(0)

        # Phase
        m = self._PHASE_RE.search(preamble)
        if m: meta.phase = m.group(1).upper()

        # Sponsor
        m = self._SPONSOR_RE.search(preamble)
        if m: meta.sponsor = m.group(1).strip().rstrip(",.")

        # Title — try multiple patterns
        title_m = re.search(r"(?:study|trial)\s+title[:\s]+(.{20,250}?)(?:\n|protocol)", preamble, re.IGNORECASE | re.DOTALL)
        if title_m:
            meta.study_title = clean_text(title_m.group(1))
        if not meta.study_title:
            # Look for long sentence that looks like a trial title
            for line in preamble.split('\n'):
                line = line.strip()
                if (40 < len(line) < 300 and
                    any(k in line.lower() for k in ['study of','trial of','phase','participants','patients','subjects']) and
                    not any(k in line.lower() for k in ['abbreviation','version','plan','sponsor'])):
                    meta.study_title = line[:250]
                    break
        if not meta.study_title and document.sections:
            for s in document.sections[:5]:
                if len(s.title) > 20 and not _TOC_PATTERN.search(s.title):
                    meta.study_title = s.title[:250]
                    break

        # Blinding, randomization ratio
        m = self._BLIND_RE.search(preamble)
        if m: meta.blinding = m.group(1).replace("-", " ").title()
        m = self._RAND_RE.search(preamble)
        if m: meta.randomization_ratio = m.group(1).strip()

        # SAP version and amendment (from document if parsed, else from text)
        if document.sap_version:
            meta.sap_version = document.sap_version
        else:
            m = self._VER_RE.search(preamble)
            if m: meta.sap_version = m.group(1)

        if document.sap_amendment:
            meta.amendment_number = document.sap_amendment
        else:
            m = self._AMEND_RE.search(preamble)
            if m: meta.amendment_number = m.group(1)

        # SAP date
        m = self._DATE_RE.search(preamble)
        if m: meta.sap_date = m.group(0)

        # Regulatory agencies
        agencies = []
        for ag in ["FDA","EMA","PMDA","Health Canada","MHRA","ANVISA","TGA"]:
            if ag.lower() in preamble.lower():
                agencies.append(ag)
        meta.regulatory_agencies = agencies

        # Has PK/PD
        meta.has_pk_analysis = bool(re.search(r"\bpharmacokinetic|PK\s+(?:analysis|data|parameter)", preamble, re.IGNORECASE))
        meta.has_pd_analysis = bool(re.search(r"\bpharmacodynamic|PD\s+(?:analysis|endpoint)", preamble, re.IGNORECASE))
        meta.has_study_schema_diagram = document.has_study_schema_diagram

        return meta


class SAPVersionExtractor:
    """Extract SAP version history from document."""
    _AMEND_BLOCKS = re.compile(
        r"[Aa]mendment\s+(\d+|[A-Z])[\s,]+(?:dated?\s+)?([\w\s,]+?\d{4})?[:\s]+(.{20,400}?)(?=\n\n|\Z|\d+\.\s+[A-Z])",
        re.DOTALL
    )
    def extract(self, document: ParsedDocument) -> List[SAPVersion]:
        versions = []
        if document.sap_version:
            versions.append(SAPVersion(
                version=document.sap_version,
                amendment=document.sap_amendment,
            ))
        # Scan for amendment history
        preamble = document.full_text[:8000]
        for m in self._AMEND_BLOCKS.finditer(preamble):
            versions.append(SAPVersion(
                version="",
                amendment=m.group(1),
                date=m.group(2).strip() if m.group(2) else None,
                changes=[clean_text(m.group(3))[:200]],
            ))
        return versions[:10]


class PopulationExtractor:
    """
    v4: Dynamic + fixed population extraction.
    Scans population sections AND child subsections.
    Detects non-standard sets (DLT, All Enrolled, Immunogenicity).
    Extracts ADaM flag variables from inline annotations.
    """
    _SECTION_KEYWORDS = [
        "analysis set","analysis population","study population","patient population",
        "participant population","general consideration","data analys"
    ]
    _DEF_PATTERNS = [
        r"(?:The\s+)?(?P<name>[A-Z][A-Za-z\s\-/]{3,60}?)\s+(?:[Aa]nalysis\s+[Ss]et|[Pp]opulation)\s+(?:is\s+defined\s+as|includes?|consists?\s+of|comprises?)\s+(?P<def>.{15,400}?)(?:\.|;|\n\n)",
        r"(?P<name>[A-Z][A-Za-z\s\-/]{3,50}?)\s+(?:[Aa]nalysis\s+[Ss]et|[Pp]opulation)\s*\((?P<abbrev>[A-Z]{2,8})\).*?(?P<def>(?:includes?|is\s+defined)[^.;]{15,300}?)(?:\.|;)",
        r"(?P<abbrev>[A-Z]{2,8})FL\s*(?:=\s*['\"]?Y['\"]?)?[.\s,]+(?:for\s+)?(?P<name>[A-Za-z\s\-/]{5,60}?)(?:population|set|analysis set)",
    ]
    _FLAG_INLINE = re.compile(r"([A-Z]{2,8}FL)\s*=\s*['\"]?Y['\"]?", re.IGNORECASE)

    def extract(self, document: ParsedDocument) -> List[Population]:
        populations: List[Population] = []
        seen: Set[str] = set()

        # Find population sections AND their children
        pop_sec_ids: Set[str] = set()
        pop_sections = []
        for sec in document.sections:
            if any(kw in sec.title.lower() for kw in self._SECTION_KEYWORDS):
                pop_sections.append(sec)
                pop_sec_ids.add(sec.section_id)
        # Include children of matched sections
        for sec in document.sections:
            if sec.parent_id in pop_sec_ids and sec.section_id not in pop_sec_ids:
                pop_sections.append(sec)

        all_sections = pop_sections if pop_sections else document.sections

        for sec in all_sections:
            text = sec.get_text()
            if not text: continue

            # Try fixed normalization first
            for norm_pat, (label, abbrev, order) in POPULATION_NORMALIZATION.items():
                if abbrev not in seen and re.search(norm_pat, text, re.IGNORECASE):
                    flag = POPULATION_FLAG_MAP.get(abbrev, abbrev + "FL")
                    definition = self._extract_definition(text, label, abbrev)
                    seen.add(abbrev)
                    populations.append(Population(
                        population_id=f"pop_{slugify(abbrev)}",
                        label=label, abbreviation=abbrev,
                        hierarchy_order=order,
                        formal_definition=definition,
                        adam_flag_variable=flag,
                        adam_dataset=POPULATION_DATASET_MAP.get(abbrev, "ADSL"),
                        derivation_rule=f"where {flag} = 'Y';",
                        source_section=sec.section_id,
                        source_page=sec.page_start,
                        confidence=0.85 if definition else 0.65,
                    ))

            # Also scan tables in section for population definitions
            for tbl in sec.tables:
                self._extract_from_table(tbl, populations, seen, sec)

            # Dynamic extraction for non-standard populations
            for pat in self._DEF_PATTERNS:
                for m in re.finditer(pat, text, re.IGNORECASE | re.DOTALL):
                    d = m.groupdict()
                    name = clean_text(d.get("name","")).strip()
                    abbrev_raw = clean_text(d.get("abbrev","")).strip()
                    definition = clean_text(d.get("def","")).strip()[:400]
                    if not name or len(name) < 4: continue

                    # Generate abbreviation
                    if not abbrev_raw:
                        abbrev_raw = "".join(w[0].upper() for w in name.split() if w)[:6]

                    # Check fixed list first
                    result = normalize_population(name + " population")
                    if result:
                        label, abbrev, order = result
                    else:
                        label = name; abbrev = abbrev_raw; order = 5

                    if abbrev in seen: continue
                    seen.add(abbrev)

                    # Try to find flag variable inline
                    flag = POPULATION_FLAG_MAP.get(abbrev, abbrev + "FL")
                    flag_m = self._FLAG_INLINE.search(definition + " " + text[:500])
                    if flag_m: flag = flag_m.group(1).upper()

                    populations.append(Population(
                        population_id=f"pop_{slugify(abbrev)}",
                        label=label, abbreviation=abbrev,
                        hierarchy_order=order,
                        formal_definition=truncate(definition, 400),
                        adam_flag_variable=flag,
                        adam_dataset="ADSL",
                        derivation_rule=f"where {flag} = 'Y';",
                        source_section=sec.section_id,
                        source_page=sec.page_start,
                        is_dynamic=True,
                        confidence=0.78 if definition else 0.55,
                    ))

        # Also extract from ADaM inline annotations
        for ann in document.all_adam_annotations:
            m = re.match(r"ADSL?\.(([A-Z]{2,8})FL)\s*=\s*['\"]?Y", ann, re.IGNORECASE)
            if m:
                flag = m.group(1).upper()
                abbrev = m.group(2).upper()
                if abbrev not in seen:
                    result = normalize_population(abbrev + " population")
                    if result:
                        label, abbrev2, order = result
                        seen.add(abbrev2)
                        populations.append(Population(
                            population_id=f"pop_{slugify(abbrev2)}",
                            label=label, abbreviation=abbrev2,
                            hierarchy_order=order,
                            adam_flag_variable=flag,
                            adam_dataset="ADSL",
                            derivation_rule=f"where {flag} = 'Y';",
                            confidence=0.90,  # High confidence - inline annotation
                        ))

        # Ensure SAF and at least one primary pop always present
        if not any(p.abbreviation in ("SAF",) for p in populations):
            populations.append(self._default("SAF","Safety",2))
        if not any(p.abbreviation in ("ITT","FAS","ENRL") for p in populations):
            populations.append(self._default("FAS","Full Analysis Set",1))

        # Deduplicate: remove dynamic entries shadowed by fixed entries with same abbreviation
        seen_abbrevs: Set[str] = set()
        deduped: List[Population] = []
        # Fixed entries first (is_dynamic=False), then dynamic
        for pop in sorted(populations, key=lambda p: (p.is_dynamic, p.hierarchy_order)):
            key = pop.abbreviation.upper()
            if key not in seen_abbrevs:
                seen_abbrevs.add(key)
                deduped.append(pop)
        return sorted(deduped, key=lambda p: p.hierarchy_order)

    def _extract_definition(self, text: str, label: str, abbrev: str) -> Optional[str]:
        esc_label = re.escape(label)
        esc_abbrev = re.escape(abbrev)
        patterns = [
            # "Label (ABBREV) population: definition."  — most common SAP format
            esc_label + r"\s*\([A-Z]{2,8}\)\s*(?:population|set|subjects)[:\s]+(.{20,300}?)(?:\.|;)",
            # "Label population: definition."
            esc_label + r"\s*(?:population|set|subjects)[:\s]+(.{20,300}?)(?:\.|;)",
            # "ABBREV population: definition."
            r"\b" + esc_abbrev + r"\b\s*(?:population|set|subjects)[:\s]+(.{20,300}?)(?:\.|;)",
            # "Label is defined as / consists of / includes"
            esc_label + r".{0,30}(?:is\s+defined\s+as|consists?\s+of|includes?)[:\s]+(.{20,400}?)(?:\.|;)",
            esc_abbrev + r".{0,30}(?:is\s+defined\s+as|includes?|set\s+includes?)[:\s]+(.{20,400}?)(?:\.|;)",
            # "All subjects who received..."  generic
            r"(?:defined\s+as|includes?)\s+all\s+(?:enrolled\s+)?(?:subjects|participants).{0,300}?(?:who\s+.{20,200}?)(?:\.|;)",
        ]
        for p in patterns:
            m = re.search(p, text, re.IGNORECASE | re.DOTALL)
            if m: return truncate(clean_text(m.group(1) if m.lastindex else m.group(0)), 400)
        return None

    def _extract_from_table(self, tbl: ParsedTable, populations, seen, sec):
        """Extract population definitions from table rows."""
        for row in tbl.rows:
            if len(row) < 2: continue
            first_cell = row[0].strip()
            if not first_cell or len(first_cell) < 3: continue
            result = normalize_population(first_cell)
            if result and result[1] not in seen:
                label, abbrev, order = result
                seen.add(abbrev)
                flag = POPULATION_FLAG_MAP.get(abbrev, abbrev + "FL")
                defn = " ".join(row[1:]).strip()
                populations.append(Population(
                    population_id=f"pop_{slugify(abbrev)}",
                    label=label, abbreviation=abbrev, hierarchy_order=order,
                    formal_definition=truncate(defn, 300) or None,
                    adam_flag_variable=flag, adam_dataset="ADSL",
                    derivation_rule=f"where {flag} = 'Y';",
                    source_section=sec.section_id, source_page=sec.page_start,
                    confidence=0.88,
                ))

    @staticmethod
    def _default(abbrev, label, order) -> Population:
        flag = POPULATION_FLAG_MAP.get(abbrev, abbrev + "FL")
        return Population(
            population_id=f"pop_{abbrev.lower()}", label=label, abbreviation=abbrev,
            hierarchy_order=order, adam_flag_variable=flag, adam_dataset="ADSL",
            derivation_rule=f"where {flag} = 'Y';", confidence=0.55,
        )


class EndpointExtractor:
    """
    v4: Extracts endpoints from BOTH prose AND 2-column objective/endpoint tables.
    The real SAP (GS-4528) uses a table with Primary Objective | Primary Endpoint columns.
    """
    _SECTION_KEYWORDS = ["objective","endpoint","aim","goal","study design","introduction","1.1"]
    _EP_TABLE_KEYWORDS = ["primary objective","primary endpoint","secondary objective","secondary endpoint"]

    _PRIMARY_PATTERNS = [
        r"primary\s+(?:efficacy\s+)?endpoint\s+(?:is|are|:)\s+(.+?)(?:\n\n|\.\s*(?:[A-Z]|$)|\.$|$)",
        r"primary\s+(?:efficacy\s+)?objective\s*[:\-–]\s*(.+?)(?:\n\n|\.\s*(?:[A-Z]|$)|\.$|$)",
        r"the\s+primary\s+(?:endpoint|outcome)\s+(?:is|of\s+this\s+study\s+(?:is|will\s+be))\s+(.+?)(?:\.|;|\n)",
        r"primary\s+endpoints?[:\s]+(.+)",
        r"co.primary\s+endpoint[s]?[:\s]+(.+)",
    ]
    _SECONDARY_PATTERNS = [
        r"(?:key\s+)?secondary\s+(?:efficacy\s+)?endpoint[s]?\s+(?:include[s]?|are|:)\s+(.+)",
        r"(?:key\s+)?secondary\s+(?:efficacy\s+)?objective[s]?\s*[:\-–]\s*(.+)",
    ]
    _SAFETY_PATTERNS = [
        r"safety\s+endpoint[s]?\s+(?:include[s]?|are)[:\s]+(.+)",
        r"safety\s+(?:and\s+tolerability\s+)?(?:endpoints?|variables?|assessments?)\s+(?:include[s]?)[:\s]+(.+)",
    ]
    _PK_PATTERNS = [
        r"(?:primary\s+)?PK\s+(?:endpoint[s]?|parameter[s]?)[:\s]+(.+)",
        r"pharmacokinetic\s+(?:endpoint[s]?|objective[s]?)[:\s]+(.+)",
    ]
    _TIMEPOINT_RE = re.compile(r"(?:at\s+|through\s+|by\s+)?(?:week|day|month|year|cycle)\s+\d+|end\s+of\s+(?:study|treatment)", re.IGNORECASE)

    def extract(self, document: ParsedDocument) -> List[Endpoint]:
        endpoints: List[Endpoint] = []
        seen: Set[str] = set()

        # First: scan objective/endpoint sections
        ep_sections = []
        for sec in document.sections:
            if any(kw in sec.title.lower() for kw in self._SECTION_KEYWORDS):
                ep_sections.append(sec)

        all_secs = ep_sections if ep_sections else document.sections[:15]

        for sec in all_secs:
            text = sec.get_text()
            if not text: continue

            # Extract from tables FIRST (most reliable for real SAPs)
            for tbl in sec.tables:
                self._extract_from_objective_table(tbl, endpoints, seen, sec)

            # Prose patterns
            self._extract_prose(text, sec, endpoints, seen)

        return endpoints

    def _extract_from_objective_table(self, tbl: ParsedTable, endpoints, seen, sec):
        """
        Parse 2-column Objective | Endpoint tables.
        Also parse TEAE plan tables, censoring rule tables.
        """
        if not tbl.rows or tbl.num_cols < 2: return
        headers = [c.lower().strip() for c in tbl.rows[0]]

        # Check if this looks like an objective/endpoint table
        is_ep_table = any(any(kw in h for kw in self._EP_TABLE_KEYWORDS) for h in headers)
        if not is_ep_table:
            # Check first column of first data row
            if tbl.num_rows >= 2:
                first_row_text = " ".join(tbl.rows[0]).lower()
                is_ep_table = any(kw in first_row_text for kw in ["primary","secondary","exploratory"])

        if not is_ep_table: return

        for row in tbl.rows[1:]:
            if not row or not any(c.strip() for c in row): continue
            # Col 0 = objective, Col 1 = endpoint
            obj_text = row[0].strip() if row else ""
            ep_text = " | ".join(c.strip() for c in row[1:] if c.strip())

            # Classify from objective column
            cls = EndpointClassification.SECONDARY
            obj_lower = obj_text.lower()
            if "primary" in obj_lower: cls = EndpointClassification.PRIMARY
            elif "safety" in obj_lower or "tolerability" in obj_lower: cls = EndpointClassification.SAFETY
            elif "pk" in obj_lower or "pharmacokinetic" in obj_lower: cls = EndpointClassification.PK
            elif "exploratory" in obj_lower: cls = EndpointClassification.EXPLORATORY

            if ep_text and ep_text not in seen:
                seen.add(ep_text[:60])
                timepoints = self._TIMEPOINT_RE.findall(ep_text + " " + obj_text)
                endpoints.append(Endpoint(
                    endpoint_id=f"ep_{uuid.uuid4().hex[:8]}",
                    classification=cls.value,
                    description=truncate(clean_text(ep_text), 400),
                    timepoints=[t.strip() for t in timepoints],
                    source_section=sec.section_id, source_page=sec.page_start,
                    from_table=True,
                    confidence=0.90,
                ))

            # Also capture objective as separate endpoint if different
            if obj_text and obj_text not in seen and len(obj_text) > 20:
                seen.add(obj_text[:60])
                cls2 = cls if not ep_text else (
                    EndpointClassification.PRIMARY if "primary" in obj_text.lower()
                    else EndpointClassification.SECONDARY
                )
                endpoints.append(Endpoint(
                    endpoint_id=f"ep_{uuid.uuid4().hex[:8]}",
                    classification=cls2.value,
                    description=truncate(clean_text(obj_text), 400),
                    source_section=sec.section_id, source_page=sec.page_start,
                    from_table=True, confidence=0.85,
                ))

    def _extract_prose(self, text: str, sec, endpoints, seen):
        def _add(desc: str, cls: EndpointClassification, from_tbl: bool = False):
            for sub in re.split(r";\s*|\n\s*[-•*]\s*", desc):
                sub = clean_text(sub)
                if len(sub) < 12 or sub[:60] in seen: continue
                seen.add(sub[:60])
                tps = self._TIMEPOINT_RE.findall(sub)
                endpoints.append(Endpoint(
                    endpoint_id=f"ep_{uuid.uuid4().hex[:8]}",
                    classification=cls.value,
                    description=truncate(sub, 350),
                    timepoints=[t.strip() for t in tps],
                    source_section=sec.section_id,
                    source_page=sec.page_start,
                    from_table=from_tbl,
                    confidence=0.88 if from_tbl else 0.78,
                ))

        # Detect pipe-separated objective|endpoint table in plain text
        # Pattern: "Objective text | Endpoint text" (from txt SAP files)
        pipe_rows = re.findall(r"^(.+?)\s*\|\s*(.+?)$", text, re.MULTILINE)
        for obj_text, ep_text in pipe_rows:
            obj_text = obj_text.strip(); ep_text = ep_text.strip()
            if len(obj_text) < 10 or len(ep_text) < 10: continue
            # Skip header rows
            if any(kw in obj_text.lower() for kw in ["objective", "endpoint", "---"]):
                continue
            # Classify from row position or content
            obj_lower = obj_text.lower()
            cls = EndpointClassification.SECONDARY
            if "safety" in obj_lower or "tolerab" in obj_lower: cls = EndpointClassification.SAFETY
            elif "pk" in obj_lower or "pharmacokinetic" in obj_lower: cls = EndpointClassification.PK
            elif "exploratory" in obj_lower: cls = EndpointClassification.EXPLORATORY
            else: cls = EndpointClassification.SECONDARY  # Unlabelled rows → SECONDARY (safer default)
            _add(ep_text, cls, from_tbl=True)

        for pat in self._PRIMARY_PATTERNS:
            for m in re.finditer(pat, text, re.IGNORECASE | re.DOTALL):
                _add(m.group(1), EndpointClassification.PRIMARY)
        for pat in self._SECONDARY_PATTERNS:
            for m in re.finditer(pat, text, re.IGNORECASE | re.DOTALL):
                _add(m.group(1), EndpointClassification.KEY_SECONDARY)
        for pat in self._SAFETY_PATTERNS:
            for m in re.finditer(pat, text, re.IGNORECASE | re.DOTALL):
                _add(m.group(1), EndpointClassification.SAFETY)
        for pat in self._PK_PATTERNS:
            for m in re.finditer(pat, text, re.IGNORECASE | re.DOTALL):
                _add(m.group(1), EndpointClassification.PK)


class VisitScheduleExtractor:
    _SECTION_KEYWORDS = ["visit","window","assessment","schedule","timing","analysis visit"]
    _WINDOW_RE = re.compile(
        r"(?:visit\s+)?(?:window\s+)?(?:for\s+)?(?:week|day|cycle)\s*(\d+).{0,40}"
        r"(?:day|week|cycle)\s+(\d+)\s+to\s+(?:day|week|cycle)\s+(\d+)",
        re.IGNORECASE
    )
    _CYCLE_RE = re.compile(r"[Cc]ycle\s+(\d+)(?:\s+[Dd]ay\s+(\d+))?")

    def extract(self, document: ParsedDocument) -> List[VisitWindow]:
        visits: List[VisitWindow] = []
        seen_labels: Set[str] = set()

        for sec in document.sections:
            if not any(kw in sec.title.lower() for kw in self._SECTION_KEYWORDS):
                continue
            text = sec.get_text()
            for tbl in sec.tables:
                self._from_table(tbl, visits, seen_labels, sec)
            for m in self._WINDOW_RE.finditer(text):
                label = f"Week {m.group(1)}"
                if label in seen_labels: continue
                seen_labels.add(label)
                d_from, d_to = int(m.group(2)), int(m.group(3))
                nominal = (d_from + d_to) // 2
                visits.append(VisitWindow(
                    visit_id=f"vis_w{m.group(1).zfill(3)}", visit_label=label,
                    nominal_day=nominal, window_pre_days=nominal-d_from,
                    window_post_days=d_to-nominal,
                    window_rule=truncate(m.group(0), 200),
                    adam_visit_value=label.upper(),
                    adam_visitnum=float(m.group(1)),
                    analysis_visit_flag=True,
                    source_page=sec.page_start, confidence=0.88,
                ))

        if not visits:
            visits = self._defaults()
        return sorted(visits, key=lambda v: (v.adam_visitnum or 0))

    def _from_table(self, tbl: ParsedTable, visits, seen, sec):
        if not tbl.rows: return
        hdr = [c.lower() for c in tbl.rows[0]]
        visit_col = next((i for i,h in enumerate(hdr) if any(k in h for k in ["visit","cycle","week","day"])), None)
        window_col = next((i for i,h in enumerate(hdr) if "window" in h), None)
        if visit_col is None: return
        for row in tbl.rows[1:]:
            if not row or not row[visit_col].strip(): continue
            label = row[visit_col].strip()
            if label in seen: continue
            seen.add(label)
            wm = None
            if window_col and window_col < len(row):
                wm = re.search(r"[+-]?\s*(\d+)", row[window_col])
            wk = re.search(r"(?:week|cycle|day)\s*(\d+)", label, re.IGNORECASE)
            visitnum = float(wk.group(1)) if wk else None
            visits.append(VisitWindow(
                visit_id=f"vis_{slugify(label)[:20]}",
                visit_label=label, adam_visit_value=label.upper(),
                adam_visitnum=visitnum, analysis_visit_flag=bool(visitnum),
                source_page=sec.page_start, confidence=0.82,
            ))

    @staticmethod
    def _defaults() -> List[VisitWindow]:
        return [
            VisitWindow(visit_id="vis_scr",visit_label="Screening",visit_type="Screening",
                        adam_visit_value="SCREENING",confidence=0.50),
            VisitWindow(visit_id="vis_d1",visit_label="Day 1",nominal_day=1,
                        window_pre_days=0,window_post_days=0,
                        adam_visit_value="DAY 1",adam_visitnum=1.0,
                        analysis_visit_flag=True,confidence=0.50),
            VisitWindow(visit_id="vis_eot",visit_label="End of Treatment",
                        adam_visit_value="END OF TREATMENT",confidence=0.40),
        ]


def _canonicalize_title(title: str) -> str:
    """
    Blueprint Step 2: Normalise title to semantic unit by stripping cosmetic variants.
    'Mean (SD) Plasma Conc.' and 'Median (Q1, Q3) Plasma Conc.' → 'Plasma Conc.'
    Used to group related outputs into AnalysisSignature families.
    """
    import re as _re
    t = title or ""
    # Strip statistical display specifiers (not semantic)
    t = _re.sub(r'(?:Mean|Median|SD|SE|Min|Max|IQR|Q1|Q3|Geometric|CV%?|'
                r'Number|Percent|n|N|Count|Rate|95%?\s*CI)', '', t, flags=_re.IGNORECASE)
    t = _re.sub(r'\(.*?\)', '', t)     # remove parenthetical expressions
    t = _re.sub(r'\[.*?\]', '', t)     # remove bracketed qualifiers  
    t = _re.sub(r'\s+', ' ', t).strip()
    return t.lower()


def _clean_title(raw: str) -> str:
    """
    Remove trailing page/section reference numbers from TLF titles.
    Examples:
      '...Treatments]155'  -> '...Treatments]'
      '...Measures34 6.5.' -> '...Measures'
      '  foo  bar  '       -> 'foo bar'
    """
    import re as _re
    if not raw:
        return raw
    # Strip trailing 2-4 digit page-reference numbers after ] ) or whitespace
    title = _re.sub(r'([\])])\s*\d{2,4}\s*$', r'\1', raw)
    # Strip trailing standalone digits after a word character
    title = _re.sub(r'(?<=\w)\s*\d{2,4}\s*$', '', title)
    # Normalise whitespace
    title = _re.sub(r'\s+', ' ', title).strip()
    return title


class OutputExtractor:
    _TOC_PATTERN = re.compile(r"(?:table|list)\s+of\s+(?:tables|figures|listings|contents)", re.IGNORECASE)
    _SHORTREF_RE = re.compile(r"(?:^|\s)([TLF])(\d+(?:\.\d+){0,5}[a-zA-Z]?)\s*[:.]?\s*(.{3,150})", re.MULTILINE)

    @staticmethod
    def _split_tlf(text: str) -> List[Tuple[str,str,str]]:
        parts = _TLF_SPLIT_RE.split(text)
        results = []
        for part in parts:
            part = part.strip()
            if not part: continue
            m = _TLF_ENTRY_RE.match(part)
            if m:
                raw_title = re.split(r"\s+(?:Table|Listing|Figure|Appendix|Exhibit)\s+\d", m.group(3))[0]
                title = _clean_title(clean_text(raw_title))
                if title and len(title) >= 5:
                    results.append((m.group(1), m.group(2), title))
        return results

    def extract(self, document: ParsedDocument, populations: List[Population],
                endpoints: List[Endpoint]) -> List[AnalysisOutput]:
        outputs: List[AnalysisOutput] = []
        seen: Set[Tuple[str,str]] = set()  # (type_key, number)

        for sec in document.sections:
            text = sec.get_text()
            if not text: continue
            if self._TOC_PATTERN.search(sec.title): continue

            for type_str, num, title in self._split_tlf(text):
                key = (type_str.upper()[0], num)
                if key in seen: continue
                seen.add(key)
                outputs.append(self._build(type_str, num, title, sec, populations, endpoints, len(outputs)+1))

            # Short reference T15.8.1.3.1 style
            for m in self._SHORTREF_RE.finditer(text):
                type_map = {"T":"Table","L":"Listing","F":"Figure"}
                ts = type_map.get(m.group(1).upper(),"Table")
                num = m.group(2)
                key = (ts[0], num)
                if key in seen: continue
                seen.add(key)
                title = clean_text(m.group(3).split("\n")[0])
                if len(title) >= 5:
                    outputs.append(self._build(ts, num, title, sec, populations, endpoints, len(outputs)+1))

        return sorted(outputs, key=lambda o: (o.output_type.value, o.output_number or ""))

    def _build(self, type_str: str, number: str, title: str, sec,
               populations, endpoints, display_order: int) -> AnalysisOutput:
        ot = OutputType.TABLE
        for x in OutputType:
            if x.value.lower() == type_str.lower(): ot = x; break

        cls_str = classify_output(title, sec.get_text()[:300])
        oc = OutputClass.OTHER
        for x in OutputClass:
            if x.value.lower() == cls_str.lower(): oc = x; break

        pop = self._match_pop(title + " " + sec.get_text()[:500], populations)
        eps = self._match_eps(title, endpoints)
        datasets = infer_adam_datasets(title, sec.get_text()[:400])
        methods = [normalize_method(t) for t in [sec.get_text()[:1000]] if normalize_method(t)]
        methods = [m for m in methods if m]

        # Extract ADaM annotations as programming rules
        prog_rules: List[ProgrammingRule] = []
        for ann in sec.adam_annotations[:5]:
            prog_rules.append(ProgrammingRule(
                rule=ann, rule_type=RuleType.INLINE_ANNOTATION,
                severity="mandatory", confidence=0.92,
                adam_variable=re.sub(r"ADSL?\.", "", ann).split("=")[0].strip(),
            ))

        # CHG derivation if change from baseline mentioned
        if re.search(r"change\s+from\s+baseline", title + " " + sec.get_text()[:300], re.IGNORECASE):
            prog_rules.append(ProgrammingRule(
                rule="CHG = AVAL - BASE", rule_type=RuleType.DERIVATION,
                severity="mandatory", sas_hint="CHG = AVAL - BASE;", confidence=0.95,
            ))
        if pop and pop.adam_flag_variable:
            prog_rules.append(ProgrammingRule(
                rule=f"{pop.adam_flag_variable} = 'Y'", rule_type=RuleType.FILTER,
                severity="mandatory", sas_hint=f"where {pop.adam_flag_variable} = 'Y';",
                confidence=0.97, adam_variable=pop.adam_flag_variable,
            ))

        confidence = compute_confidence(
            sum([bool(pop), bool(eps), bool(methods), bool(datasets), bool(title)]), 5, 0.60
        )

        output_id = f"out_{ot.value[0].lower()}{number.replace('.','_')}"

        # Blueprint Step 3: build AnalysisSignature
        from src.models.schema import AnalysisSignature as _AS
        sig = _AS(
            outcome_concept=_canonicalize_title(title),
            population_abbreviation=pop.abbreviation if pop else "",
            time_basis=", ".join(eps[0].timepoints[:2]) if eps and eps[0].timepoints else "",
            summary_measure=", ".join(methods[:2]) if methods else "",
            analysis_class=oc,
        )
        # Blueprint Step 10: verification_status based on confidence and completeness
        vs = ("programmer_ready" if confidence >= 0.88 and pop
              else "needs_review" if confidence >= 0.65
              else "unverified")

        return AnalysisOutput(
            output_id=output_id, output_type=ot, output_class=oc,
            output_number=number,
            full_title=f"{ot.value} {number}: {_clean_title(title)}",
            title=_clean_title(title),
            analysis_signature=sig,
            verification_status=vs,
            section_id=sec.section_id, display_order=display_order,
            population=pop, endpoints=eps[:3],
            analysis=AnalysisSpec(methods=methods, confidence=0.80 if methods else 0.50),
            data_specification=DataSpecification(
                input_datasets=datasets,
                key_variables={
                    "by_vars": ["USUBJID","TRT01PN"],
                    "analysis_vars": ["AVAL","BASE","CHG"],
                    "filter_vars": [pop.adam_flag_variable] if pop and pop.adam_flag_variable else [],
                },
                adam_annotations=sec.adam_annotations[:10],
            ),
            programming_rules=prog_rules,
            traceability=Traceability(
                page_number=sec.page_start, section_id=sec.section_id,
                source_excerpt=truncate(title, 150), confidence=confidence,
            ),
            confidence_score=confidence,
        )

    @staticmethod
    def _match_pop(text: str, populations: List[Population]) -> Optional[Population]:
        """
        FIXED v5: No longer silently defaults to populations[0].
        Returns None if no clear match — avoids misclassifying PK/biomarker outputs.
        Marks match method on returned population for QC traceability.
        """
        tl = text.lower()
        # Strong match: explicit abbreviation in title
        for pop in sorted(populations, key=lambda p: p.hierarchy_order):
            if pop.abbreviation.lower() in tl:
                return pop
        # Medium match: label keyword in title
        for pop in sorted(populations, key=lambda p: p.hierarchy_order):
            if len(pop.label) > 3 and pop.label.lower() in tl:
                return pop
        # Weak match: keyword inference by output class context
        oc_pop_hints = {
            "pk": "PK", "pharmacokinetic": "PK",
            "safety": "SAF", "adverse": "SAF", "teae": "SAF",
            "efficacy": None, "primary": None,  # keep ITT/FAS as default for efficacy
        }
        for kw, abbrev in oc_pop_hints.items():
            if kw in tl and abbrev:
                matched = next((p for p in populations if p.abbreviation == abbrev), None)
                if matched: return matched
        # For efficacy-like titles: use the PRIMARY population (ITT/FAS) not populations[0]
        # populations[0] is sorted by hierarchy_order so is correct for efficacy
        efficacy_hints = ["change from baseline","efficacy","responder","ORR","PFS","OS","DFS"]
        if any(h in tl for h in efficacy_hints):
            primary_pop = next((p for p in populations if p.abbreviation in ("ITT","FAS","mITT","RAND","ENRL")), None)
            return primary_pop  # May be None if no primary pop — QC will flag it
        # No match at all — return None
        return None

    @staticmethod
    def _match_eps(title: str, endpoints: List[Endpoint]) -> List[Endpoint]:
        tl = title.lower()
        matched = []
        for ep in endpoints:
            words = [w for w in ep.description.lower().split() if len(w) > 4]
            if sum(1 for w in words if w in tl) >= 2:
                matched.append(ep)
        return matched[:3]
