"""
CTI Platform v6 — Streamlit Dashboard
Fixes from v5:
  - CRITICAL: Nested expander crash in ADaM Spec tab fixed
  - Random numbers stripped from TLF titles
  - Excel formula corruption fixed (_safe_cell)
  - Analytics tab fixed (try/except + correct chart data)
  - SAS metadata download button added
  - Timing definitions tab (TEAE, study day, follow-up)
  - ADaM variable registry table from Excel spec
  - Blank page after extraction fixed (no st.rerun mid-render)
  - Full color overhaul for dark theme readability
  - Readiness score explained inline
  - Population formal definitions improved
  - SAS code copy blocks throughout
"""
from __future__ import annotations
import hashlib, io, json, os, sys, tempfile, time
from collections import Counter, defaultdict
from pathlib import Path
from typing import List, Optional

import streamlit as st

sys.path.insert(0, str(Path(__file__).parent))

from src.models.schema import ClinicalIntelligenceSchema, OutputType, QCSeverity
from src.services import ExtractionPipeline, PipelineConfig
from src.export import ExportManager

st.set_page_config(
    page_title="CTI Platform v6",
    page_icon="⬡",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Global CSS — high-contrast dark theme ────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600&family=Inter:wght@300;400;600;700&display=swap');

/* Base */
html, body, [class*="css"] { font-family: 'Inter', system-ui, sans-serif; }
.stApp { background: #0d1117; color: #c9d1d9; }
.main .block-container { padding: 1.5rem 2rem; max-width: 1400px; }

/* Sidebar — clearly readable labels */
[data-testid="stSidebar"] {
  background: #161b22;
  border-right: 1px solid #30363d;
}
[data-testid="stSidebar"] label,
[data-testid="stSidebar"] .stMarkdown p,
[data-testid="stSidebar"] .stMarkdown div {
  color: #e6edf3 !important;
  font-size: 13px !important;
}
[data-testid="stSidebar"] .stCheckbox label { color: #c9d1d9 !important; }
[data-testid="stSidebar"] [data-testid="stSlider"] label { color: #e6edf3 !important; }
[data-testid="stSidebar"] [data-testid="stSlider"] .st-emotion-cache-1inwz65 { color: #58a6ff !important; }

/* Metrics */
[data-testid="stMetricValue"] {
  color: #58a6ff;
  font-family: 'IBM Plex Mono', monospace;
  font-size: 1.6rem;
}
[data-testid="stMetricLabel"] {
  color: #8b949e;
  font-size: .7rem;
  text-transform: uppercase;
  letter-spacing: .06em;
}
[data-testid="stMetric"] {
  background: #161b22;
  border: 1px solid #30363d;
  border-radius: 8px;
  padding: .75rem;
}

/* Tabs */
.stTabs [data-baseweb="tab-list"] {
  background: #161b22;
  border-bottom: 1px solid #30363d;
}
.stTabs [data-baseweb="tab"] {
  color: #8b949e;
  font-size: .82rem;
  padding: .6rem 1rem;
}
.stTabs [aria-selected="true"] {
  color: #58a6ff;
  border-bottom: 2px solid #58a6ff;
}

/* Expanders */
.streamlit-expanderHeader {
  background: #161b22;
  border: 1px solid #30363d;
  border-radius: 6px;
  color: #c9d1d9 !important;
  font-size: 13px;
}
.streamlit-expanderContent {
  background: #0d1117;
  border: 1px solid #21262d;
  border-top: none;
  border-radius: 0 0 6px 6px;
}

/* Progress */
.stProgress > div > div {
  background: linear-gradient(90deg, #238636, #1f6feb);
}

/* File uploader */
[data-testid="stFileUploaderDropzone"] {
  background: #161b22;
  border: 2px dashed #30363d;
  border-radius: 8px;
  color: #8b949e;
}

/* Buttons */
.stButton > button {
  background: #238636;
  color: #ffffff;
  border: 1px solid #2ea043;
  border-radius: 6px;
  font-weight: 600;
  font-size: 13px;
  padding: .45rem 1rem;
  transition: background .15s;
}
.stButton > button:hover { background: #2ea043; }

/* Download buttons */
.stDownloadButton > button {
  background: #21262d;
  color: #c9d1d9;
  border: 1px solid #30363d;
  border-radius: 6px;
  font-size: 12px;
  padding: .35rem .8rem;
}
.stDownloadButton > button:hover { background: #30363d; color: #e6edf3; }

/* Custom badges */
.badge-crit { background: rgba(248,81,73,.15); color: #f85149; border: 1px solid rgba(248,81,73,.4);
              padding: 2px 7px; border-radius: 4px; font-size: 11px; font-weight: 700; }
.badge-warn { background: rgba(210,153,34,.15); color: #d29922; border: 1px solid rgba(210,153,34,.4);
              padding: 2px 7px; border-radius: 4px; font-size: 11px; font-weight: 700; }
.badge-info { background: rgba(31,111,235,.15); color: #58a6ff; border: 1px solid rgba(31,111,235,.4);
              padding: 2px 7px; border-radius: 4px; font-size: 11px; font-weight: 700; }
.badge-ok   { background: rgba(35,134,54,.15);  color: #3fb950; border: 1px solid rgba(35,134,54,.4);
              padding: 2px 7px; border-radius: 4px; font-size: 11px; font-weight: 700; }

/* Section headers in sidebar */
.sec-hdr {
  font-family: 'IBM Plex Mono', monospace;
  font-size: .65rem;
  font-weight: 700;
  color: #8b949e;
  text-transform: uppercase;
  letter-spacing: .1em;
  margin: .5rem 0 .3rem;
  padding-bottom: 3px;
  border-bottom: 1px solid #21262d;
}

/* Upload label pill */
.upload-pill {
  display: inline-block;
  background: rgba(31,111,235,.15);
  color: #58a6ff;
  border: 1px solid rgba(31,111,235,.3);
  border-radius: 4px;
  font-size: 11px;
  font-weight: 700;
  padding: 2px 8px;
  margin-bottom: 4px;
  letter-spacing: .04em;
  text-transform: uppercase;
}

/* Tracked-changes banner */
.tracked-ok {
  background: rgba(35,134,54,.1);
  border: 1px solid rgba(35,134,54,.3);
  border-radius: 6px;
  padding: .4rem .8rem;
  font-size: 12px;
  color: #3fb950;
  margin-top: .5rem;
}

/* ADaM annotation chip */
.ann-chip {
  background: #1c2128;
  color: #a5d6ff;
  border: 1px solid rgba(88,166,255,.2);
  padding: 1px 6px;
  border-radius: 3px;
  font-family: 'IBM Plex Mono', monospace;
  font-size: 10px;
}

/* Reset button */
.reset-wrap > div > button {
  background: transparent !important;
  color: #f85149 !important;
  border: 1px solid rgba(248,81,73,.3) !important;
  font-size: 11px !important;
}

/* Code blocks */
.stCode { font-size: 11.5px !important; }

/* Dataframe */
[data-testid="stDataFrame"] { border: 1px solid #21262d; border-radius: 6px; }
</style>
""", unsafe_allow_html=True)

# ── Session state ─────────────────────────────────────────────────────────────
for k, v in {
    "schema": None, "error": None, "file_hash": None,
    "html_report": None, "excel_bytes": None, "sas_bytes": None,
}.items():
    if k not in st.session_state:
        st.session_state[k] = v


def _fhash(*files) -> str:
    h = hashlib.md5()
    for f in files:
        if f:
            h.update(f.getvalue()[:8192])
    return h.hexdigest()[:12]


def _conf_badge(s: float) -> str:
    if s >= .88:  return f'<span class="badge-ok">✓ {s:.0%}</span>'
    if s >= .70:  return f'<span class="badge-info">~ {s:.0%}</span>'
    if s >= .55:  return f'<span class="badge-warn">! {s:.0%}</span>'
    return f'<span class="badge-crit">✗ {s:.0%}</span>'


def _rc(score: float) -> str:
    return "#3fb950" if score >= .80 else "#d29922" if score >= .60 else "#f85149"


def _card(content_html: str, left_color: str = "#1f6feb") -> None:
    st.markdown(
        f'<div style="background:#161b22;border:1px solid #30363d;border-left:3px solid {left_color};'
        f'border-radius:0 6px 6px 0;padding:10px 14px;margin:6px 0;font-size:12px;">'
        f'{content_html}</div>',
        unsafe_allow_html=True,
    )


def _safe_cleanup(path: str) -> None:
    import shutil
    try:
        shutil.rmtree(path, ignore_errors=True)
    except Exception:
        pass


# ── Sidebar ───────────────────────────────────────────────────────────────────
def _sidebar():
    with st.sidebar:
        st.markdown(
            '<div style="padding:.6rem 0 .5rem;">'
            '<span style="font-size:18px;color:#58a6ff;">⬡</span>'
            '<span style="font-weight:700;font-size:14px;color:#e6edf3;margin-left:8px;">CTI Platform v6</span>'
            '<br><span style="font-size:10px;color:#8b949e;margin-left:26px;">SAP Intelligence · Multi-Document</span>'
            '</div>',
            unsafe_allow_html=True,
        )
        st.divider()

        # Primary SAP
        st.markdown('<div class="sec-hdr">📄 Primary SAP <span style="color:#f85149">★ required</span></div>',
                    unsafe_allow_html=True)
        sap_file = st.file_uploader(
            "SAP document", type=["docx", "rtf", "txt"],
            key="sap_up", label_visibility="collapsed",
            help="Main Statistical Analysis Plan (DOCX / RTF / TXT)",
        )

        # Optional documents
        st.markdown('<div class="sec-hdr" style="margin-top:.8rem;">📎 Optional Documents</div>',
                    unsafe_allow_html=True)

        st.markdown('<span class="upload-pill">🔗 TFL Shell / Mock Shell (DOCX)</span>', unsafe_allow_html=True)
        st.markdown(
            '<div style="font-size:11px;color:#6e7681;margin-bottom:3px;">'
            'Annotated mock-shell document with Table/Listing/Figure structure. '
            'Typically adds 40–100+ outputs.</div>',
            unsafe_allow_html=True,
        )
        shell_file = st.file_uploader(
            "TFL Shell", type=["docx", "rtf"],
            key="shell_up", label_visibility="collapsed",
        )

        st.markdown('<span class="upload-pill" style="margin-top:6px;display:inline-block;">📊 ADaM Variable Specification (XLSX)</span>',
                    unsafe_allow_html=True)
        st.markdown(
            '<div style="font-size:11px;color:#6e7681;margin-bottom:3px;">'
            'CDISC ADaM spec Excel or Define-XML source workbook. '
            'Improves dataset inference and adds variable-level derivation tables.</div>',
            unsafe_allow_html=True,
        )
        adam_file = st.file_uploader(
            "ADaM Spec", type=["xlsx", "xls"],
            key="adam_up", label_visibility="collapsed",
        )

        # Pipeline options
        st.markdown('<div class="sec-hdr" style="margin-top:.8rem;">⚙️ Pipeline Options</div>',
                    unsafe_allow_html=True)
        run_qc    = st.checkbox("Run QC Engine",       True, help="17 QC checks + readiness score")
        run_shell = st.checkbox("Parse Mock Shells",   True, help="Extract column structure from shell tables")
        parallel  = st.checkbox("Parallel Extraction", True, help="Concurrent entity extractors — faster")
        conf      = st.slider("Confidence Threshold", 0.50, 0.95, 0.65, 0.05,
                              format="%.2f",
                              help="Outputs below threshold shown with warning badge")

        # Export options
        st.markdown('<div class="sec-hdr" style="margin-top:.8rem;">📤 Export Options</div>',
                    unsafe_allow_html=True)
        exp_json = st.checkbox("Export JSON",  False)
        exp_xl   = st.checkbox("Export Excel", True,  help="Multi-sheet workbook: Outputs, Pops, Rules, Visits, ADaM variables")
        exp_html = st.checkbox("Export HTML",  True,  help="Interactive dark-theme HTML report")
        exp_sas  = st.checkbox("Export SAS",   False, help="SAS metadata JSON for downstream tooling")

        st.markdown("")
        run_btn  = st.button("⬡ Run Extraction", use_container_width=True, disabled=not bool(sap_file))
        demo_btn = st.button("⚡ Demo SAP",       use_container_width=True, help="Run on built-in 150-page fixture SAP")

        # Reset
        st.markdown("")
        st.markdown('<div class="reset-wrap">', unsafe_allow_html=True)
        reset_btn = st.button("🔄 Reset / New Study", use_container_width=True,
                              help="Clear results to start a new extraction")
        st.markdown("</div>", unsafe_allow_html=True)

        # Result summary
        schema = st.session_state.get("schema")
        if schema:
            meta  = schema.get("study_metadata", {}) or {}
            qc    = schema.get("qc_report", {}) or {}
            rs    = qc.get("overall_readiness_score", 0)
            color = _rc(rs)
            pid   = meta.get("protocol_id", "N/A")
            st.divider()
            st.markdown(
                f'<div style="font-size:12px;color:#8b949e;line-height:2.1;">'
                f'<b style="color:#e6edf3;">{pid}</b><br>'
                f'Phase {meta.get("phase","?")} &nbsp;·&nbsp; '
                f'{"v" + meta.get("sap_version","") if meta.get("sap_version") else "vN/A"}<br>'
                f'{len(schema.get("outputs_master",[]))} outputs &nbsp;·&nbsp; '
                f'{len(schema.get("populations",[]))} pops<br>'
                f'{len(schema.get("endpoints",[]))} endpoints &nbsp;·&nbsp; '
                f'{len(schema.get("rule_engine_output",[]))} rules &nbsp;·&nbsp; '
                f'{len(schema.get("timing_definitions",[]))} timing defs'
                f'</div>',
                unsafe_allow_html=True,
            )
            st.markdown(
                f'<div style="margin-top:.5rem;padding:8px 12px;background:#0d1117;'
                f'border:1px solid #30363d;border-left:3px solid {color};border-radius:0 6px 6px 0;">'
                f'<div style="font-size:9px;color:#6e7681;text-transform:uppercase;letter-spacing:.08em;">QC Readiness</div>'
                f'<div style="font-size:1.5rem;font-family:\'IBM Plex Mono\',monospace;color:{color};font-weight:700;">'
                f'{rs:.0%}</div></div>',
                unsafe_allow_html=True,
            )

            st.divider()
            st.markdown('<div class="sec-hdr">⬇ Downloads</div>', unsafe_allow_html=True)

            st.download_button(
                "⬇ JSON Schema",
                data=json.dumps(schema, indent=2, default=str),
                file_name=f"cti_{pid}.json",
                mime="application/json",
                use_container_width=True,
            )
            html_rpt = st.session_state.get("html_report")
            if html_rpt:
                st.download_button(
                    "⬇ HTML Report",
                    data=html_rpt,
                    file_name=f"cti_report_{pid}.html",
                    mime="text/html",
                    use_container_width=True,
                )
            xl = st.session_state.get("excel_bytes")
            if xl:
                st.download_button(
                    "⬇ Excel Workbook",
                    data=xl,
                    file_name=f"cti_{pid}.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    use_container_width=True,
                )
            sas_b = st.session_state.get("sas_bytes")
            if sas_b:
                st.download_button(
                    "⬇ SAS Metadata (JSON)",
                    data=sas_b,
                    file_name=f"cti_sas_meta_{pid}.json",
                    mime="application/json",
                    use_container_width=True,
                )

    return (sap_file, shell_file, adam_file, run_btn, demo_btn, reset_btn,
            run_qc, run_shell, parallel, conf,
            exp_json, exp_xl, exp_html, exp_sas)


# ── Pipeline runners ──────────────────────────────────────────────────────────
def _run(sap_file, shell_file, adam_file, conf, run_qc, run_shell,
         parallel, exp_json, exp_xl, exp_html, exp_sas):
    key = _fhash(sap_file, shell_file, adam_file)
    if st.session_state.get("file_hash") == key and st.session_state.get("schema"):
        st.info("Showing cached result — click 🔄 Reset to run a new extraction.")
        return

    progress = st.progress(0.0, text="Starting…")
    status   = st.empty()

    def cb(msg, pct):
        try:
            progress.progress(min(float(pct), 1.0), text=msg)
            status.markdown(
                f'<div style="font-size:11px;color:#8b949e;">{msg}</div>',
                unsafe_allow_html=True,
            )
        except Exception:
            pass

    tmp_dir = tempfile.mkdtemp()
    try:
        paths = []
        for uf in [sap_file, shell_file, adam_file]:
            if uf:
                safe = uf.name.replace(" ", "_").replace("(", "").replace(")", "")
                p = Path(tmp_dir) / safe
                p.write_bytes(uf.getvalue())
                paths.append(p)

        export_dir = Path(tmp_dir) / "exports"
        export_dir.mkdir(exist_ok=True)

        config = PipelineConfig(
            confidence_threshold=conf,
            run_qc=run_qc,
            run_mock_shell=run_shell,
            parallel_extraction=parallel,
            export_json=exp_json,
            export_excel=exp_xl,
            export_html=exp_html,
            export_sas=exp_sas,
            output_dir=export_dir,
            progress_callback=cb,
        )

        schema_obj  = ExtractionPipeline(config).run(paths)
        schema_dict = json.loads(schema_obj.model_dump_json())

        # Generate downloads in a second temp dir
        html_content  = None
        excel_content = None
        sas_content   = None
        try:
            tmp2 = tempfile.mkdtemp()
            em   = ExportManager(Path(tmp2))
            html_path = em.export_html_report(schema_obj)
            html_content  = html_path.read_text(encoding="utf-8")
            xl_path = em.export_excel(schema_obj)
            excel_content = xl_path.read_bytes()
            sas_path = em.export_sas_metadata(schema_obj)
            sas_content = sas_path.read_bytes()
            _safe_cleanup(tmp2)
        except Exception:
            pass

        st.session_state.update({
            "schema":      schema_dict,
            "file_hash":   key,
            "html_report": html_content,
            "excel_bytes": excel_content,
            "sas_bytes":   sas_content,
            "error":       None,
        })
        progress.progress(1.0, text="Complete ✓")
        status.empty()

    except Exception as exc:
        import traceback
        st.session_state["error"] = f"{exc}\n\n{traceback.format_exc()[-800:]}"
        progress.empty()
        status.empty()
    finally:
        _safe_cleanup(tmp_dir)


def _run_demo():
    sap = Path("tests/fixtures/mock_saps/sap_large_150page.docx")
    if not sap.exists():
        candidates = sorted(Path("tests/fixtures/mock_saps").glob("*.docx"))
        sap = candidates[-1] if candidates else None
    if not sap:
        st.error("No demo fixture found.")
        return

    config = PipelineConfig(run_qc=True, run_mock_shell=True, parallel_extraction=True)
    schema_obj  = ExtractionPipeline(config).run([sap])
    schema_dict = json.loads(schema_obj.model_dump_json())

    html_content  = None
    excel_content = None
    sas_content   = None
    try:
        tmp = tempfile.mkdtemp()
        em  = ExportManager(Path(tmp))
        html_content  = em.export_html_report(schema_obj).read_text(encoding="utf-8")
        excel_content = em.export_excel(schema_obj).read_bytes()
        sas_content   = em.export_sas_metadata(schema_obj).read_bytes()
        _safe_cleanup(tmp)
    except Exception:
        pass

    st.session_state.update({
        "schema":      schema_dict,
        "file_hash":   "demo",
        "html_report": html_content,
        "excel_bytes": excel_content,
        "sas_bytes":   sas_content,
        "error":       None,
    })


# ── Header ────────────────────────────────────────────────────────────────────
def _header(schema):
    if schema:
        meta    = schema.get("study_metadata", {}) or {}
        sys_ms  = schema.get("execution_time_ms", 0)
        tracked = schema.get("tracked_changes_stripped", False)
        annots  = schema.get("inline_annotations_count", 0)

        parts = [
            f'Protocol: <span style="color:#c9d1d9;">{meta.get("protocol_id","N/A")}</span>',
            f'Phase: <span style="color:#c9d1d9;">{meta.get("phase","?")}</span>',
        ]
        if meta.get("sap_version"):
            parts.append(f'SAP v<span style="color:#c9d1d9;">{meta["sap_version"]}</span>')
        if meta.get("amendment_number"):
            parts.append(f'Amend: <span style="color:#c9d1d9;">{meta["amendment_number"]}</span>')
        parts.append(f'NCT: <span style="color:#c9d1d9;">{meta.get("nct_number","N/A")}</span>')

        meta_line = " &nbsp;·&nbsp; ".join(parts)
        t_html    = (f'<div class="tracked-ok">✓ Tracked changes (strikethrough) stripped</div>'
                     if tracked else "")
        a_html    = (f'<div style="font-size:11px;color:#a5d6ff;margin-top:4px;">'
                     f'📎 {annots} inline ADaM annotations</div>' if annots else "")
        time_html = f'<div style="font-size:10px;color:#6e7681;">Extracted in {sys_ms:,} ms</div>' if sys_ms else ""

        title = (meta.get("study_title") or "Clinical Trial SAP Analysis")[:120]

        st.markdown(
            f'<div style="background:linear-gradient(135deg,#161b22,#1c2128);'
            f'border:1px solid #30363d;border-radius:10px;padding:1rem 1.4rem;margin-bottom:1rem;">'
            f'<div style="display:flex;justify-content:space-between;align-items:flex-start;">'
            f'<div>'
            f'<div style="font-size:1rem;font-weight:700;color:#e6edf3;margin-bottom:3px;">{title}</div>'
            f'<div style="font-size:11px;color:#6e7681;">{meta_line}</div>'
            f'</div>{time_html}</div>'
            f'{t_html}{a_html}</div>',
            unsafe_allow_html=True,
        )
    else:
        st.markdown(
            '<div style="background:linear-gradient(135deg,#161b22,#1c2128);'
            'border:1px solid #30363d;border-radius:10px;padding:2rem;'
            'text-align:center;margin-bottom:1rem;">'
            '<div style="font-size:2rem;margin-bottom:.4rem;">⬡</div>'
            '<div style="font-size:1.15rem;font-weight:700;color:#e6edf3;margin-bottom:.4rem;">'
            'Clinical Trial Intelligence Platform v6</div>'
            '<div style="font-size:12px;color:#6e7681;max-width:580px;margin:0 auto;">'
            'Upload a SAP (DOCX/RTF/TXT) + optional TFL Shell + ADaM Spec Excel. '
            'Extracts outputs, populations, endpoints, programming rules, timing definitions, '
            'and study day conventions. Pattern-based, no LLM required.</div></div>',
            unsafe_allow_html=True,
        )


# ── Metrics ───────────────────────────────────────────────────────────────────
def _metrics(schema):
    qc   = schema.get("qc_report") or {}
    rs   = qc.get("overall_readiness_score", 0)
    cols = st.columns(10)
    vals = [
        ("Outputs",     len(schema.get("outputs_master", []))),
        ("Populations", len(schema.get("populations", []))),
        ("Endpoints",   len(schema.get("endpoints", []))),
        ("Rules",       len(schema.get("rule_engine_output", []))),
        ("Timing",      len(schema.get("timing_definitions", []))),
        ("Visits",      len(schema.get("visit_schedule", []))),
        ("Sections",    len(schema.get("sections", []))),
        ("ADaM Annots", schema.get("inline_annotations_count", 0)),
        ("QC Errors",   qc.get("errors", 0)),
        ("Readiness",   f"{rs:.0%}"),
    ]
    for col, (lbl, val) in zip(cols, vals):
        with col:
            st.metric(lbl, val)


# ── Tab: Outputs ──────────────────────────────────────────────────────────────
def _tab_outputs(schema):
    import pandas as pd

    outs = schema.get("outputs_master", [])
    if not outs:
        st.warning("No outputs extracted. Verify SAP contains Table/Listing/Figure entries.")
        return

    c1, c2, c3, c4 = st.columns([2, 2, 2, 2])
    with c1:
        type_f = st.multiselect("Type", ["Table","Listing","Figure"],
                                default=["Table","Listing","Figure"], key="of_type")
    with c2:
        pops_a = sorted({(o.get("population") or {}).get("abbreviation","?")
                         for o in outs if o.get("population")})
        pop_f  = st.multiselect("Population", pops_a, default=pops_a, key="of_pop")
    with c3:
        cls_a = sorted({o.get("output_class","Other") for o in outs})
        cls_f = st.multiselect("Class", cls_a, default=cls_a, key="of_cls")
    with c4:
        conf_f = st.slider("Min Confidence", 0.0, 1.0, 0.0, 0.05, key="of_conf")

    filtered = [
        o for o in outs
        if o.get("output_type","Table") in type_f
        and o.get("output_class","Other") in cls_f
        and (not pops_a or (o.get("population") or {}).get("abbreviation","?") in pop_f)
        and o.get("confidence_score", 0) >= conf_f
    ]

    tc = Counter(o.get("output_type","Table") for o in filtered)
    st.caption(
        f"Showing **{len(filtered)}/{len(outs)}** — "
        f"Tables: {tc.get('Table',0)}, Listings: {tc.get('Listing',0)}, Figures: {tc.get('Figure',0)}"
    )

    # Class breakdown
    if filtered:
        cc = Counter(o.get("output_class","Other") for o in filtered)
        df_cc = pd.DataFrame({"Class": list(cc.keys()), "Count": list(cc.values())}).sort_values("Count", ascending=False)
        with st.expander("📊 Output Class Breakdown", expanded=False):
            st.bar_chart(df_cc.set_index("Class"), height=180)

    icon_map = {"Table":"▦","Listing":"≡","Figure":"◈"}
    cls_colors = {
        "PK":"#d29922","Safety":"#f85149","Efficacy":"#ff7b72",
        "Demographics":"#58a6ff","Disposition":"#79c0ff","Laboratory":"#56d364",
        "ECG":"#3fb950","QoL":"#bc8cff","Immunogenicity":"#e3b341",
        "Biomarker":"#ffa657","Subgroup":"#a5d6ff","Exposure":"#f0883e","Other":"#8b949e",
    }

    for o in filtered:
        pop      = (o.get("population") or {}).get("abbreviation","—")
        pop_flag = (o.get("population") or {}).get("adam_flag_variable","")
        ds_list  = (o.get("data_specification") or {}).get("input_datasets",[])
        mth_list = (o.get("analysis") or {}).get("methods",[])
        icon     = icon_map.get(o.get("output_type","Table"),"▦")
        oc       = o.get("output_class","Other")
        oc_col   = cls_colors.get(oc,"#8b949e")
        title    = o.get("title") or ""
        shell_fl = " 🔗" if o.get("from_shell_doc") else ""

        with st.expander(f"{icon} **{o.get('output_number','?')}** — {title[:90]}{shell_fl}"):
            ca, cb, cc_col = st.columns([3, 2, 1])
            with ca:
                ds_chips = " ".join(
                    f'<code style="font-size:10px;background:#1c2128;'
                    f'border:1px solid #30363d;padding:1px 5px;border-radius:3px;">{d}</code>'
                    for d in ds_list[:6]
                ) or "—"
                flag_code = (
                    f'<code style="font-size:10px;color:#58a6ff;background:#0d1117;'
                    f'padding:1px 5px;border-radius:3px;margin-left:6px;">{pop_flag}=\'Y\'</code>'
                    if pop_flag else ""
                )
                st.markdown(
                    f'<div style="font-size:12px;line-height:2.1;color:#8b949e;">'
                    f'<b style="color:#c9d1d9;">Full Title:</b> <span style="color:#e6edf3;">{title}</span><br>'
                    f'<b style="color:#c9d1d9;">Type:</b> {o.get("output_type","?")} '
                    f'<span style="background:{oc_col}22;color:{oc_col};border:1px solid {oc_col}44;'
                    f'padding:1px 7px;border-radius:3px;font-size:10px;font-weight:700;">{oc}</span><br>'
                    f'<b style="color:#c9d1d9;">Population:</b> {pop}{flag_code}<br>'
                    f'<b style="color:#c9d1d9;">Methods:</b> {", ".join(mth_list[:3]) or "—"}<br>'
                    f'<b style="color:#c9d1d9;">Datasets:</b> {ds_chips}</div>',
                    unsafe_allow_html=True,
                )
            with cb:
                rules = o.get("programming_rules", [])[:5]
                if rules:
                    st.markdown(
                        '<div style="font-size:10px;color:#6e7681;margin-bottom:4px;">⚡ Rules</div>',
                        unsafe_allow_html=True,
                    )
                    for r in rules:
                        st.markdown(
                            f'<div style="font-family:\'IBM Plex Mono\',monospace;font-size:10px;'
                            f'background:#0d1117;border-left:2px solid #f0883e;'
                            f'padding:3px 7px;margin-bottom:3px;color:#c9d1d9;border-radius:0 4px 4px 0;">'
                            f'{r.get("rule","")}</div>',
                            unsafe_allow_html=True,
                        )
                        if r.get("sas_hint"):
                            st.code(r["sas_hint"], language="sas")
            with cc_col:
                st.markdown(_conf_badge(o.get("confidence_score",0)), unsafe_allow_html=True)
                vs = o.get("verification_status","unverified")
                vs_color = {"programmer_ready":"#3fb950","needs_review":"#d29922",
                            "unverified":"#6e7681","not_implementable":"#f85149"}.get(vs,"#6e7681")
                st.markdown(
                    f'<div style="font-size:9px;color:{vs_color};margin-top:3px;'
                    f'font-weight:600;">{vs.replace("_"," ").upper()}</div>',
                    unsafe_allow_html=True,
                )
                sig = o.get("analysis_signature")
                if sig and sig.get("outcome_concept"):
                    st.markdown(
                        f'<div style="font-size:9px;color:#6e7681;margin-top:3px;'
                        f'font-family:monospace;">sig:{(sig.get("outcome_concept","")[:20])}</div>',
                        unsafe_allow_html=True,
                    )
                if o.get("from_shell_doc"):
                    st.markdown(
                        '<span style="font-size:10px;color:#3fb950;">🔗 Shell</span>',
                        unsafe_allow_html=True,
                    )
                page = (o.get("traceability") or {}).get("page_number")
                if page:
                    st.markdown(
                        f'<div style="font-size:10px;color:#6e7681;margin-top:4px;">~p.{page}</div>',
                        unsafe_allow_html=True,
                    )


# ── Tab: Populations ──────────────────────────────────────────────────────────
def _tab_populations(schema):
    import pandas as pd

    pops = schema.get("populations", [])
    if not pops:
        st.warning("No populations extracted.")
        return

    n_dyn = sum(1 for p in pops if p.get("is_dynamic"))
    st.caption(f"{len(pops)-n_dyn} fixed + {n_dyn} dynamic populations")

    # Summary table
    rows = [{
        "Abbrev":     p.get("abbreviation",""),
        "Label":      p.get("label",""),
        "Flag":       p.get("adam_flag_variable",""),
        "Dataset":    p.get("adam_dataset","ADSL"),
        "Derivation": p.get("derivation_rule","")[:60],
        "Confidence": f'{p.get("confidence",0):.0%}',
        "Dynamic":    "✓" if p.get("is_dynamic") else "",
    } for p in pops]
    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
    st.markdown("")

    for pop in pops:
        dyn = " 🏷️" if pop.get("is_dynamic") else ""
        flag    = pop.get("adam_flag_variable","N/A")
        label   = pop.get("label","")
        abbrev  = pop.get("abbreviation","")
        deriv   = pop.get("derivation_rule","N/A")
        defn    = pop.get("formal_definition","")
        incl    = pop.get("inclusion_criteria","")

        with st.expander(f"👥 **{abbrev}** — {label}{dyn}"):
            ca, cb = st.columns([3, 1])
            with ca:
                st.markdown(
                    f'<div style="font-size:12px;line-height:2.2;color:#8b949e;">'
                    f'<b style="color:#c9d1d9;">ADaM Flag:</b> '
                    f'<code style="background:#0d1117;color:#58a6ff;padding:2px 8px;border-radius:3px;">'
                    f'{flag} = \'Y\'</code><br>'
                    f'<b style="color:#c9d1d9;">Dataset:</b> {pop.get("adam_dataset","ADSL")}<br>'
                    f'<b style="color:#c9d1d9;">Derivation:</b> '
                    f'<code style="background:#0d1117;color:#3fb950;font-size:10px;'
                    f'padding:2px 6px;border-radius:3px;">{deriv}</code></div>',
                    unsafe_allow_html=True,
                )
                st.code(f"where {flag} = 'Y';  /* {label} */", language="sas")
                if defn:
                    st.markdown(
                        f'<div style="background:#0d1117;border-left:3px solid #bc8cff;'
                        f'border-radius:0 5px 5px 0;padding:7px 12px;margin-top:6px;'
                        f'font-size:11px;color:#8b949e;font-style:italic;">'
                        f'<b style="color:#c9d1d9;font-style:normal;">Definition:</b><br>{defn[:400]}</div>',
                        unsafe_allow_html=True,
                    )
                if incl:
                    st.markdown(
                        f'<div style="background:#0d1117;border-left:3px solid #3fb950;'
                        f'border-radius:0 5px 5px 0;padding:7px 12px;margin-top:4px;'
                        f'font-size:11px;color:#8b949e;">'
                        f'<b style="color:#c9d1d9;">Inclusion:</b> {incl[:300]}</div>',
                        unsafe_allow_html=True,
                    )
            with cb:
                st.markdown(_conf_badge(pop.get("confidence",0)), unsafe_allow_html=True)


# ── Tab: Endpoints ────────────────────────────────────────────────────────────
def _tab_endpoints(schema):
    eps = schema.get("endpoints", [])
    if not eps:
        st.warning(
            "No endpoints extracted. "
            "Verify SAP has a Primary/Secondary Objective-Endpoint section "
            "or a 2-column table with those headings."
        )
        return

    from_tbl = sum(1 for e in eps if e.get("from_table"))
    st.caption(f"{from_tbl} from structured tables · {len(eps)-from_tbl} from prose · {len(eps)} total")

    cls_order  = ["Primary","Key Secondary","Secondary","PK","PD","Safety","Exploratory"]
    cls_colors = {
        "Primary":"#ff7b72","Key Secondary":"#f0883e","Secondary":"#58a6ff",
        "PK":"#d29922","PD":"#3fb950","Safety":"#f85149","Exploratory":"#bc8cff",
    }
    grouped = defaultdict(list)
    for ep in eps:
        grouped[ep.get("classification","Secondary")].append(ep)

    for cls in cls_order + [c for c in grouped if c not in cls_order]:
        grp = grouped.get(cls, [])
        if not grp:
            continue
        color = cls_colors.get(cls, "#8b949e")
        st.markdown(
            f'<div style="font-size:12px;font-weight:700;color:{color};'
            f'margin:14px 0 6px;border-left:3px solid {color};padding-left:8px;">'
            f'{cls} Endpoints ({len(grp)})</div>',
            unsafe_allow_html=True,
        )
        for ep in grp:
            src  = "📊" if ep.get("from_table") else "📄"
            desc = ep.get("description","")
            with st.expander(f"{src} {desc[:85]}"):
                st.markdown(
                    f'<div style="font-size:12px;color:#c9d1d9;line-height:1.7;">'
                    f'<b>Full description:</b><br>{desc}</div>',
                    unsafe_allow_html=True,
                )
                if ep.get("timepoints"):
                    st.markdown(
                        f'<div style="font-size:11px;color:#56d364;margin-top:5px;">'
                        f'⏱ Timepoints: {", ".join(ep["timepoints"][:6])}</div>',
                        unsafe_allow_html=True,
                    )
                if ep.get("adam_variables"):
                    chips = " ".join(
                        f'<code style="font-size:10px;background:#1c2128;'
                        f'color:#a5d6ff;padding:1px 5px;border-radius:3px;">{v}</code>'
                        for v in ep["adam_variables"][:8]
                    )
                    st.markdown(
                        f'<div style="font-size:11px;color:#8b949e;margin-top:4px;">'
                        f'ADaM: {chips}</div>',
                        unsafe_allow_html=True,
                    )
                st.markdown(_conf_badge(ep.get("confidence",0)), unsafe_allow_html=True)


# ── Tab: Rules ────────────────────────────────────────────────────────────────
def _tab_rules(schema):
    rules = schema.get("rule_engine_output", [])
    if not rules:
        st.warning("No programming rules extracted.")
        return

    rt_all = sorted({r.get("rule_type","") for r in rules})
    c1, c2 = st.columns(2)
    with c1:
        sel = st.multiselect("Filter by Rule Type", rt_all, default=rt_all, key="rt_type")
    with c2:
        ds_all = sorted({d for r in rules for d in r.get("applies_to_datasets",[])})
        ds_sel = st.multiselect("Filter by Dataset", ["All"] + ds_all,
                                default=["All"], key="rt_ds")

    filtered = [r for r in rules if r.get("rule_type","") in sel]
    if "All" not in ds_sel and ds_sel:
        filtered = [r for r in filtered
                    if any(d in ds_sel for d in r.get("applies_to_datasets",[]))]
    st.caption(f"{len(filtered)} rules")

    col_map = {
        "baseline_definition":"#bc8cff","date_imputation":"#f0883e",
        "censoring":"#f85149","filter":"#58a6ff","derivation":"#3fb950",
        "flag":"#79c0ff","LOCF":"#ff7b72","BOCF":"#d29922",
        "inline_annotation":"#a5d6ff","study_day":"#8b949e",
        "pk_rule":"#e3b341","visit_window":"#56d364","timing_definition":"#ffa657",
    }

    for r in filtered:
        rt    = r.get("rule_type","")
        color = col_map.get(rt,"#8b949e")
        snip  = r.get("rule_text_verbatim","")[:70]
        with st.expander(f"[{rt}] {snip}…"):
            ca, cb = st.columns([3, 1])
            with ca:
                st.markdown(
                    f'<div style="font-size:11px;color:#8b949e;font-style:italic;margin-bottom:5px;">'
                    f'{r.get("rule_text_verbatim","")}</div>',
                    unsafe_allow_html=True,
                )
                if r.get("pseudocode"):
                    st.code(r["pseudocode"], language="sas")
                v_str = ", ".join(r.get("applies_to_variables",[])[:6]) or "—"
                d_str = ", ".join(r.get("applies_to_datasets",[])[:5]) or "—"
                st.markdown(
                    f'<div style="font-size:10px;color:#6e7681;margin-top:4px;">'
                    f'Vars: <span style="color:{color};">{v_str}</span> &nbsp;·&nbsp; Datasets: {d_str}</div>',
                    unsafe_allow_html=True,
                )
            with cb:
                st.markdown(_conf_badge(r.get("confidence",0)), unsafe_allow_html=True)


# ── Tab: Timing Definitions ───────────────────────────────────────────────────
def _tab_timing(schema):
    import pandas as pd

    timing = schema.get("timing_definitions", [])
    if not timing:
        st.info(
            "No timing definitions extracted. "
            "Ensure the SAP contains study day conventions, TEAE window definitions, "
            "or follow-up period specifications."
        )
        return

    cat_colors = {
        "study_day_anchor":"#58a6ff","ady_formula":"#79c0ff",
        "teae_window":"#f85149","days_after_last_dose":"#f0883e",
        "followup_definition":"#3fb950","on_treatment_period":"#56d364",
        "washout_definition":"#d29922","ldreld_derivation":"#e3b341",
    }

    cat_counts = Counter(t.get("category","") for t in timing)
    st.caption(f"{len(timing)} timing definitions across {len(cat_counts)} categories")

    # Summary table
    rows = [{
        "Category":    t.get("category",""),
        "Description": t.get("description",""),
        "ADaM Vars":   ", ".join(t.get("adam_variables",[])[:4]),
        "Section":     t.get("source_section",""),
        "Conf":        f'{t.get("confidence",0):.0%}',
    } for t in timing]
    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
    st.markdown("")

    for t in timing:
        cat   = t.get("category","")
        color = cat_colors.get(cat,"#8b949e")
        desc  = t.get("description","")
        vars_ = t.get("adam_variables",[])
        ps    = t.get("sas_pseudocode","")

        with st.expander(
            f'<span style="color:{color};">[{cat}]</span> {desc}',
            expanded=False,
        ):
            if vars_:
                chips = " ".join(
                    f'<code style="font-size:10px;background:#1c2128;'
                    f'color:{color};padding:1px 5px;border-radius:3px;">{v}</code>'
                    for v in vars_
                )
                st.markdown(
                    f'<div style="font-size:11px;color:#8b949e;margin-bottom:6px;">'
                    f'ADaM variables: {chips}</div>',
                    unsafe_allow_html=True,
                )
            if ps:
                st.code(ps, language="sas")
            sec = t.get("source_section","")
            if sec:
                st.markdown(
                    f'<div style="font-size:10px;color:#6e7681;">Source section: {sec}</div>',
                    unsafe_allow_html=True,
                )


# ── Tab: Visits ───────────────────────────────────────────────────────────────
def _tab_visits(schema):
    import pandas as pd

    visits = schema.get("visit_schedule", [])
    if not visits:
        st.info("No visit schedule extracted.")
        return

    rows = [{
        "Label":   v.get("visit_label",""),
        "Type":    v.get("visit_type",""),
        "Nominal": v.get("nominal_day","—"),
        "Window":  (f"-{v['window_pre_days']}/+{v['window_post_days']}"
                    if v.get("window_pre_days") is not None else "—"),
        "AVISIT":  v.get("adam_visit_value",""),
        "AVISITN": v.get("adam_visitnum",""),
        "Analysis":"✓" if v.get("analysis_visit_flag") else "",
        "Primary": "⭐" if v.get("primary_timepoint") else "",
        "Conf":    f'{v.get("confidence",0):.2f}',
    } for v in visits]
    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)


# ── Tab: QC Report ────────────────────────────────────────────────────────────
def _tab_qc(schema):
    import pandas as pd

    qc = schema.get("qc_report")
    if not qc:
        st.warning("QC engine not run.")
        return

    rs    = qc.get("overall_readiness_score", 0)
    color = _rc(rs)

    c1, c2, c3, c4, c5, c6 = st.columns(6)
    with c1:
        st.markdown(
            f'<div style="background:#161b22;border:2px solid {color};'
            f'border-radius:8px;padding:10px;text-align:center;">'
            f'<div style="font-size:1.5rem;font-family:\'IBM Plex Mono\',monospace;'
            f'color:{color};font-weight:700;">{rs:.0%}</div>'
            f'<div style="font-size:10px;color:#6e7681;text-transform:uppercase;">Readiness</div>'
            f'</div>',
            unsafe_allow_html=True,
        )
    for col, val, lbl in [
        (c2, f'{qc.get("completeness_pct",0):.0f}%', "Completeness"),
        (c3, qc.get("errors",0),   "Errors"),
        (c4, qc.get("warnings",0), "Warnings"),
        (c5, qc.get("infos",0),    "Info"),
        (c6, qc.get("low_confidence_count",0), "Low Conf"),
    ]:
        with col:
            st.metric(lbl, val)

    st.markdown("")
    # Readiness formula explanation
    with st.expander("ℹ️ How readiness is calculated"):
        st.markdown(
            """
            ```
            base  = 1.0
            base -= errors   × 0.06   # errors penalise heavily
            base -= warnings × 0.02
            base -= (low_conf_outputs / total_outputs) × 0.15
            base += 0.05 if endpoints extracted
            base += 0.05 if rules extracted
            base += 0.03 if tracked_changes_stripped
            readiness = max(0.0, min(1.0, base))
            ```
            80%+ = programmer-ready · 60–79% = needs review · <60% = significant gaps
            """,
        )

    issues = qc.get("issues", [])
    c_a, c_b = st.columns(2)
    with c_a:
        sev_f = st.multiselect("Severity", ["ERROR","WARNING","INFO"],
                               default=["ERROR","WARNING"], key="qc_sev")
    with c_b:
        cats  = sorted({i.get("category","") for i in issues})
        cat_f = st.multiselect("Category", ["All"] + cats, default=["All"], key="qc_cat")

    shown = [i for i in issues if i.get("severity","") in sev_f]
    if "All" not in cat_f and cat_f:
        shown = [i for i in shown if i.get("category","") in cat_f]

    sev_cls = {"ERROR":"badge-crit","WARNING":"badge-warn","INFO":"badge-info"}
    for i in shown:
        sev = i.get("severity","INFO")
        bd  = sev_cls.get(sev,"badge-info")
        fix = i.get("suggested_fix","")
        st.markdown(
            f'<div style="background:#161b22;border:1px solid #21262d;border-radius:6px;'
            f'padding:.5rem .8rem;margin-bottom:.4rem;font-size:12px;">'
            f'<span class="{bd}">{sev}</span>'
            f'<span style="color:#6e7681;margin-left:.5rem;font-size:10px;">{i.get("category","")}</span>'
            f'<span style="color:#c9d1d9;margin-left:.75rem;">{i.get("message","")}</span>'
            f'{"<div style=\'font-size:10px;color:#6e7681;margin-top:3px;\'>💡 " + fix + "</div>" if fix else ""}'
            f'</div>',
            unsafe_allow_html=True,
        )

    if not shown:
        st.success("✓ No issues at selected severity.")

    # Verification status summary (Blueprint Step 10)
    outs = schema.get("outputs_master",[])
    if outs:
        vs_counts = Counter(o.get("verification_status","unverified") for o in outs)
        st.markdown("")
        st.markdown("**Analysis Verification Status** *(Blueprint Step 10)*")
        vs_cols = st.columns(4)
        for col, (status, color) in zip(vs_cols, [
            ("programmer_ready","#3fb950"),("needs_review","#d29922"),
            ("unverified","#8b949e"),("not_implementable","#f85149"),
        ]):
            with col:
                cnt = vs_counts.get(status, 0)
                st.markdown(
                    f'<div style="background:#161b22;border:1px solid #30363d;'
                    f'border-left:3px solid {color};border-radius:4px;'
                    f'padding:8px 10px;text-align:center;">'
                    f'<div style="font-size:1.3rem;font-family:monospace;color:{color};font-weight:700;">{cnt}</div>'
                    f'<div style="font-size:9px;color:#6e7681;text-transform:uppercase;">'
                    f'{status.replace("_"," ")}</div></div>',
                    unsafe_allow_html=True,
                )

    if issues:
        with st.expander("📊 Issue breakdown by category"):
            cat_c = Counter(i.get("category","Other") for i in issues)
            df_c  = pd.DataFrame({"Category": list(cat_c.keys()),
                                   "Count": list(cat_c.values())}).sort_values("Count", ascending=False)
            st.bar_chart(df_c.set_index("Category"), height=200)


# ── Tab: ADaM Spec — FIXED (no nested expanders) ─────────────────────────────
def _tab_adam(schema):
    import pandas as pd

    ds_map: dict = defaultdict(lambda: {"outputs":[], "pops":set(), "rules":0})
    for o in schema.get("outputs_master",[]):
        ds_spec  = o.get("data_specification") or {}
        pop_abbr = (o.get("population") or {}).get("abbreviation","")
        for ds in (ds_spec.get("input_datasets") or []):
            ds_map[ds]["outputs"].append(o.get("output_number","?"))
            if pop_abbr:
                ds_map[ds]["pops"].add(pop_abbr)
    for r in schema.get("rule_engine_output",[]):
        for ds in r.get("applies_to_datasets",[]):
            ds_map[ds]["rules"] += 1

    icons = {
        "ADSL":"👤","ADAE":"⚠️","ADLB":"🧪","ADEFF":"🎯","ADTTE":"⏱️",
        "ADPK":"💊","ADVS":"❤️","ADQS":"📋","ADCM":"💉","ADEX":"📊",
        "ADPC":"🔬","ADPP":"📈","ADRS":"🏥","ADIE":"🔬","ADEG":"💓",
        "ADNCA":"⚗️","ADPD":"🧬","ADBDS":"🔭",
    }

    st.markdown(
        f'<b>{len(ds_map)} ADaM datasets</b> referenced across '
        f'{len(schema.get("outputs_master",[]))} outputs',
        unsafe_allow_html=True,
    )

    if ds_map:
        df_u = pd.DataFrame([
            {"Dataset": ds, "Outputs": len(info["outputs"]), "Rules": info["rules"]}
            for ds, info in sorted(ds_map.items(), key=lambda x: -len(x[1]["outputs"]))
        ])
        with st.expander("📊 Dataset Usage Overview", expanded=True):
            st.bar_chart(df_u.set_index("Dataset")[["Outputs","Rules"]], height=220)

    for ds_name, info in sorted(ds_map.items(), key=lambda x: -len(x[1]["outputs"])):
        icon = icons.get(ds_name,"🗃️")
        pops_str = ", ".join(sorted(info["pops"])) or "—"
        with st.expander(
            f'{icon} **{ds_name}** — {len(info["outputs"])} outputs · '
            f'{info["rules"]} rules · pops: {pops_str}'
        ):
            # Output numbers
            if info["outputs"]:
                nums = sorted(info["outputs"])[:20]
                chips = " ".join(
                    f'<code style="font-size:10px;background:#1c2128;'
                    f'border:1px solid #30363d;padding:1px 4px;border-radius:3px;">{n}</code>'
                    for n in nums
                )
                more = f" +{len(info['outputs'])-20}" if len(info["outputs"]) > 20 else ""
                st.markdown(
                    f'<div style="font-size:11px;margin-bottom:5px;">Outputs: {chips}{more}</div>',
                    unsafe_allow_html=True,
                )

            # Variable references from rules — use plain markdown/code, NOT expander
            ds_rules = [r for r in schema.get("rule_engine_output",[])
                        if ds_name in r.get("applies_to_datasets",[])]
            if ds_rules:
                var_set = sorted({v for r in ds_rules for v in r.get("applies_to_variables",[])})
                var_chips = " ".join(
                    f'<code style="font-size:9px;background:#0d1117;color:#a5d6ff;'
                    f'padding:1px 5px;border-radius:3px;border:1px solid #30363d44;">{v}</code>'
                    for v in var_set
                )
                st.markdown(
                    f'<div style="font-size:10px;color:#6e7681;margin-bottom:4px;">'
                    f'Referenced variables:</div>{var_chips}',
                    unsafe_allow_html=True,
                )

                # Programming rules — use markdown table, NOT nested expander
                st.markdown(
                    f'<div style="font-size:10px;color:#6e7681;margin-top:8px;margin-bottom:4px;">'
                    f'⚡ {len(ds_rules)} Programming Rules for {ds_name}:</div>',
                    unsafe_allow_html=True,
                )
                for r in ds_rules[:8]:
                    rt  = r.get("rule_type","")
                    txt = r.get("rule_text_verbatim","")[:100]
                    st.markdown(
                        f'<div style="font-family:\'IBM Plex Mono\',monospace;font-size:10px;'
                        f'background:#0d1117;border-left:2px solid #1f6feb;'
                        f'padding:4px 8px;margin-bottom:3px;border-radius:0 4px 4px 0;color:#c9d1d9;">'
                        f'[{rt}] {txt}</div>',
                        unsafe_allow_html=True,
                    )
                    if r.get("pseudocode"):
                        st.code(r["pseudocode"], language="sas")

    # ADaM variable registry from spec Excel
    adam_reg = schema.get("adam_spec_registry")
    if adam_reg and adam_reg.get("datasets"):
        st.divider()
        file_name = adam_reg.get("file_name","unknown")
        n_ds   = len(adam_reg.get("datasets",{}))
        n_vars = sum(len(v) if isinstance(v, list) else
                     len(v.get("variables",[]) if isinstance(v, dict) else [])
                     for v in adam_reg.get("datasets",{}).values())
        st.markdown(
            f'### 📊 ADaM Spec Variable Registry\n'
            f'Source: `{file_name}` — **{n_ds} datasets**, **{n_vars} variables**',
        )
        for ds_name, ds_spec in sorted(adam_reg.get("datasets",{}).items()):
            variables = (ds_spec if isinstance(ds_spec, list) else
                         ds_spec.get("variables",[]) if isinstance(ds_spec, dict) else [])
            if not variables:
                continue
            # Use plain expander — NOT nested (we are already at top level here)
            with st.expander(f"🗃️ **{ds_name}** — {len(variables)} variables"):
                rows = []
                for v in variables[:60]:
                    if isinstance(v, dict):
                        rows.append({
                            "Variable":   v.get("variable",""),
                            "Label":      (v.get("label","") or "")[:50],
                            "Type":       v.get("type",""),
                            "Origin":     v.get("origin",""),
                            "Core":       v.get("core",""),
                            "Derivation": (v.get("derivation_text","") or "")[:70],
                        })
                if rows:
                    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
                if len(variables) > 60:
                    st.caption(f"Showing 60/{len(variables)} variables. Full list in Excel download.")


# ── Tab: Analytics ────────────────────────────────────────────────────────────
def _tab_analytics(schema):
    import pandas as pd

    outs = schema.get("outputs_master", [])
    if not outs:
        st.info("No outputs to analyse.")
        return

    try:
        c1, c2 = st.columns(2)

        with c1:
            # Output type
            st.markdown("**Output Type Distribution**")
            tc = Counter(o.get("output_type","Table") for o in outs)
            st.bar_chart(
                pd.DataFrame({"Count": dict(tc)}).T,
                height=180,
            )

            # Output class
            st.markdown("**Output Class Distribution**")
            cc = Counter(o.get("output_class","Other") for o in outs)
            df_cc = pd.DataFrame({
                "Class": list(cc.keys()),
                "Count": list(cc.values()),
            }).sort_values("Count", ascending=False)
            st.bar_chart(df_cc.set_index("Class"), height=220)

        with c2:
            # Population coverage
            st.markdown("**Population Coverage**")
            pc = Counter(
                (o.get("population") or {}).get("abbreviation","None")
                for o in outs
            )
            df_pc = pd.DataFrame({
                "Population": list(pc.keys()),
                "Outputs":    list(pc.values()),
            }).sort_values("Outputs", ascending=False)
            st.bar_chart(df_pc.set_index("Population"), height=180)

            # Confidence distribution
            st.markdown("**Confidence Distribution**")
            bins = {"<55%":0, "55–70%":0, "70–88%":0, "≥88%":0}
            for o in outs:
                s = o.get("confidence_score", 0)
                if s < .55:   bins["<55%"]  += 1
                elif s < .70: bins["55–70%"] += 1
                elif s < .88: bins["70–88%"] += 1
                else:          bins["≥88%"]  += 1
            df_b = pd.DataFrame({"Band": list(bins.keys()), "Outputs": list(bins.values())})
            st.bar_chart(df_b.set_index("Band"), height=180)

        # Dataset × Population matrix
        st.markdown("**Dataset × Population Matrix** *(output count)*")
        ds_pop: dict = defaultdict(lambda: defaultdict(int))
        pops_seen: set = set()
        for o in outs:
            ds_list  = (o.get("data_specification") or {}).get("input_datasets",[])
            pop_abbr = (o.get("population") or {}).get("abbreviation","None")
            pops_seen.add(pop_abbr)
            for ds in ds_list[:4]:
                ds_pop[ds][pop_abbr] += 1
        if ds_pop:
            all_pops = sorted(pops_seen)
            matrix   = {ds: [counts.get(p,0) for p in all_pops]
                        for ds, counts in sorted(ds_pop.items())}
            df_mat = pd.DataFrame(matrix, index=all_pops).T
            st.dataframe(df_mat, use_container_width=True)

        # Timing categories
        timing = schema.get("timing_definitions",[])
        if timing:
            st.markdown("**Timing Definitions by Category**")
            tc2 = Counter(t.get("category","") for t in timing)
            df_t = pd.DataFrame({"Category": list(tc2.keys()), "Count": list(tc2.values())}).sort_values("Count", ascending=False)
            st.bar_chart(df_t.set_index("Category"), height=150)

    except Exception as exc:
        import traceback
        st.error(f"Analytics error: {exc}")
        with st.expander("Traceback"):
            st.code(traceback.format_exc())


# ── Tab: Structure & TOC ──────────────────────────────────────────────────────
def _tab_structure(schema):
    import pandas as pd

    secs = schema.get("sections",[])
    n_app  = sum(1 for s in secs if s.get("is_appendix"))
    st.caption(f"{len(secs)-n_app} main sections · {n_app} appendix sections")

    df = pd.DataFrame([{
        "ID":    s.get("section_id",""),
        "Lv":    s.get("level",0),
        "Title": s.get("title","")[:90],
        "Page":  s.get("page_start",""),
        "App":   "✓ " + (s.get("appendix_label") or "") if s.get("is_appendix") else "",
        "ADaM":  len(s.get("adam_annotations",[])),
    } for s in secs])
    st.dataframe(df, use_container_width=True, hide_index=True, height=440)

    cr = schema.get("cross_refs",{})
    if cr:
        with st.expander(f"Cross-References ({len(cr)})"):
            st.dataframe(
                pd.DataFrame([{"Number":k,"Section":v}
                              for k,v in list(cr.items())[:50]]),
                use_container_width=True, hide_index=True,
            )


# ── Welcome grid ──────────────────────────────────────────────────────────────
def _welcome():
    features = [
        ("📄","Large SAPs","O(n) XML parsing, parallel extraction. Handles 277-page shell docs."),
        ("✂️","Tracked Changes","w:del XML stripped. Only accepted text extracted."),
        ("📊","Table Endpoints","Primary/Secondary 2-col objective-endpoint tables parsed directly."),
        ("🔗","Multi-Document","SAP + TFL Shell + ADaM Spec Excel for higher accuracy."),
        ("⏱️","Timing Definitions","TEAE windows, study day, follow-up, washout — now extracted."),
        ("📎","ADaM Annotations","Inline ADSL.SAFFL='Y' green-text annotations extracted as rules."),
        ("📋","SAP Versioning","Version and Amendment extracted from document header."),
        ("🗂️","Table Rules","Censoring rule tables parsed row-by-row with SAS pseudocode."),
        ("📈","Analytics","Output class, dataset coverage, confidence, and timing charts."),
        ("✓","QC Engine","17 checks targeting >80% readiness on real-world SAPs."),
    ]
    cols = st.columns(5)
    for i,(icon,title,desc) in enumerate(features):
        with cols[i % 5]:
            st.markdown(
                f'<div style="background:#161b22;border:1px solid #21262d;border-radius:8px;'
                f'padding:1rem;margin-bottom:.75rem;min-height:125px;">'
                f'<div style="font-size:1.3rem;margin-bottom:.3rem;">{icon}</div>'
                f'<div style="font-size:11px;font-weight:700;color:#e6edf3;margin-bottom:.2rem;">{title}</div>'
                f'<div style="font-size:10px;color:#6e7681;">{desc}</div></div>',
                unsafe_allow_html=True,
            )


# ── Main ──────────────────────────────────────────────────────────────────────
def main():
    (sap_file, shell_file, adam_file, run_btn, demo_btn, reset_btn,
     run_qc, run_shell, parallel, conf,
     exp_json, exp_xl, exp_html, exp_sas) = _sidebar()

    # Reset
    if reset_btn:
        for k in ("schema","error","file_hash","html_report","excel_bytes","sas_bytes"):
            st.session_state[k] = None
        st.rerun()

    # Run (only sets session state — no st.rerun to avoid blank page)
    if run_btn and sap_file:
        _run(sap_file, shell_file, adam_file, conf, run_qc, run_shell,
             parallel, exp_json, exp_xl, exp_html, exp_sas)

    # Demo
    if demo_btn:
        with st.spinner("Running demo pipeline on built-in 150-page SAP…"):
            try:
                _run_demo()
            except Exception as exc:
                import traceback
                st.session_state["error"] = f"{exc}\n\n{traceback.format_exc()[-600:]}"

    # Errors
    if st.session_state.get("error"):
        st.error(f"Pipeline error:\n\n{st.session_state['error']}")
        if st.button("Clear Error & Reset"):
            for k in ("schema","error","file_hash","html_report","excel_bytes","sas_bytes"):
                st.session_state[k] = None
            st.rerun()

    schema = st.session_state.get("schema")
    _header(schema)

    if schema is None:
        _welcome()
        return

    _metrics(schema)
    st.markdown("")

    tabs = st.tabs([
        "📊 Outputs",
        "📑 Structure",
        "👥 Populations",
        "🎯 Endpoints",
        "⚡ Rules",
        "⏱️ Timing",
        "📅 Visits",
        "✓ QC Report",
        "🗃️ ADaM Spec",
        "📈 Analytics",
    ])

    with tabs[0]: _tab_outputs(schema)
    with tabs[1]: _tab_structure(schema)
    with tabs[2]: _tab_populations(schema)
    with tabs[3]: _tab_endpoints(schema)
    with tabs[4]: _tab_rules(schema)
    with tabs[5]: _tab_timing(schema)
    with tabs[6]: _tab_visits(schema)
    with tabs[7]: _tab_qc(schema)
    with tabs[8]: _tab_adam(schema)
    with tabs[9]: _tab_analytics(schema)


if __name__ == "__main__":
    main()
