# Clinical Trial Intelligence Platform v6

Pattern-based semantic extraction of clinical trial programming specifications from SAP documents.
No LLM required. CDISC ADaM-aligned. Python 3.9+.

## Quick Start
```bash
pip install -r requirements.txt
streamlit run app.py
```

## v6 — MD File Improvements (8)
| # | Improvement | MD Reference |
|---|-------------|--------------|
| 1 | `AnalysisSignature` dataclass — canonical hashable unit per analysis | Blueprint Step 3 |
| 2 | `OUTCOME_SYNONYMS` + `VARIABLE_ROLE_MAP` — Global Knowledge Layer | Scaling MD |
| 3 | `verification_status` on every output — programmer_ready/needs_review/unverified | Blueprint Step 10 |
| 4 | ADEFF removed — ADRS/ADTTE used correctly | Regression fix |
| 5 | Timing QC check — TEAE window/study day/follow-up gap detection | Blueprint Step 8 |
| 6 | Population formal_definition extraction improved | Blueprint Step 4 |
| 7 | ContextualDatasetResolver — confirmed datasets ordered before unconfirmed | Blueprint Step 6 |
| 8 | ICH E9(R1) ICE rule pattern | Blueprint Step 7 |

## v6 — Bug Fixes (9)
| # | Bug | Fix |
|---|-----|-----|
| 1 | Nested expander crash in ADaM tab | Inner expander replaced with markdown+code |
| 2 | Random numbers at end of TLF titles (e.g. `]155`) | `_clean_title()` strips page references |
| 3 | Excel formula corruption | `_safe_cell()` + `datetime.utcnow()` fixed |
| 4 | Analytics tab blank | try/except + corrected DataFrame format |
| 5 | SAS export no download button | `sas_bytes` in session state + download button |
| 6 | Timing definitions always empty | `_TimingExtractor` in pipeline step 2.5 |
| 7 | ADaM tab shows only output numbers | Variable registry tables + per-dataset Excel sheets |
| 8 | Blank page after extraction | Removed `st.rerun()` from completion path |
| 9 | Color readability | Full GitHub dark theme (#0d1117) overhaul |

## Inputs
1. **Primary SAP** *(required)* — DOCX, RTF, or TXT
2. **TFL Shell / Mock Shell** *(optional DOCX)* — adds 40–100+ outputs
3. **ADaM Variable Spec** *(optional XLSX)* — variable-level derivation tables

## Programmatic API
```python
from src.services import ExtractionPipeline, PipelineConfig
from pathlib import Path

schema = ExtractionPipeline(PipelineConfig(run_qc=True)).run([
    Path("SAP.docx"), Path("TFL_Shell.docx"), Path("ADaM_Spec.xlsx"),
])

# AnalysisSignature cross-study comparison
for o in schema.outputs_master:
    print(f"{o.output_number}: sig={o.analysis_signature.to_hash()}, status={o.verification_status}")

# Timing definitions with SAS pseudocode
for td in schema.timing_definitions:
    print(f"[{td.category}] {td.sas_pseudocode}")
```

See `docs/full_documentation.html` for full technical reference.
