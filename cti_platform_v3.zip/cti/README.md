# Clinical Trial Intelligence Platform v3.1.0

Semantic extraction of clinical trial programming specifications from SAP documents.

## What it extracts

| Domain | Details |
|--------|---------|
| Study metadata | Protocol ID, NCT, EudraCT, phase, sponsor, blinding, randomization, regulatory agencies |
| Populations | ITT/FAS/mITT/PP/SAF/PK/PD/BME with ADaM flag variables (sponsor-verified) |
| Endpoints | Primary/secondary/safety with ICH E9(R1) estimand (all 5 attributes) |
| Visit schedule | Windows, tie-breaking rule, analysis flags, unscheduled exclusion |
| **Study timing** | Study day convention, ADY formula, TEAE window, N-days-after-last-dose, follow-up, washout |
| **PK/PD** | ADPC/ADPP/ADNCA/ADPK datasets, 13 NCA parameters, BLoQ handling, ARELTM reference |
| Rules | Baseline, derivation, imputation, censoring, date imputation, filter rules |
| TLFs | Table/Listing/Figure catalogue with traceability |

## Quick start

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Programmatic use

```python
from src.services import ExtractionPipeline, PipelineConfig
from pathlib import Path

config = PipelineConfig(
    run_qc=True,
    export_json=True,
    export_excel=True,
    output_dir=Path("./outputs"),
)
schema = ExtractionPipeline(config).run([Path("my_sap.docx")])

print(schema.to_summary_dict())
print("Timing defs:", len(schema.timing_definitions))
print("PK params:", [p.paramcd for p in schema.pkpd_spec.parameters] if schema.pkpd_spec else "N/A")
```

## Extensibility

All pattern lists are plain Python dicts/lists in `src/utils/normalization.py`.
Extend without touching business logic:

```python
from src.utils.normalization import POPULATION_NORMALIZATION, PK_PARAMETER_PATTERNS, STUDY_DAY_PATTERNS

# Custom population
POPULATION_NORMALIZATION[r"\bOLE\b"] = ("OLE Population", "OLE", 7)

# Custom PK parameter
PK_PARAMETER_PATTERNS.append((r"\bCss\b", "CSS", "Steady-State Concentration (ng/mL)"))

# Custom timing rule
STUDY_DAY_PATTERNS.append((r"recovery.{0,60}(\d+)\s+days", "recovery_period", "Recovery period N days"))
```

## Documentation

Open `docs/full_documentation.html` in a browser for the full technical reference.

## Version history

- **v3.1.0** — Study timing extractor, PK/PD extractor, 22+ bug fixes, ICH E9(R1) estimand, utils refactor
- **v3.0.0** — Initial release
