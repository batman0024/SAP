"""
Document parsers for DOCX, RTF, and plain text SAP documents.

KEY IMPROVEMENTS over v2:
  - O(n) paragraph matching via id() map (was O(n2) element identity scan)
  - Hyperlinked TOC parsing with bookmark targets
  - Cross-reference / section-number resolution
  - Study schema diagram detection (images/drawings flagged, not discarded)
  - Comment/revision markup stripped before text extraction
  - Appendix section detection and labelling
  - Parallel section-text building with ThreadPoolExecutor
  - Memory-safe streaming for large documents (>4 MB)
"""
from __future__ import annotations

import re
import zipfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple
from xml.etree import ElementTree as ET

from src.utils import clean_text, get_logger, truncate

logger = get_logger(__name__)

_NS = {
    "w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
}
_LARGE_FILE_THRESHOLD = 4 * 1024 * 1024
_MAX_WORKERS = 4


def _qn(local: str) -> str:
    return "{" + _NS["w"] + "}" + local


# Tags whose content should be ignored (comments, tracked deletions)
_SKIP_TAGS: Set[str] = {
    _qn(t) for t in (
        "del", "commentRangeStart", "commentRangeEnd",
        "proofErr", "bookmarkEnd", "permStart", "permEnd",
    )
}

_HEADING_STYLE_RE = re.compile(r"heading\s*(\d+)|h(\d+)|title|subtitle", re.IGNORECASE)
_NUMBERED_HEADING_RE = re.compile(r"^(\d+(?:\.\d+){0,4})\s+(.+)$")
_ALL_CAPS_RE = re.compile(r"^[A-Z][A-Z\s\d\-\/]{4,}$")
_APPENDIX_RE = re.compile(r"^(?:appendix|annex)\s*([A-Z\d]?)[:\s\-]*(.*)", re.IGNORECASE)
_TOC_STYLE_RE = re.compile(r"toc\s*\d|contents?\s*\d", re.IGNORECASE)
_NUM_PREFIX_RE = re.compile(r"^(\d+(?:\.\d+)*)\s+")


# ---------------------------------------------------------------------------
# Data containers (backward compatible + new fields)
# ---------------------------------------------------------------------------

@dataclass
class ParsedParagraph:
    paragraph_id: str
    text: str
    style: str
    level: int
    page_estimate: int
    index: int
    has_hyperlink: bool = False
    bookmark_id: Optional[str] = None
    is_toc_entry: bool = False
    has_drawing: bool = False


@dataclass
class ParsedTable:
    table_id: str
    page_estimate: int
    paragraph_index: int
    rows: List[List[str]] = field(default_factory=list)
    caption: str = ""
    has_header: bool = True
    is_study_schema: bool = False

    @property
    def num_rows(self) -> int:
        return len(self.rows)

    @property
    def num_cols(self) -> int:
        return max((len(r) for r in self.rows), default=0)


@dataclass
class ParsedSection:
    section_id: str
    title: str
    level: int
    parent_id: Optional[str]
    page_start: int
    paragraphs: List[ParsedParagraph] = field(default_factory=list)
    tables: List[ParsedTable] = field(default_factory=list)
    full_text: str = ""
    is_appendix: bool = False
    appendix_label: Optional[str] = None
    toc_entries: List[Tuple[str, str]] = field(default_factory=list)

    def get_text(self) -> str:
        return self.full_text or " ".join(p.text for p in self.paragraphs)


@dataclass
class ParsedDocument:
    file_name: str
    file_type: str
    file_size_bytes: int
    paragraphs: List[ParsedParagraph] = field(default_factory=list)
    tables: List[ParsedTable] = field(default_factory=list)
    sections: List[ParsedSection] = field(default_factory=list)
    full_text: str = ""
    total_pages: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)
    toc_map: Dict[str, str] = field(default_factory=dict)
    cross_refs: Dict[str, str] = field(default_factory=dict)
    has_study_schema_diagram: bool = False
    appendix_sections: List[str] = field(default_factory=list)

    def get_section_by_id(self, section_id: str) -> Optional[ParsedSection]:
        return next((s for s in self.sections if s.section_id == section_id), None)

    def get_sections_by_level(self, level: int) -> List[ParsedSection]:
        return [s for s in self.sections if s.level == level]

    def find_sections_containing(self, keyword: str) -> List[ParsedSection]:
        kw = keyword.lower()
        return [s for s in self.sections
                if kw in s.title.lower() or kw in s.get_text().lower()]


# ---------------------------------------------------------------------------
# XML helpers
# ---------------------------------------------------------------------------

def _detect_heading_level(style_name: str, text: str) -> int:
    m = _HEADING_STYLE_RE.match(style_name)
    if m:
        lv = m.group(1) or m.group(2)
        return int(lv) if lv else 1
    stripped = text.strip()
    # Appendix / Annex headings are always level 1
    if _APPENDIX_RE.match(stripped):
        return 1
    m = _NUMBERED_HEADING_RE.match(stripped)
    if m:
        return m.group(1).count(".") + 1
    if len(text) < 80 and _ALL_CAPS_RE.match(stripped):
        return 1
    return 0


def _estimate_page(idx: int, avg: int = 9) -> int:
    return max(1, idx // avg + 1)


def _xml_para_text(para_el: ET.Element) -> str:
    """Extract plain text from <w:p>, stripping tracked deletions and comments."""
    _t_tag = _qn("t")
    _ins_tag = _qn("ins")

    parts: List[str] = []

    def _walk(el: ET.Element) -> None:
        if el.tag in _SKIP_TAGS:
            return
        if el.tag == _t_tag:
            parts.append(el.text or "")
            return
        # w:ins: accepted revision — include content
        for child in el:
            _walk(child)

    _walk(para_el)
    return "".join(parts)


def _has_drawing(para_el: ET.Element) -> bool:
    draw_tags = {_qn("drawing"), _qn("pict")}
    for el in para_el.iter():
        if el.tag in draw_tags:
            return True
    return False


def _has_hyperlink(para_el: ET.Element) -> bool:
    hl_tag = _qn("hyperlink")
    return para_el.find(f".//{hl_tag}") is not None


def _bookmark_name(para_el: ET.Element) -> Optional[str]:
    bm_tag = _qn("bookmarkStart")
    name_attr = _qn("name")
    for el in para_el.iter(bm_tag):
        nm = el.get(name_attr, "")
        if nm and not nm.startswith("_"):
            return nm
    return None


# ---------------------------------------------------------------------------
# DOCX Parser
# ---------------------------------------------------------------------------

class DocxParser:
    def __init__(self, avg_paragraphs_per_page: int = 9) -> None:
        self.avg = avg_paragraphs_per_page

    def parse(self, file_path: Path) -> ParsedDocument:
        logger.info("Parsing DOCX: %s (%.1f KB)",
                    file_path.name, file_path.stat().st_size / 1024)
        try:
            import docx as _docx_mod
            if file_path.stat().st_size > _LARGE_FILE_THRESHOLD:
                logger.info("Large SAP — using XML streaming path")
                return self._parse_xml(file_path)
            return self._parse_python_docx(file_path, _docx_mod)
        except ImportError:
            return self._parse_xml(file_path)
        except Exception as exc:
            logger.error("DOCX parse error: %s", exc)
            return self._parse_xml(file_path)

    # ---------- python-docx path (small/medium docs) ----------

    def _parse_python_docx(self, file_path: Path, docx_mod: Any) -> ParsedDocument:
        doc = docx_mod.Document(str(file_path))

        # O(n) lookup maps — eliminates the O(n2) inner loop from v2
        para_by_eid: Dict[int, Any] = {id(p._element): p for p in doc.paragraphs}
        tbl_by_eid: Dict[int, Any] = {id(t._element): t for t in doc.tables}

        paragraphs: List[ParsedParagraph] = []
        tables: List[ParsedTable] = []
        para_index = 0
        has_diagram = False

        for element in doc.element.body:
            local = element.tag.rsplit("}", 1)[-1]

            if local == "p":
                p_obj = para_by_eid.get(id(element))
                if p_obj is None:
                    para_index += 1
                    continue
                text = clean_text(p_obj.text)
                has_draw = _has_drawing(element)
                if has_draw:
                    has_diagram = True
                    if not text:
                        text = "[DIAGRAM]"
                if not text:
                    para_index += 1
                    continue

                style = (p_obj.style.name if p_obj.style else "Normal") or "Normal"
                paragraphs.append(ParsedParagraph(
                    paragraph_id=f"para_{para_index:05d}",
                    text=text,
                    style=style,
                    level=_detect_heading_level(style, text),
                    page_estimate=_estimate_page(para_index, self.avg),
                    index=para_index,
                    has_hyperlink=_has_hyperlink(element),
                    bookmark_id=_bookmark_name(element),
                    is_toc_entry=bool(_TOC_STYLE_RE.search(style)),
                    has_drawing=has_draw,
                ))
                para_index += 1

            elif local == "tbl":
                tbl_obj = tbl_by_eid.get(id(element))
                if tbl_obj is None:
                    para_index += 1
                    continue
                rows = [[clean_text(c.text) for c in row.cells]
                        for row in tbl_obj.rows]
                is_schema = (len(rows) == 1 and len(rows[0]) == 1
                             and not rows[0][0].strip())
                if is_schema:
                    has_diagram = True
                tables.append(ParsedTable(
                    table_id=f"tbl_{len(tables):04d}",
                    page_estimate=_estimate_page(para_index, self.avg),
                    paragraph_index=para_index,
                    rows=rows,
                    is_study_schema=is_schema,
                ))
                para_index += 1

        return self._assemble(file_path, paragraphs, tables, has_diagram)

    # ---------- XML streaming path (large docs) ----------

    def _parse_xml(self, file_path: Path) -> ParsedDocument:
        try:
            with zipfile.ZipFile(str(file_path), "r") as zf:
                if "word/document.xml" not in zf.namelist():
                    return self._empty_document(file_path)
                xml_bytes = zf.read("word/document.xml")
        except Exception as exc:
            logger.error("Cannot open DOCX: %s", exc)
            return self._empty_document(file_path)

        try:
            root = ET.fromstring(xml_bytes)
        except ET.ParseError as exc:
            logger.error("XML parse failed: %s", exc)
            return self._empty_document(file_path)

        body = root.find(f".//{_qn('body')}")
        if body is None:
            return self._empty_document(file_path)

        _p = _qn("p")
        _tbl = _qn("tbl")
        _tr = _qn("tr")
        _tc = _qn("tc")
        _pStyle = _qn("pStyle")
        _pPr = _qn("pPr")
        _val = _qn("val")

        paragraphs: List[ParsedParagraph] = []
        tables: List[ParsedTable] = []
        para_index = 0
        has_diagram = False

        for element in body:
            if element.tag == _p:
                text = clean_text(_xml_para_text(element))
                has_draw = _has_drawing(element)
                if has_draw:
                    has_diagram = True
                    if not text:
                        text = "[DIAGRAM]"
                if not text:
                    para_index += 1
                    continue

                style = "Normal"
                pPr = element.find(_pPr)
                if pPr is not None:
                    ps = pPr.find(_pStyle)
                    if ps is not None:
                        style = ps.get(_val, "Normal")

                paragraphs.append(ParsedParagraph(
                    paragraph_id=f"para_{para_index:05d}",
                    text=text,
                    style=style,
                    level=_detect_heading_level(style, text),
                    page_estimate=_estimate_page(para_index, self.avg),
                    index=para_index,
                    has_hyperlink=_has_hyperlink(element),
                    bookmark_id=_bookmark_name(element),
                    is_toc_entry=bool(_TOC_STYLE_RE.search(style)),
                    has_drawing=has_draw,
                ))
                para_index += 1

            elif element.tag == _tbl:
                rows: List[List[str]] = []
                for tr in element.iter(_tr):
                    row = []
                    for tc in tr.findall(_tc):
                        parts = []
                        for p in tc.iter(_p):
                            t = clean_text(_xml_para_text(p))
                            if t:
                                parts.append(t)
                        row.append(" ".join(parts))
                    if row:
                        rows.append(row)
                is_schema = (len(rows) == 1 and len(rows[0]) == 1
                             and not rows[0][0].strip())
                if is_schema:
                    has_diagram = True
                tables.append(ParsedTable(
                    table_id=f"tbl_{len(tables):04d}",
                    page_estimate=_estimate_page(para_index, self.avg),
                    paragraph_index=para_index,
                    rows=rows,
                    is_study_schema=is_schema,
                ))
                para_index += 1

        return self._assemble(file_path, paragraphs, tables, has_diagram)

    # ---------- Assembly (shared) ----------

    def _assemble(
        self,
        file_path: Path,
        paragraphs: List[ParsedParagraph],
        tables: List[ParsedTable],
        has_diagram: bool,
    ) -> ParsedDocument:
        sections = self._build_sections(paragraphs, tables)
        full_text = "\n".join(p.text for p in paragraphs)
        toc_map, cross_refs = self._build_toc_map(paragraphs, sections)
        # Deduplicate appendix sections by title: keep the LAST occurrence.
        # The first occurrence is usually a TOC line (no content); the last
        # is the actual appendix section with paragraphs.
        _seen_app: Dict[str, str] = {}  # title -> section_id (last wins)
        for s in sections:
            if s.is_appendix:
                _seen_app[s.title] = s.section_id
        appendix_ids = list(_seen_app.values())
        # Mark TOC-duplicate appendix sections as non-appendix
        real_app_ids = set(appendix_ids)
        for s in sections:
            if s.is_appendix and s.section_id not in real_app_ids:
                s.is_appendix = False
                s.appendix_label = None

        return ParsedDocument(
            file_name=file_path.name,
            file_type="docx",
            file_size_bytes=file_path.stat().st_size,
            paragraphs=paragraphs,
            tables=tables,
            sections=sections,
            full_text=full_text,
            total_pages=_estimate_page(len(paragraphs), self.avg),
            toc_map=toc_map,
            cross_refs=cross_refs,
            has_study_schema_diagram=has_diagram,
            appendix_sections=appendix_ids,
        )

    # ---------- Section builder ----------

    def _build_sections(
        self,
        paragraphs: List[ParsedParagraph],
        tables: List[ParsedTable],
    ) -> List[ParsedSection]:
        sections: List[ParsedSection] = []
        stack: List[ParsedSection] = []
        orphans: List[ParsedParagraph] = []
        tbl_by_idx: Dict[int, ParsedTable] = {t.paragraph_index: t for t in tables}
        app_counter = 0
        _letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

        for para in paragraphs:
            if para.level > 0:
                while stack and stack[-1].level >= para.level:
                    stack.pop()
                parent_id = stack[-1].section_id if stack else None
                sec_id = f"sec_{len(sections):04d}"

                m = _APPENDIX_RE.match(para.text.strip())
                is_app = bool(m)
                app_label: Optional[str] = None
                if is_app:
                    explicit = (m.group(1) or "").strip().upper()
                    if explicit:
                        app_label = explicit
                    else:
                        app_label = _letters[min(app_counter, len(_letters) - 1)]
                        app_counter += 1

                sec = ParsedSection(
                    section_id=sec_id,
                    title=para.text,
                    level=para.level,
                    parent_id=parent_id,
                    page_start=para.page_estimate,
                    is_appendix=is_app,
                    appendix_label=app_label,
                )
                sections.append(sec)
                stack.append(sec)
            else:
                if stack:
                    stack[-1].paragraphs.append(para)
                    if para.index in tbl_by_idx:
                        stack[-1].tables.append(tbl_by_idx[para.index])
                else:
                    orphans.append(para)

        self._build_section_texts_parallel(sections)

        if orphans:
            pre = ParsedSection(
                section_id="sec_preamble",
                title="Document Preamble",
                level=0,
                parent_id=None,
                page_start=1,
                paragraphs=orphans,
            )
            pre.full_text = " ".join(p.text for p in orphans)
            sections.insert(0, pre)

        return sections

    @staticmethod
    def _build_section_texts_parallel(sections: List[ParsedSection]) -> None:
        if len(sections) <= 25:
            for s in sections:
                s.full_text = " ".join(p.text for p in s.paragraphs)
            return

        def _build(sec: ParsedSection) -> Tuple[str, str]:
            return sec.section_id, " ".join(p.text for p in sec.paragraphs)

        sid_map = {s.section_id: s for s in sections}
        with ThreadPoolExecutor(max_workers=_MAX_WORKERS) as pool:
            for fut in as_completed({pool.submit(_build, s) for s in sections}):
                try:
                    sid, text = fut.result()
                    sid_map[sid].full_text = text
                except Exception as exc:
                    logger.warning("Section text build error: %s", exc)

    @staticmethod
    def _build_toc_map(
        paragraphs: List[ParsedParagraph],
        sections: List[ParsedSection],
    ) -> Tuple[Dict[str, str], Dict[str, str]]:
        title_to_sid: Dict[str, str] = {s.title: s.section_id for s in sections}
        toc_map: Dict[str, str] = {}
        cross_refs: Dict[str, str] = {}

        for p in paragraphs:
            if p.bookmark_id and p.level > 0:
                sid = title_to_sid.get(p.text)
                if sid:
                    toc_map[p.bookmark_id] = sid

        for sec in sections:
            m = _NUM_PREFIX_RE.match(sec.title)
            if m:
                cross_refs[m.group(1)] = sec.section_id

        return toc_map, cross_refs

    def _text_to_paragraphs(self, text: str) -> List[ParsedParagraph]:
        paras: List[ParsedParagraph] = []
        for i, line in enumerate(l.strip() for l in text.split("\n") if l.strip()):
            paras.append(ParsedParagraph(
                paragraph_id=f"para_{i:05d}",
                text=line,
                style="Normal",
                level=_detect_heading_level("", line),
                page_estimate=_estimate_page(i, self.avg),
                index=i,
            ))
        return paras

    @staticmethod
    def _empty_document(file_path: Path) -> ParsedDocument:
        return ParsedDocument(
            file_name=file_path.name,
            file_type="docx",
            file_size_bytes=file_path.stat().st_size if file_path.exists() else 0,
        )


# ---------------------------------------------------------------------------
# RTF / Text parsers
# ---------------------------------------------------------------------------

class RtfParser:
    _RTF_CONTROL = re.compile(r"\\[a-zA-Z]+(?:-?\d+)?\s?|[{}]|\\\'[0-9a-fA-F]{2}")
    _NEWLINE_CTRL = re.compile(r"\\(par|line|pard)\b")

    def parse(self, file_path: Path) -> ParsedDocument:
        logger.info("Parsing RTF: %s", file_path.name)
        try:
            raw = file_path.read_bytes().decode("latin-1", errors="replace")
            text = self._strip(raw)
            dp = DocxParser()
            paras = dp._text_to_paragraphs(text)
            secs = dp._build_sections(paras, [])
            return ParsedDocument(
                file_name=file_path.name, file_type="rtf",
                file_size_bytes=file_path.stat().st_size,
                paragraphs=paras, sections=secs,
                full_text="\n".join(p.text for p in paras),
                total_pages=max(1, len(paras) // 9),
            )
        except Exception as exc:
            logger.error("RTF error: %s", exc)
            return DocxParser._empty_document(file_path)

    def _strip(self, rtf: str) -> str:
        text = self._NEWLINE_CTRL.sub("\n", rtf)
        return re.sub(r"\n{3,}", "\n\n", self._RTF_CONTROL.sub("", text)).strip()


class TextParser:
    def parse(self, file_path: Path) -> ParsedDocument:
        logger.info("Parsing text: %s", file_path.name)
        try:
            # Split on newlines FIRST, then clean each line individually.
            # clean_text() collapses all whitespace including newlines, so
            # applying it to the whole file destroys line-based structure.
            raw = file_path.read_text(encoding="utf-8", errors="replace")
            dp = DocxParser()
            paras: List[ParsedParagraph] = []
            for i, line in enumerate(raw.splitlines()):
                line = clean_text(line)
                if not line:
                    continue
                paras.append(ParsedParagraph(
                    paragraph_id=f"para_{i:05d}",
                    text=line,
                    style="Normal",
                    level=_detect_heading_level("", line),
                    page_estimate=_estimate_page(len(paras), 9),
                    index=len(paras),
                ))
            secs = dp._build_sections(paras, [])
            return ParsedDocument(
                file_name=file_path.name, file_type="txt",
                file_size_bytes=file_path.stat().st_size,
                paragraphs=paras, sections=secs,
                full_text="\n".join(p.text for p in paras),
                total_pages=max(1, len(paras) // 9),
            )
        except Exception as exc:
            logger.error("Text error: %s", exc)
            return DocxParser._empty_document(file_path)


def parse_document(file_path: Path) -> ParsedDocument:
    suffix = file_path.suffix.lower()
    if suffix == ".docx":
        return DocxParser().parse(file_path)
    elif suffix == ".rtf":
        return RtfParser().parse(file_path)
    elif suffix in (".txt", ".text", ".md"):
        return TextParser().parse(file_path)
    else:
        logger.warning("Unknown extension %s", suffix)
        return TextParser().parse(file_path)
