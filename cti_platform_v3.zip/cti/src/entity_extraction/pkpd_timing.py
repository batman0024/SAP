"""
PK/PD and Study Timing Extractor.

Extracts:
  - Study day / timing definitions (Day 0 vs Day 1, ADY formula, TEAE windows,
    follow-up period, days-after-last-dose, on/off-treatment periods)
  - PK/PD analysis specifications (ADPC, ADPP, NCA, PopPK, E/R)
  - BLoQ handling rules
  - PK sampling time reference conventions

This module intentionally does NOT assume any LLM is present.
All extraction is pattern-based, semantic, and structured — not
plain text passthrough.

EXTENSIBILITY:
  All pattern lists are imported from src.utils.normalization.
  Add new patterns there without touching this module.
"""
from __future__ import annotations

import re
import uuid
from typing import Dict, List, Optional, Tuple

from src.models.schema import (
    EndpointClassification,
    PKConcentrationSpec,
    PKParameter,
    PKPDSpec,
    ProgrammingRule,
    RuleType,
    TimingDefinition,
)
from src.parsers import ParsedDocument, ParsedSection
from src.utils import (
    BLOQ_HANDLING_PATTERNS,
    PD_PATTERNS,
    PK_PARAMETER_PATTERNS,
    PK_TIME_REFERENCE_PATTERNS,
    STUDY_DAY_PATTERNS,
    clean_text,
    compute_confidence,
    get_logger,
    truncate,
)

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# Study Day / Timing Extractor
# ---------------------------------------------------------------------------

class StudyTimingExtractor:
    """
    Extracts structured timing definitions from SAP text.

    Semantic categories captured:
      study_day_anchor   — Day 0 vs Day 1 convention
      ady_formula        — explicit ADY derivation formula
      followup_definition— follow-up period end anchor
      washout_definition — washout/post-dose period
      safety_followup    — safety follow-up window after last dose
      teae_window        — treatment-emergent AE observation window
      on_treatment_period— on-treatment period boundaries
      off_treatment_period
      days_after_last_dose— explicit N days after last dose rules
    """

    _STUDY_DAY_KEYWORDS = [
        "study day", "treatment day", "ady", "adtm", "study period",
        "follow-up", "followup", "post-treatment", "on-treatment",
        "after last dose", "days after", "teae", "treatment-emergent",
    ]

    _N_DAYS_PATTERN = re.compile(
        r"(\d+)\s+(?:calendar\s+)?days?",
        re.IGNORECASE,
    )
    _REFERENCE_EVENTS = {
        "last dose": "last dose",
        "last administration": "last dose",
        "end of treatment": "EOT",
        "EOT": "EOT",
        "first dose": "first dose",
        "day 1": "first dose",
        "randomization": "randomization",
        "randomisation": "randomization",
    }

    def extract(self, document: ParsedDocument) -> List[TimingDefinition]:
        """Extract all timing definitions from document."""
        definitions: List[TimingDefinition] = []
        seen_descriptions: set = set()

        for section in document.sections:
            text = section.get_text()
            if not text:
                continue

            # Only scan sections likely to contain timing definitions
            # but still fall through to all sections as fallback
            is_timing_section = any(
                kw in section.title.lower()
                for kw in ["follow", "timing", "period", "day", "window",
                           "study design", "pk", "safety", "teae", "treatment"]
            )

            for pattern, category, description_template in STUDY_DAY_PATTERNS:
                try:
                    for match in re.finditer(pattern, text, re.IGNORECASE | re.DOTALL):
                        verbatim = truncate(clean_text(match.group(0)), 300)

                        # Deduplicate by description + first 60 chars of verbatim
                        dedup_key = f"{category}::{verbatim[:60]}"
                        if dedup_key in seen_descriptions:
                            continue
                        seen_descriptions.add(dedup_key)

                        # Extract numeric day count if present
                        n_days = self._extract_n_days(match, verbatim)

                        # Extract reference event
                        ref_event = self._extract_reference_event(verbatim)

                        # Build pseudocode for known categories
                        pseudocode = self._build_pseudocode(category, n_days, ref_event)

                        # ADaM variables relevant to this category
                        adam_vars = self._adam_variables_for_category(category)

                        confidence = 0.90 if is_timing_section else 0.75
                        if n_days is not None:
                            confidence = min(1.0, confidence + 0.05)
                        if ref_event:
                            confidence = min(1.0, confidence + 0.03)

                        definitions.append(TimingDefinition(
                            category=category,
                            description=description_template,
                            verbatim_text=verbatim,
                            n_days=n_days,
                            reference_event=ref_event,
                            adam_variables=adam_vars,
                            pseudocode=pseudocode,
                            source_section=section.section_id,
                            source_page=section.page_start,
                            confidence=confidence,
                        ))
                except re.error as exc:
                    logger.warning("Regex error in timing pattern '%s': %s", pattern[:40], exc)

        logger.info("Timing extractor found %d definitions", len(definitions))
        return definitions

    def _extract_n_days(self, match: re.Match, verbatim: str) -> Optional[int]:
        """Extract the first numeric day count from the match."""
        # Try named group first
        try:
            val = match.group(1)
            if val and val.isdigit():
                return int(val)
        except IndexError:
            pass
        # Fall back to scanning verbatim text
        m = self._N_DAYS_PATTERN.search(verbatim)
        if m:
            return int(m.group(1))
        return None

    def _extract_reference_event(self, text: str) -> Optional[str]:
        """Identify reference event anchor in text."""
        text_lower = text.lower()
        for phrase, canonical in self._REFERENCE_EVENTS.items():
            if phrase.lower() in text_lower:
                return canonical
        return None

    @staticmethod
    def _build_pseudocode(category: str, n_days: Optional[int], ref_event: Optional[str]) -> Optional[str]:
        """Generate SAS-style pseudocode for known timing categories."""
        n = n_days or "N"
        ref = ref_event or "<reference_event>"
        mapping: Dict[str, str] = {
            "study_day_anchor": (
                "/* Post-dose: ADY = ADT - TRTSDT + 1; */\n"
                "/* Pre-dose:  ADY = ADT - TRTSDT;     (no Day 0) */"
            ),
            "ady_formula": (
                "if ADT >= TRTSDT then ADY = ADT - TRTSDT + 1;\n"
                "else ADY = ADT - TRTSDT;"
            ),
            "teae_window": (
                f"/* TEAE window: ADT >= TRTSDT and ADT <= (LDRELD + {n}) */\n"
                f"AETRTEM = (AESTDTM >= TRTSDTM) and (AESTDTM <= (LDRELDTM + {n}*86400));"
            ),
            "days_after_last_dose": (
                f"/* On/Off-treatment boundary: LDRELD = date of last dose */\n"
                f"if ADT <= LDRELD + {n} then /* within {n} days of last dose */;"
            ),
            "safety_followup": (
                f"/* Safety follow-up ends {n} days after last dose */\n"
                f"SFUENDT = LDRELD + {n};"
            ),
            "followup_definition": (
                f"/* Follow-up period: from EOT/last dose to {n} days after */\n"
                f"FUENDT = LDRELD + {n};"
            ),
            "washout_definition": (
                f"/* Washout: from last dose, lasting {n} days */\n"
                f"WOENDT = LDRELD + {n};"
            ),
        }
        return mapping.get(category)

    @staticmethod
    def _adam_variables_for_category(category: str) -> List[str]:
        mapping: Dict[str, List[str]] = {
            "study_day_anchor":     ["ADY", "TRTSDT", "ADT"],
            "ady_formula":          ["ADY", "ADTM", "TRTSDT", "TRTSDTM"],
            "teae_window":          ["AETRTEM", "AESTDTM", "TRTSDTM", "LDRELDTM", "TRTEMFL"],
            "days_after_last_dose": ["ADT", "LDRELD", "LDRELDTM", "TRTEDTM"],
            "safety_followup":      ["ADT", "LDRELD", "SFUENDT"],
            "followup_definition":  ["ADT", "LDRELD", "FUENDT", "APHASE"],
            "washout_definition":   ["ADT", "LDRELD", "WOENDT", "APHASE"],
            "on_treatment_period":  ["TRTSDT", "TRTEDTM", "ONTRFL", "ADT"],
            "off_treatment_period": ["TRTEDTM", "LDRELD", "ADT"],
        }
        return mapping.get(category, ["ADY", "ADT"])


# ---------------------------------------------------------------------------
# PK/PD Extractor
# ---------------------------------------------------------------------------

class PKPDExtractor:
    """
    Extracts PK/PD specifications from SAP or PKAP text.

    Produces a PKPDSpec covering:
      - Which ADaM datasets are needed: ADPC, ADPP, ADPK (PopPK)
      - SDTM source domains: PC, PP, EX
      - PK parameters (PARAMCD/PARAM pairs)
      - BLoQ handling
      - ARELTM time reference convention
      - NCA, PopPK, E/R flags
      - PD biomarkers
    """

    _PK_SECTION_KEYWORDS = [
        "pharmacokinetic", "pharmacodynamic", " pk ", " pd ", "pk/pd", "pkpd",
        "concentration", "nca", "non-compartmental", "pop pk", "exposure-response",
        "bioavailability", "adpc", "adpp",
    ]
    _PD_SECTION_KEYWORDS = [
        "pharmacodynamic", "biomarker", "exposure-response", "pk/pd",
        "receptor occupancy", "target engagement",
    ]

    _NCA_PATTERN = re.compile(
        r"\b(?:NCA|non.compartmental\s+analysis|phoenix|winnonlin|WNL)\b",
        re.IGNORECASE,
    )
    _POP_PK_PATTERN = re.compile(
        r"\b(?:population\s+PK|PopPK|NONMEM|NLME|mixed.effects\s+PK)\b",
        re.IGNORECASE,
    )
    _ER_PATTERN = re.compile(
        r"\b(?:exposure.response|E/R|Emax\s+model|linear\s+model.*exposure|"
        r"logistic.*exposure|PK.PD|PKPD)\b",
        re.IGNORECASE,
    )
    _MATRIX_PATTERN = re.compile(
        r"\b(plasma|serum|whole\s+blood|urine|CSF|saliva|dried\s+blood\s+spot|DBS)\b",
        re.IGNORECASE,
    )
    _LLOQ_PATTERN = re.compile(
        r"LLOQ\s*(?:of|=|is|:)?\s*([\d.]+)\s*(ng[/\\]mL|µg[/\\]mL|mg[/\\]L|pg[/\\]mL)",
        re.IGNORECASE,
    )
    _SOFTWARE_PATTERN = re.compile(
        r"\b(?:Phoenix|WinNonLin|WNL|NONMEM|Monolix|ADAPT|PsN|SAS\s+PROC\s+NLM)\b",
        re.IGNORECASE,
    )

    def extract(self, document: ParsedDocument) -> Optional[PKPDSpec]:
        """
        Extract PK/PD spec. Returns None if no PK/PD content detected.
        Callers should check study_metadata.has_pk_analysis before calling.
        """
        # First pass: check if document has PK content at all
        full_lower = document.full_text.lower()
        has_pk = any(kw in full_lower for kw in ["pharmacokinetic", " adpc", " adpp",
                                                   "cmax", "auc", " nca ", "half-life"])
        has_pd = any(kw in full_lower for kw in ["pharmacodynamic", "exposure-response",
                                                   "biomarker", "emax", "ec50"])
        if not has_pk and not has_pd:
            return None

        spec = PKPDSpec(
            has_nca=False,
            has_pop_pk=False,
            has_exposure_response=False,
            has_pd_endpoints=has_pd,
        )

        # Always include standard PK SDTM/ADaM datasets when PK detected
        if has_pk:
            spec.sdtm_domains_source = ["PC", "PP", "EX"]
            spec.adam_datasets_required = ["ADPC", "ADPP"]

        pk_sections = []
        for section in document.sections:
            title_lower = section.title.lower()
            text = section.get_text()
            if not text:
                continue

            is_pk_section = any(kw in title_lower for kw in self._PK_SECTION_KEYWORDS)
            is_pd_section = any(kw in title_lower for kw in self._PD_SECTION_KEYWORDS)

            if is_pk_section or is_pd_section or has_pk:
                pk_sections.append((section, is_pk_section, is_pd_section))

        all_text_parts = []
        primary_section = None

        for section, is_pk, is_pd in pk_sections:
            text = section.get_text()
            all_text_parts.append(text)
            if is_pk and primary_section is None:
                primary_section = section

        combined_text = " ".join(all_text_parts)

        # --- NCA detection ---
        if self._NCA_PATTERN.search(combined_text):
            spec.has_nca = True
            if "ADNCA" not in spec.adam_datasets_required:
                spec.adam_datasets_required.append("ADNCA")

        # --- PopPK detection ---
        if self._POP_PK_PATTERN.search(combined_text):
            spec.has_pop_pk = True
            if "ADPK" not in spec.adam_datasets_required:
                spec.adam_datasets_required.append("ADPK")

        # --- E/R detection ---
        if self._ER_PATTERN.search(combined_text):
            spec.has_exposure_response = True
            er_m = re.search(
                r"\b(Emax|linear|logistic|power|sigmoidal|indirect\s+response)\b",
                combined_text, re.IGNORECASE
            )
            if er_m:
                spec.er_model_type = er_m.group(1).title()

        # --- Software ---
        sw_m = self._SOFTWARE_PATTERN.search(combined_text)
        if sw_m:
            spec.nca_software = sw_m.group(0)

        # --- Parameters ---
        spec.parameters = self._extract_pk_parameters(combined_text)

        # --- Concentration spec ---
        spec.concentration_spec = self._extract_concentration_spec(combined_text)

        # --- PD biomarkers ---
        pd_markers: List[str] = []
        for pattern, desc in PD_PATTERNS:
            if re.search(pattern, combined_text, re.IGNORECASE):
                # Extract actual biomarker names
                m = re.search(r"\b([A-Z]{2,10}(?:-\d+)?)\b", desc)
                if m and m.group(1) not in pd_markers:
                    pd_markers.append(m.group(1))
        spec.pd_biomarkers = pd_markers

        # --- PK populations ---
        pop_abbrevs: List[str] = []
        for abbrev in ["PK", "mITT", "ITT", "FAS", "SAF", "EVAL"]:
            if re.search(rf"\b{abbrev}\b.{{0,40}}(?:population|set)", combined_text, re.IGNORECASE):
                pop_abbrevs.append(abbrev)
        if not pop_abbrevs and has_pk:
            pop_abbrevs = ["PK"]
        spec.pk_populations = pop_abbrevs

        # --- Time reference for ARELTM ---
        for pattern, desc in PK_TIME_REFERENCE_PATTERNS:
            if re.search(pattern, combined_text, re.IGNORECASE):
                if spec.concentration_spec:
                    spec.concentration_spec.time_reference = desc
                break

        spec.source_section = primary_section.section_id if primary_section else None
        spec.confidence = compute_confidence(
            sum([
                spec.has_nca,
                bool(spec.parameters),
                bool(spec.concentration_spec and spec.concentration_spec.assay_lloq),
                bool(spec.nca_software),
                bool(spec.pk_populations),
            ]),
            5,
            base=0.70,
        )

        logger.info(
            "PK/PD extractor: NCA=%s PopPK=%s E/R=%s params=%d datasets=%s",
            spec.has_nca, spec.has_pop_pk, spec.has_exposure_response,
            len(spec.parameters), spec.adam_datasets_required,
        )
        return spec

    def _extract_pk_parameters(self, text: str) -> List[PKParameter]:
        """Extract named PK parameters as ADPP-ready entries."""
        params: List[PKParameter] = []
        seen_paramcds: set = set()

        for pattern, paramcd, param_desc in PK_PARAMETER_PATTERNS:
            if re.search(pattern, text, re.IGNORECASE) and paramcd not in seen_paramcds:
                seen_paramcds.add(paramcd)
                # Detect if log-transformed (geometric mean reported)
                log_transformed = bool(re.search(
                    rf"{re.escape(paramcd)}.{{0,80}}(?:log|geometric\s+mean|ln)",
                    text, re.IGNORECASE
                ))
                # Infer summary stats
                stats = ["n", "Mean", "SD", "CV%", "Median", "Min", "Max"]
                if log_transformed:
                    stats = ["n", "Geometric Mean", "CV%", "Median", "Min", "Max"]
                # Determine whether this is concentration (ADPC) or parameter (ADPP)
                is_conc = paramcd in ("CMAX", "CMIN", "CAVG")
                params.append(PKParameter(
                    paramcd=paramcd,
                    param=param_desc,
                    sdtm_source="PC" if is_conc else "PP",
                    adam_dataset="ADPC" if is_conc else "ADPP",
                    log_transformed=log_transformed,
                    summary_statistics=stats,
                ))

        return params

    def _extract_concentration_spec(self, text: str) -> Optional[PKConcentrationSpec]:
        """Extract ADPC-relevant concentration data handling specifications."""
        spec = PKConcentrationSpec()
        found_anything = False

        # Matrix (plasma, serum, etc.)
        m = self._MATRIX_PATTERN.search(text)
        if m:
            spec.matrix = m.group(1).lower()
            found_anything = True

        # LLOQ
        m = self._LLOQ_PATTERN.search(text)
        if m:
            spec.assay_lloq = float(m.group(1))
            spec.assay_lloq_unit = m.group(2)
            found_anything = True

        # BLoQ handling — structured extraction
        for pattern, desc in BLOQ_HANDLING_PATTERNS:
            if re.search(pattern, text, re.IGNORECASE):
                spec.bloq_handling = desc
                found_anything = True
                break

        # Predose ATPTN convention
        if re.search(r"predose.{0,40}(?:ATPTN|time)\s*=\s*0", text, re.IGNORECASE):
            spec.predose_atptn_convention = "0"
            found_anything = True
        elif re.search(r"predose.{0,40}negative\s+(?:time|ATPTN)", text, re.IGNORECASE):
            spec.predose_atptn_convention = "negative"
            found_anything = True

        # Excluded conditions (vomiting, emesis)
        excluded = []
        for excl_pattern in [
            r"vomit.{0,40}(?:within|less\s+than)\s+(\d+)\s+(?:hours?|h)\s+(?:of|after)\s+dose",
            r"diarrhea.{0,40}within\s+(\d+)\s+hours?",
            r"emesis.{0,40}within\s+(\d+)\s+hours?",
        ]:
            m = re.search(excl_pattern, text, re.IGNORECASE)
            if m:
                excluded.append(clean_text(m.group(0))[:150])
        if excluded:
            spec.excluded_conditions = excluded
            found_anything = True

        return spec if found_anything else None


# ---------------------------------------------------------------------------
# Rule generator for timing rules (feeds ExtractedRule list)
# ---------------------------------------------------------------------------

class TimingRuleGenerator:
    """
    Converts TimingDefinition objects into ExtractedRule entries
    with structured logic and SAS pseudocode for the rule engine output.
    """

    def generate(self, timing_defs: List[TimingDefinition]) -> List[ProgrammingRule]:
        """Convert TimingDefinitions into ProgrammingRules for export."""
        rules: List[ProgrammingRule] = []
        for td in timing_defs:
            if td.pseudocode:
                rules.append(ProgrammingRule(
                    rule=td.description,
                    rule_type=RuleType.TIMING_DEFINITION,
                    severity="mandatory" if td.category in (
                        "study_day_anchor", "ady_formula", "teae_window"
                    ) else "recommended",
                    sas_hint=td.pseudocode,
                    confidence=td.confidence,
                    source_text=truncate(td.verbatim_text, 300),
                ))
        return rules
