"""
Entity extraction: populations, endpoints, outputs (TLFs), visit schedules,
analysis methods, and study metadata from parsed SAP documents.
"""
from __future__ import annotations

import re
import uuid
from typing import Dict, List, Optional, Tuple

from src.models.schema import (
    AnalysisOutput, AnalysisSpec, DataSpecification, Endpoint,
    EndpointClassification, Estimand, IntercurrentEvent, MockShell,
    Multiplicity, OutputClass, OutputType, Population, ProgrammingRule,
    RuleType, StudyMetadata, Traceability, VisitWindow
)
from src.parsers import ParsedDocument, ParsedSection
from src.utils import (
    POPULATION_NORMALIZATION, POPULATION_FLAG_MAP, POPULATION_DATASET_MAP,
    METHOD_NORMALIZATION, clean_text, classify_output, compute_confidence,
    extract_number_from_title, get_logger, infer_adam_datasets,
    normalize_output_number, normalize_population, normalize_method,
    slugify, truncate
)

logger = get_logger(__name__)

# Lazy import to avoid circular dependency
def _get_pkpd_extractor():
    from src.entity_extraction.pkpd_timing import PKPDExtractor, StudyTimingExtractor, TimingRuleGenerator
    return PKPDExtractor, StudyTimingExtractor, TimingRuleGenerator


# ---------------------------------------------------------------------------
# Study metadata extractor
# ---------------------------------------------------------------------------

class StudyMetadataExtractor:
    """Extract study-level metadata from document preamble and title sections."""

    _PROTOCOL_PATTERNS = [
        r"protocol\s+(?:number|no\.?|id|identifier)[\s:]+([A-Z0-9][A-Z0-9\-_]{2,20})",
        r"study\s+(?:number|no\.?|id)[\s:]+([A-Z0-9][A-Z0-9\-_]{2,20})",
        r"(?:protocol|study)\s+([A-Z]{2,5}-\d{3,6}(?:-\d+)?)",
    ]
    _NCT_PATTERN = re.compile(r"NCT\d{8}")
    _EUDRACT_PATTERN = re.compile(r"\d{4}-\d{6}-\d{2}")
    _PHASE_PATTERN = re.compile(r"phase\s+([123456IV]+(?:/[123IV]+)?)", re.IGNORECASE)
    _SPONSOR_PATTERN = re.compile(r"sponsor[\s:]+([A-Z][A-Za-z\s,\.]{5,60}?)(?:\n|\.|\|)", re.IGNORECASE)
    _BLINDING_PATTERN = re.compile(
        r"(open.label|single.blind|double.blind|triple.blind|unblinded)", re.IGNORECASE
    )
    _RAND_RATIO_PATTERN = re.compile(r"randomized?\s+(?:in\s+(?:a\s+)?)?(\d+:\d+(?::\d+)?)\s+ratio", re.IGNORECASE)

    def extract(self, document: ParsedDocument) -> StudyMetadata:
        # Use first 5000 chars of full text as preamble
        preamble = document.full_text[:5000]
        meta = StudyMetadata()

        # Protocol ID
        for pattern in self._PROTOCOL_PATTERNS:
            m = re.search(pattern, preamble, re.IGNORECASE)
            if m:
                meta.protocol_id = m.group(1).strip()
                break

        # NCT
        m = self._NCT_PATTERN.search(preamble)
        if m:
            meta.nct_number = m.group(0)

        # EudraCT
        m = self._EUDRACT_PATTERN.search(preamble)
        if m:
            meta.eudract_number = m.group(0)

        # Phase
        m = self._PHASE_PATTERN.search(preamble)
        if m:
            meta.phase = m.group(1).upper()

        # Sponsor
        m = self._SPONSOR_PATTERN.search(preamble)
        if m:
            meta.sponsor = m.group(1).strip().rstrip(",.")

        # Study title — look for "title" or first long sentence
        title_match = re.search(r"(?:study|trial)\s+title[\s:]+(.{20,200}?)(?:\n|protocol)", preamble, re.IGNORECASE | re.DOTALL)
        if title_match:
            meta.study_title = clean_text(title_match.group(1))
        elif document.sections:
            meta.study_title = document.sections[0].title[:200]

        # Blinding
        m = self._BLINDING_PATTERN.search(preamble)
        if m:
            meta.blinding = m.group(1).replace("-", " ").title()

        # Randomization ratio
        m = self._RAND_RATIO_PATTERN.search(preamble)
        if m:
            meta.randomization_ratio = m.group(1)

        # Regulatory agencies (heuristic)
        agencies = []
        for agency in ["FDA", "EMA", "PMDA", "Health Canada", "MHRA"]:
            if agency.lower() in preamble.lower():
                agencies.append(agency)
        # NOTE: Never default to FDA — leave empty and let QC flag it
        meta.regulatory_agencies = agencies

        return meta


# ---------------------------------------------------------------------------
# Population extractor
# ---------------------------------------------------------------------------

class PopulationExtractor:
    """Extract analysis population definitions from SAP text."""

    _POPULATION_SECTION_KEYWORDS = [
        "analysis population", "study population", "patient population",
        "analysis set", "analysis sets", "populations"
    ]

    _DEFINITION_PATTERNS = [
        r"(?:the\s+)?(?P<pop_name>[A-Z][A-Za-z\s]{3,40}?)\s+(?:population|set|analysis\s+set)\s+(?:is\s+|will\s+be\s+)?(?:defined\s+as|consists?\s+of|includes?)\s+(?P<definition>.{20,300}?)(?:\.|;|\n\n)",
        r"(?P<pop_name>ITT|FAS|mITT|PP|Safety|SAF|PK|Evaluable|Randomized|Full\s+Analysis)\s+(?:population|set)[\s:]+(?P<definition>.{10,200}?)(?:\.|;|\n\n)",
    ]

    def extract(self, document: ParsedDocument) -> List[Population]:
        populations: List[Population] = []
        seen_abbrevs: set = set()

        # Look in population-related sections AND their children
        pop_section_ids: set = set()
        pop_sections = []
        for section in document.sections:
            if any(kw in section.title.lower() for kw in self._POPULATION_SECTION_KEYWORDS):
                pop_sections.append(section)
                pop_section_ids.add(section.section_id)

        # Include child sections (subsections) of matched population sections
        if pop_sections:
            for section in document.sections:
                if (section.parent_id in pop_section_ids
                        and section.section_id not in pop_section_ids):
                    pop_sections.append(section)

        # Fall back to all sections if nothing found
        all_sections = pop_sections if pop_sections else document.sections

        for section in all_sections:
            text = section.get_text()
            if not text:
                continue
            found = self._extract_from_text(text, section.section_id, section.page_start)
            for pop in found:
                if pop.abbreviation not in seen_abbrevs:
                    seen_abbrevs.add(pop.abbreviation)
                    populations.append(pop)

        # Always ensure at least ITT and Safety
        for abbrev, label, order in [("ITT", "Intent-to-Treat", 1), ("SAF", "Safety", 2)]:
            if abbrev not in seen_abbrevs:
                populations.append(self._make_default_population(abbrev, label, order))

        return sorted(populations, key=lambda p: p.hierarchy_order)

    def _extract_from_text(
        self,
        text: str,
        section_id: str,
        page: int
    ) -> List[Population]:
        results: List[Population] = []

        # Try structured patterns
        for pattern in self._DEFINITION_PATTERNS:
            for m in re.finditer(pattern, text, re.IGNORECASE | re.DOTALL):
                pop_name_raw = clean_text(m.group("pop_name"))
                definition = clean_text(m.group("definition"))

                normalized = normalize_population(pop_name_raw)
                if normalized is None:
                    # Try normalizing the combined string
                    normalized = normalize_population(pop_name_raw + " population")
                if normalized is None:
                    continue

                label, abbrev, order = normalized
                flag = POPULATION_FLAG_MAP.get(abbrev, abbrev + "FL")
                dataset = POPULATION_DATASET_MAP.get(abbrev, "ADSL")

                confidence = compute_confidence(
                    sum([
                        bool(definition),
                        len(definition) > 30,
                        bool(flag),
                    ]),
                    3,
                    base=0.75
                )

                results.append(Population(
                    population_id=f"pop_{slugify(abbrev)}",
                    label=label,
                    abbreviation=abbrev,
                    hierarchy_order=order,
                    formal_definition=truncate(definition, 500),
                    adam_flag_variable=flag,
                    adam_dataset=dataset,
                    derivation_rule=f"where {flag} = 'Y';",
                    source_section=section_id,
                    source_page=page,
                    source_text=truncate(m.group(0), 300),
                    confidence=confidence,
                ))

        # Fallback: scan for any population mentions
        for norm_pattern, (label, abbrev, order) in POPULATION_NORMALIZATION.items():
            if re.search(norm_pattern, text, re.IGNORECASE):
                # Check not already found
                if not any(abbrev == r.abbreviation for r in results):
                    flag = POPULATION_FLAG_MAP.get(abbrev, abbrev + "FL")
                    results.append(Population(
                        population_id=f"pop_{slugify(abbrev)}",
                        label=label,
                        abbreviation=abbrev,
                        hierarchy_order=order,
                        adam_flag_variable=flag,
                        adam_dataset=POPULATION_DATASET_MAP.get(abbrev, "ADSL"),
                        derivation_rule=f"where {flag} = 'Y';",
                        source_section=section_id,
                        source_page=page,
                        confidence=0.72,
                    ))

        return results

    @staticmethod
    def _make_default_population(abbrev: str, label: str, order: int) -> Population:
        flag = POPULATION_FLAG_MAP.get(abbrev, abbrev + "FL")
        return Population(
            population_id=f"pop_{abbrev.lower()}",
            label=label,
            abbreviation=abbrev,
            hierarchy_order=order,
            formal_definition=f"All {label} subjects",
            adam_flag_variable=flag,
            adam_dataset="ADSL",
            derivation_rule=f"where {flag} = 'Y';",
            confidence=0.60,
        )


# ---------------------------------------------------------------------------
# Endpoint extractor
# ---------------------------------------------------------------------------

class EndpointExtractor:
    """Extract primary, secondary and safety endpoints from SAP."""

    _ENDPOINT_SECTION_KEYWORDS = [
        "endpoint", "objective", "efficacy", "outcome"
    ]

    _PRIMARY_PATTERNS = [
        r"primary\s+(?:efficacy\s+)?endpoint\s+(?:is|:)\s+(.{20,300}?)(?:\.|;|\n)",
        r"primary\s+outcome\s+(?:measure|variable)\s+(?:is|:)\s+(.{20,300}?)(?:\.|;|\n)",
        r"the\s+primary\s+endpoint\s+(?:of\s+this\s+study\s+)?(?:is|will\s+be)\s+(.{20,300}?)(?:\.|;|\n)",
    ]
    _SECONDARY_PATTERNS = [
        r"secondary\s+(?:efficacy\s+)?endpoint[s]?\s+(?:include|are|:)\s+(.{20,500}?)(?:\n\n|\.\s+[A-Z])",
        r"key\s+secondary\s+endpoint\s+(?:is|:)\s+(.{20,300}?)(?:\.|;|\n)",
    ]
    _SAFETY_PATTERNS = [
        r"safety\s+endpoint[s]?\s+(?:include|are)[:\s]+(.+)",
        r"safety\s+(?:and\s+tolerability\s+)?(?:variables?|endpoints?|assessments?)\s+(?:include|are)[:\s]+(.+)",
    ]
    _TIMEPOINT_PATTERN = re.compile(r"(?:at\s+|through\s+)?(?:week|day|month|year)\s+\d+", re.IGNORECASE)
    _INSTRUMENT_PATTERN = re.compile(
        r"\b([A-Z]{2,10}(?:-\d+)?(?:\s+scale|\s+score|\s+questionnaire)?)\b(?:\s+score)?",
    )

    def extract(self, document: ParsedDocument) -> List[Endpoint]:
        endpoints: List[Endpoint] = []
        seen: set = set()

        for section in document.sections:
            text = section.get_text()
            if not text:
                continue

            # Primary
            for pattern in self._PRIMARY_PATTERNS:
                for m in re.finditer(pattern, text, re.IGNORECASE | re.DOTALL):
                    desc = clean_text(m.group(1))
                    if desc and desc not in seen:
                        seen.add(desc)
                        endpoints.append(self._make_endpoint(
                            desc, EndpointClassification.PRIMARY,
                            section.section_id, section.page_start,
                            order=1
                        ))

            # Key secondary and secondary
            for pattern in self._SECONDARY_PATTERNS:
                for m in re.finditer(pattern, text, re.IGNORECASE | re.DOTALL):
                    desc = clean_text(m.group(1))
                    # Split multi-endpoint blocks
                    sub_endpoints = re.split(r";\s*|\n\s*[-*\u2022]\s*", desc)
                    for sub in sub_endpoints:
                        sub = clean_text(sub)
                        if len(sub) > 15 and sub not in seen:
                            seen.add(sub)
                            cls = (EndpointClassification.KEY_SECONDARY
                                   if "key" in pattern else EndpointClassification.SECONDARY)
                            endpoints.append(self._make_endpoint(
                                sub, cls,
                                section.section_id, section.page_start
                            ))

            # Safety
            for pattern in self._SAFETY_PATTERNS:
                for m in re.finditer(pattern, text, re.IGNORECASE | re.DOTALL):
                    desc = clean_text(m.group(1))
                    sub_endpoints = re.split(r";\s*|\n\s*[-*\u2022]\s*", desc)
                    for sub in sub_endpoints:
                        sub = clean_text(sub)
                        if len(sub) > 15 and sub not in seen:
                            seen.add(sub)
                            endpoints.append(self._make_endpoint(
                                sub, EndpointClassification.SAFETY,
                                section.section_id, section.page_start
                            ))

        return endpoints

    def _make_endpoint(
        self,
        description: str,
        classification: EndpointClassification,
        section_id: str,
        page: int,
        order: Optional[int] = None,
    ) -> Endpoint:
        timepoints = self._TIMEPOINT_PATTERN.findall(description)
        confidence = compute_confidence(
            sum([bool(timepoints), len(description) > 30, True]),
            3, base=0.75
        )
        ep_id = f"ep_{slugify(description[:40])}_{uuid.uuid4().hex[:6]}"
        adam_vars = ["AVAL", "BASE", "CHG"]
        if "change" in description.lower():
            adam_vars = ["AVAL", "BASE", "CHG", "PCHG"]
        if "time" in description.lower() and "event" in description.lower():
            adam_vars = ["AVAL", "CNSR", "ADT"]
        # Infer likely ADaM datasets from endpoint description
        from src.utils import infer_adam_datasets
        adam_datasets = infer_adam_datasets(description)

        return Endpoint(
            endpoint_id=ep_id,
            classification=classification,
            testing_order=order,
            description=truncate(description, 300),
            timepoints=[t.strip() for t in timepoints],
            adam_variables=adam_vars,
            adam_datasets=adam_datasets,
            source_section=section_id,
            source_page=page,
            source_text=truncate(description, 200),
            confidence=confidence,
        )


# ---------------------------------------------------------------------------
# Visit schedule extractor
# ---------------------------------------------------------------------------

class VisitScheduleExtractor:
    """Extract visit windows and schedules from SAP."""

    _VISIT_SECTION_KEYWORDS = ["visit schedule", "visit window", "assessment schedule", "schedule of events"]

    _WINDOW_PATTERN = re.compile(
        r"(?:week|day|visit)\s+(\d+).{0,30}(?:window|days?)\s+(?:is\s+|of\s+)?"
        r"(?:day|week)\s+(\d+)\s+to\s+(?:day|week)\s+(\d+)",
        re.IGNORECASE
    )
    _VISIT_ROW_PATTERN = re.compile(
        r"(?:Week|Day|Visit)\s+(\d+(?:\.\d+)?)\s+(?:\((?:Day|Week)\s+(\d+)\))?",
        re.IGNORECASE
    )

    def extract(self, document: ParsedDocument) -> List[VisitWindow]:
        visits: List[VisitWindow] = []
        visit_num = 0

        for section in document.sections:
            if not any(kw in section.title.lower() for kw in self._VISIT_SECTION_KEYWORDS):
                # Still scan all sections for window patterns
                pass
            text = section.get_text()
            if not text:
                continue

            # Extract from tables in section
            for table in section.tables:
                table_visits = self._extract_from_table(table)
                visits.extend(table_visits)

            # Extract from text patterns
            for m in self._WINDOW_PATTERN.finditer(text):
                label = f"Week {m.group(1)}"
                day_from = int(m.group(2))
                day_to = int(m.group(3))
                nominal = (day_from + day_to) // 2
                vid = f"vis_w{m.group(1).zfill(3)}"
                if not any(v.visit_id == vid for v in visits):
                    visits.append(VisitWindow(
                        visit_id=vid,
                        visit_label=label,
                        visit_type="On-treatment",
                        nominal_day=nominal,
                        window_pre_days=nominal - day_from,
                        window_post_days=day_to - nominal,
                        window_rule=truncate(m.group(0), 200),
                        adam_visit_value=label.upper(),
                        adam_visitnum=float(m.group(1)),
                        analysis_visit_flag=True,
                        source_page=section.page_start,
                        confidence=0.88,
                    ))
                    visit_num += 1

        # Ensure basic visits if none found
        if not visits:
            visits = self._default_visits()

        return sorted(visits, key=lambda v: v.adam_visitnum or 0)

    def _extract_from_table(self, table) -> List[VisitWindow]:
        visits: List[VisitWindow] = []
        if not table.rows:
            return visits
        header = [c.lower() for c in table.rows[0]] if table.rows else []

        # Look for visit column
        visit_col = next((i for i, h in enumerate(header) if "visit" in h or "week" in h or "day" in h), None)
        window_col = next((i for i, h in enumerate(header) if "window" in h), None)

        for row in table.rows[1:]:
            if not row or not any(cell.strip() for cell in row):
                continue
            label = row[visit_col].strip() if visit_col is not None and visit_col < len(row) else ""
            if not label:
                continue
            # Parse week number
            week_m = re.search(r"(?:week|day)\s+(\d+)", label, re.IGNORECASE)
            if week_m:
                week_num = int(week_m.group(1))
                vid = f"vis_w{str(week_num).zfill(3)}"
                window_text = row[window_col].strip() if window_col is not None and window_col < len(row) else ""
                # Try parse window "Day X to Day Y"
                w_m = re.search(r"(?:day|week)\s+(\d+)\s+to\s+(?:day|week)\s+(\d+)", window_text, re.IGNORECASE)
                pre = post = None
                nominal = week_num * 7 if "week" in label.lower() else week_num
                if w_m:
                    d_from, d_to = int(w_m.group(1)), int(w_m.group(2))
                    nominal = (d_from + d_to) // 2
                    pre = nominal - d_from
                    post = d_to - nominal

                visits.append(VisitWindow(
                    visit_id=vid,
                    visit_label=label,
                    visit_type="On-treatment",
                    nominal_day=nominal,
                    window_pre_days=pre,
                    window_post_days=post,
                    window_rule=window_text or label,
                    adam_visit_value=label.upper(),
                    adam_visitnum=float(week_num),
                    analysis_visit_flag=True,
                    confidence=0.85,
                ))
        return visits

    @staticmethod
    def _default_visits() -> List[VisitWindow]:
        default_schedule = [
            ("vis_scr", "Screening", -14, -21, -7, "Screening", 0),
            ("vis_d1", "Day 1 (Baseline)", 1, 1, 1, "BASELINE", 0),
            ("vis_w4", "Week 4", 29, 22, 35, "WEEK 4", 4),
            ("vis_w8", "Week 8", 57, 50, 64, "WEEK 8", 8),
            ("vis_w12", "Week 12", 85, 78, 92, "WEEK 12", 12),
            ("vis_eot", "End of Treatment", -1, None, None, "END OF TREATMENT", -1),
        ]
        visits = []
        for vid, label, nominal, pre_day, post_day, adam_val, visitnum in default_schedule:
            pre = (nominal - pre_day) if pre_day and nominal > 0 else None
            post = (post_day - nominal) if post_day and nominal > 0 else None
            visits.append(VisitWindow(
                visit_id=vid,
                visit_label=label,
                nominal_day=nominal if nominal > 0 else None,
                window_pre_days=pre,
                window_post_days=post,
                adam_visit_value=adam_val,
                adam_visitnum=float(visitnum) if visitnum >= 0 else None,
                analysis_visit_flag=visitnum > 0,
                primary_timepoint=(visitnum == 12),
                confidence=0.50,
            ))
        return visits


# ---------------------------------------------------------------------------
# Output (TLF) extractor
# ---------------------------------------------------------------------------

class OutputExtractor:
    """Extract Table/Listing/Figure outputs from SAP document."""

    _TLF_TITLE_PATTERN = re.compile(
        r"(?:^|\n|\s)(?P<type>Table|Listing|Figure|Appendix)\s+"
        r"(?P<num>\d+(?:\.\d+)+)\s*[:.]?\s*(?P<title>[^\n]{5,200})",
        re.IGNORECASE | re.MULTILINE
    )
    _TLF_SHORTREF_PATTERN = re.compile(
        r"(?:^|\s)(?P<type>[TLF])(?P<num>\d+(?:\.\d+)+)\s*[:.]?\s*(?P<title>[^\n]{5,150})",
        re.MULTILINE
    )
    _TOC_PATTERN = re.compile(
        r"(?:list\s+of\s+(?:tables|figures|listings)|table\s+of\s+contents)",
        re.IGNORECASE
    )

    @staticmethod
    def _split_tlf_entries(text: str):
        """Split text on TLF boundaries, return (type_str, number, clean_title) tuples."""
        parts = re.split(r"(?=(?:Table|Listing|Figure|Appendix)\s+\d+\.\d)", text, flags=re.IGNORECASE)
        results = []
        for part in parts:
            part = part.strip()
            if not part:
                continue
            m = re.match(
                r"(Table|Listing|Figure|Appendix)\s+(\d+(?:\.\d+)+)\s*[:.]?\s*(.{5,200})",
                part, re.IGNORECASE | re.DOTALL
            )
            if m:
                # Stop title at next TLF reference
                raw_title = re.split(r"\s+(?:Table|Listing|Figure|Appendix)\s+\d", m.group(3))[0]
                raw_title = clean_text(raw_title)
                if raw_title:
                    results.append((m.group(1), m.group(2), raw_title))
        return results

    def extract(
        self,
        document: ParsedDocument,
        populations: List[Population],
        endpoints: List[Endpoint],
    ) -> List[AnalysisOutput]:
        outputs: List[AnalysisOutput] = []
        # Deduplicate on (normalized_type, number) so Table 14.1.1 != Figure 14.1.1
        seen_type_nums: set = set()

        for section in document.sections:
            text = section.get_text()
            if not text:
                continue

            # Skip TOC sections
            if self._TOC_PATTERN.search(section.title):
                continue

            # Split-based extraction (handles run-together TLF lines)
            for type_str, num, title in self._split_tlf_entries(text):
                key = (type_str.upper()[:1], num)  # (T/L/F/A, number)
                if key in seen_type_nums:
                    continue
                seen_type_nums.add(key)
                outputs.append(self._build_output(
                    output_type_str=type_str,
                    number=num,
                    title=title,
                    section=section,
                    populations=populations,
                    endpoints=endpoints,
                    display_order=len(outputs) + 1,
                ))

            # Short reference pattern (T14.1.1)
            for m in self._TLF_SHORTREF_PATTERN.finditer(text):
                num = m.group("num")
                type_map = {"T": "Table", "L": "Listing", "F": "Figure"}
                type_str = type_map.get(m.group("type").upper(), "Table")
                key = (type_str[0], num)
                if key in seen_type_nums:
                    continue
                seen_type_nums.add(key)
                outputs.append(self._build_output(
                    output_type_str=type_str,
                    number=num,
                    title=clean_text(m.group("title")),
                    section=section,
                    populations=populations,
                    endpoints=endpoints,
                    display_order=len(outputs) + 1,
                ))

        return sorted(outputs, key=lambda o: (o.output_type.value, o.output_number or ""))

    def _build_output(
        self,
        output_type_str: str,
        number: str,
        title: str,
        section: "ParsedSection",
        populations: List[Population],
        endpoints: List[Endpoint],
        display_order: int,
    ) -> AnalysisOutput:
        output_type = OutputType.TABLE
        for ot in OutputType:
            if ot.value.lower() == output_type_str.lower():
                output_type = ot
                break

        output_class_str = classify_output(title, section.get_text()[:500])
        output_class = OutputClass.OTHER
        for oc in OutputClass:
            if oc.value.lower() == output_class_str.lower():
                output_class = oc
                break

        # Match population
        matched_pop = self._match_population(title + " " + section.get_text()[:300], populations)

        # Match endpoints
        matched_eps = self._match_endpoints(title, endpoints)

        # Infer datasets
        datasets = infer_adam_datasets(title, section.get_text()[:500])

        # Extract analysis methods
        methods = self._extract_methods(section.get_text())

        # Extract programming rules
        prog_rules = self._extract_programming_rules(section.get_text())

        # Build analysis spec
        analysis = AnalysisSpec(
            methods=methods,
            confidence=0.80 if methods else 0.50,
        ) if methods else None

        # Data spec
        data_spec = DataSpecification(
            input_datasets=datasets,
            key_variables={
                "by_vars": ["USUBJID", "TRT01PN"],
                "analysis_vars": ["AVAL", "BASE", "CHG"],
                "filter_vars": [matched_pop.adam_flag_variable] if matched_pop and matched_pop.adam_flag_variable else [],
            }
        )

        output_id = f"out_{output_type.value[0].lower()}{number.replace('.', '_')}"
        full_title = f"{output_type.value} {number}: {title}"

        # Confidence
        confidence = compute_confidence(
            sum([
                bool(matched_pop),
                bool(matched_eps),
                bool(methods),
                bool(datasets),
                bool(title),
            ]),
            5,
            base=0.65
        )

        return AnalysisOutput(
            output_id=output_id,
            output_type=output_type,
            output_class=output_class,
            output_number=number,
            title=title,
            full_title=full_title,
            section_id=section.section_id,
            display_order=display_order,
            population=matched_pop,
            endpoints=[ep for ep in matched_eps],
            analysis=analysis,
            data_specification=data_spec,
            programming_rules=prog_rules,
            traceability=Traceability(
                page_number=section.page_start,
                section_id=section.section_id,
                source_excerpt=truncate(title, 150),
                confidence=confidence,
            ),
            confidence_score=confidence,
        )

    @staticmethod
    def _match_population(
        text: str,
        populations: List[Population]
    ) -> Optional[Population]:
        """Find the best matching population for a given text snippet."""
        text_lower = text.lower()
        # Check abbreviations first (most specific)
        for pop in sorted(populations, key=lambda p: p.hierarchy_order):
            if pop.abbreviation.lower() in text_lower:
                return pop
        # Check labels
        for pop in sorted(populations, key=lambda p: p.hierarchy_order):
            if pop.label.lower() in text_lower:
                return pop
        # No match found — return None so QC can flag missing population
        # Do NOT silently default to first population (would misclassify PK/biomarker outputs)
        return None

    @staticmethod
    def _match_endpoints(title: str, endpoints: List[Endpoint]) -> List[Endpoint]:
        """Find endpoints mentioned in output title."""
        matched = []
        title_lower = title.lower()
        for ep in endpoints:
            # Check key words from endpoint description
            words = [w for w in ep.description.lower().split() if len(w) > 4]
            if sum(1 for w in words if w in title_lower) >= 2:
                matched.append(ep)
        return matched[:3]  # cap at 3

    @staticmethod
    def _extract_methods(text: str) -> List[str]:
        """Extract analysis method names from section text."""
        methods = []
        for pattern, name in METHOD_NORMALIZATION.items():
            if re.search(pattern, text, re.IGNORECASE):
                if name not in methods:
                    methods.append(name)
        return methods

    @staticmethod
    def _extract_programming_rules(text: str) -> List[ProgrammingRule]:
        """Extract explicit programming notes from SAP text."""
        rules: List[ProgrammingRule] = []

        # Baseline definition
        if re.search(r"baseline.{0,60}last\s+non.missing", text, re.IGNORECASE):
            rules.append(ProgrammingRule(
                rule="Baseline = last non-missing value prior to first dose",
                rule_type=RuleType.BASELINE_DEFINITION,
                severity="mandatory",
                sas_hint="ABLFL = 'Y'",
                confidence=0.92,
                source_text="Baseline defined as last non-missing value prior to first dose.",
            ))

        # Filter patterns
        for flag in ["ITTFL", "SAFFL", "PPROTFL", "FASFL"]:
            if re.search(rf"\b{flag}\b", text):
                rules.append(ProgrammingRule(
                    rule=f"{flag} = 'Y'",
                    rule_type=RuleType.FILTER,
                    severity="mandatory",
                    sas_hint=f"where {flag} = 'Y';",
                    confidence=0.95,
                ))

        # CHG derivation
        if re.search(r"change\s+from\s+baseline", text, re.IGNORECASE):
            rules.append(ProgrammingRule(
                rule="CHG = AVAL - BASE",
                rule_type=RuleType.DERIVATION,
                severity="mandatory",
                sas_hint="CHG = AVAL - BASE;",
                confidence=0.97,
            ))

        return rules
