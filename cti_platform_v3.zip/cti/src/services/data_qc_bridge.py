"""
DataQCBridge: optional pluggable module for cross-validating extracted
clinical intelligence against SAS datasets (ADaM/SDTM) and figure metadata.

Can be used standalone or integrated into the pipeline.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from src.models.schema import (
    AnalysisOutput, ClinicalIntelligenceSchema, QCIssue, QCSeverity
)
from src.utils import get_logger

logger = get_logger(__name__)


@dataclass
class DatasetProfile:
    """Profile of a SAS-like dataset (from CSV or metadata JSON)."""
    dataset_name: str
    variables: List[str] = field(default_factory=list)
    n_records: int = 0
    subjects: int = 0
    treatment_values: List[str] = field(default_factory=list)
    visit_values: List[str] = field(default_factory=list)
    flag_variables: List[str] = field(default_factory=list)
    source_file: Optional[str] = None


@dataclass
class FigureMetadata:
    """Metadata about a figure/TLF from PDF or RTF."""
    figure_id: str
    title: str
    page: int
    source_file: str


@dataclass
class BridgeResult:
    """Result from a DataQCBridge validation run."""
    issues: List[QCIssue] = field(default_factory=list)
    dataset_profiles: List[DatasetProfile] = field(default_factory=list)
    figure_metadata: List[FigureMetadata] = field(default_factory=list)
    cross_check_summary: Dict[str, Any] = field(default_factory=dict)


class DataQCBridge:
    """
    Cross-validates SAP-extracted intelligence against:
    1. ADaM/SDTM dataset metadata (CSV or JSON profiles)
    2. Figure/TLF metadata from shell documents or PDFs
    3. SAS dataset variable lists

    Usage:
        bridge = DataQCBridge()
        result = bridge.validate(schema, dataset_dir=Path("./data"), figure_dir=Path("./figures"))
        schema.qc_report.issues.extend(result.issues)
    """

    def __init__(self) -> None:
        self._dataset_profiles: List[DatasetProfile] = []
        self._figure_metadata: List[FigureMetadata] = []

    def validate(
        self,
        schema: ClinicalIntelligenceSchema,
        dataset_dir: Optional[Path] = None,
        figure_dir: Optional[Path] = None,
        dataset_metadata_json: Optional[Path] = None,
    ) -> BridgeResult:
        """
        Run all cross-validation checks.

        Args:
            schema: Populated ClinicalIntelligenceSchema.
            dataset_dir: Directory containing CSV files (simulating ADaM datasets).
            figure_dir: Directory containing figure metadata JSON files.
            dataset_metadata_json: Pre-computed dataset metadata JSON.

        Returns:
            BridgeResult with issues and profiles.
        """
        result = BridgeResult()

        # 1. Load dataset profiles
        if dataset_metadata_json and dataset_metadata_json.exists():
            result.dataset_profiles = self._load_dataset_metadata(dataset_metadata_json)
        elif dataset_dir and dataset_dir.exists():
            result.dataset_profiles = self._profile_csv_datasets(dataset_dir)

        self._dataset_profiles = result.dataset_profiles

        # 2. Load figure metadata
        if figure_dir and figure_dir.exists():
            result.figure_metadata = self._load_figure_metadata(figure_dir)
        self._figure_metadata = result.figure_metadata

        # 3. Run cross-checks
        result.issues.extend(self._check_variable_existence(schema))
        result.issues.extend(self._check_population_flags(schema))
        result.issues.extend(self._check_figure_titles(schema))
        result.issues.extend(self._check_dataset_coverage(schema))

        result.cross_check_summary = {
            "datasets_profiled": len(result.dataset_profiles),
            "figures_found": len(result.figure_metadata),
            "issues_raised": len(result.issues),
            "errors": sum(1 for i in result.issues if i.severity == QCSeverity.ERROR),
            "warnings": sum(1 for i in result.issues if i.severity == QCSeverity.WARNING),
        }

        logger.info(
            "DataQCBridge: %d datasets profiled, %d figures, %d issues",
            len(result.dataset_profiles), len(result.figure_metadata), len(result.issues)
        )
        return result

    # ------------------------------------------------------------------
    # Dataset profiling
    # ------------------------------------------------------------------

    def _profile_csv_datasets(self, directory: Path) -> List[DatasetProfile]:
        """Profile CSV files as simulated ADaM datasets."""
        profiles: List[DatasetProfile] = []
        for csv_file in directory.glob("*.csv"):
            try:
                profile = self._profile_single_csv(csv_file)
                if profile:
                    profiles.append(profile)
            except Exception as exc:
                logger.warning("Could not profile %s: %s", csv_file.name, exc)
        return profiles

    @staticmethod
    def _profile_single_csv(csv_file: Path) -> Optional[DatasetProfile]:
        """Read CSV header and basic stats without loading full file."""
        try:
            with csv_file.open("r", encoding="utf-8", errors="replace") as f:
                header_line = f.readline().strip()
                variables = [v.strip().strip('"') for v in header_line.split(",")]

                # Count records (lines)
                n_records = sum(1 for _ in f)

            dataset_name = csv_file.stem.upper()

            # Detect flag variables (columns ending in FL)
            flag_vars = [v for v in variables if v.endswith("FL")]

            return DatasetProfile(
                dataset_name=dataset_name,
                variables=variables,
                n_records=n_records,
                flag_variables=flag_vars,
                source_file=str(csv_file),
            )
        except Exception as exc:
            logger.warning("CSV profile failed for %s: %s", csv_file.name, exc)
            return None

    @staticmethod
    def _load_dataset_metadata(json_file: Path) -> List[DatasetProfile]:
        """Load pre-computed dataset metadata from JSON."""
        try:
            with json_file.open("r", encoding="utf-8") as f:
                data = json.load(f)
            profiles = []
            for item in data if isinstance(data, list) else [data]:
                profiles.append(DatasetProfile(
                    dataset_name=item.get("dataset_name", "UNKNOWN"),
                    variables=item.get("variables", []),
                    n_records=item.get("n_records", 0),
                    subjects=item.get("subjects", 0),
                    treatment_values=item.get("treatment_values", []),
                    visit_values=item.get("visit_values", []),
                    flag_variables=item.get("flag_variables", []),
                    source_file=item.get("source_file"),
                ))
            return profiles
        except Exception as exc:
            logger.error("Failed to load dataset metadata: %s", exc)
            return []

    # ------------------------------------------------------------------
    # Figure metadata
    # ------------------------------------------------------------------

    @staticmethod
    def _load_figure_metadata(directory: Path) -> List[FigureMetadata]:
        """Load figure metadata from JSON files in directory."""
        figures: List[FigureMetadata] = []
        for json_file in directory.glob("*.json"):
            try:
                with json_file.open("r", encoding="utf-8") as f:
                    data = json.load(f)
                items = data if isinstance(data, list) else [data]
                for item in items:
                    figures.append(FigureMetadata(
                        figure_id=item.get("figure_id", ""),
                        title=item.get("title", ""),
                        page=item.get("page", 0),
                        source_file=str(json_file),
                    ))
            except Exception as exc:
                logger.warning("Could not load figure metadata from %s: %s", json_file.name, exc)
        return figures

    # ------------------------------------------------------------------
    # Cross-validation checks
    # ------------------------------------------------------------------

    def _check_variable_existence(self, schema: ClinicalIntelligenceSchema) -> List[QCIssue]:
        """Check that variables referenced in outputs exist in dataset profiles."""
        issues: List[QCIssue] = []
        if not self._dataset_profiles:
            return issues

        # Build variable index: {dataset_name: set(variables)}
        var_index: Dict[str, set] = {
            p.dataset_name: set(p.variables)
            for p in self._dataset_profiles
        }

        for output in schema.outputs_master:
            if not output.data_specification:
                continue
            for ds in output.data_specification.input_datasets:
                if ds not in var_index:
                    issues.append(QCIssue(
                        severity=QCSeverity.WARNING,
                        category="DataQCBridge",
                        output_id=output.output_id,
                        message=f"Dataset '{ds}' referenced by output {output.output_number} not found in profiled datasets",
                        suggested_fix=f"Ensure {ds} dataset is included in dataset directory",
                    ))
                    continue

                ds_vars = var_index[ds]
                all_key_vars = []
                for var_list in output.data_specification.key_variables.values():
                    all_key_vars.extend(var_list)

                for var in all_key_vars:
                    if var and var not in ds_vars:
                        issues.append(QCIssue(
                            severity=QCSeverity.WARNING,
                            category="DataQCBridge",
                            output_id=output.output_id,
                            message=f"Variable '{var}' referenced in output {output.output_number} not found in dataset {ds}",
                            suggested_fix=f"Verify {var} is created in {ds} programming specifications",
                        ))
        return issues

    def _check_population_flags(self, schema: ClinicalIntelligenceSchema) -> List[QCIssue]:
        """Verify population flag variables exist in ADSL dataset profile."""
        issues: List[QCIssue] = []
        if not self._dataset_profiles:
            return issues

        adsl_profile = next((p for p in self._dataset_profiles if p.dataset_name == "ADSL"), None)
        if not adsl_profile:
            return issues

        adsl_vars = set(adsl_profile.variables)
        for pop in schema.populations:
            if pop.adam_flag_variable and pop.adam_flag_variable not in adsl_vars:
                issues.append(QCIssue(
                    severity=QCSeverity.ERROR,
                    category="DataQCBridge",
                    output_id=pop.population_id,
                    message=f"Population flag '{pop.adam_flag_variable}' for {pop.abbreviation} not found in ADSL",
                    suggested_fix=f"Create {pop.adam_flag_variable} in ADSL derivation program",
                ))
        return issues

    def _check_figure_titles(self, schema: ClinicalIntelligenceSchema) -> List[QCIssue]:
        """Cross-validate output titles against figure metadata."""
        issues: List[QCIssue] = []
        if not self._figure_metadata:
            return issues

        figure_titles = {fig.title.lower().strip() for fig in self._figure_metadata}

        for output in schema.outputs_master:
            if output.output_type.value != "Figure":
                continue
            title = (output.title or "").lower().strip()
            # Fuzzy match — check if any figure title contains the output title
            matched = any(title in fig_title or fig_title in title
                          for fig_title in figure_titles)
            if not matched and title:
                issues.append(QCIssue(
                    severity=QCSeverity.INFO,
                    category="DataQCBridge",
                    output_id=output.output_id,
                    message=f"Figure '{output.output_number}' title not matched in figure metadata",
                    detail=f"SAP title: '{output.title}'",
                    suggested_fix="Verify figure title matches across SAP and output shell",
                ))
        return issues

    def _check_dataset_coverage(self, schema: ClinicalIntelligenceSchema) -> List[QCIssue]:
        """Check all ADaM datasets referenced in outputs are profiled."""
        issues: List[QCIssue] = []
        if not self._dataset_profiles:
            return issues

        profiled_names = {p.dataset_name for p in self._dataset_profiles}
        all_referenced: set = set()
        for output in schema.outputs_master:
            if output.data_specification:
                all_referenced.update(output.data_specification.input_datasets)

        uncovered = all_referenced - profiled_names
        if uncovered:
            issues.append(QCIssue(
                severity=QCSeverity.INFO,
                category="DataQCBridge",
                message=f"Datasets referenced in SAP but not profiled: {', '.join(sorted(uncovered))}",
                suggested_fix="Provide these datasets in the dataset directory for full cross-validation",
            ))
        return issues
