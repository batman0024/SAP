"""
Pipeline orchestration service - v3.
Adds: parallel entity extraction, progress callbacks, appendix handling,
      TOC/cross-ref awareness, study schema diagram detection.
"""
from __future__ import annotations

import time
import hashlib
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Callable, List, Optional

from src.models.schema import ClinicalIntelligenceSchema, DocumentMetadata
from src.parsers import parse_document, ParsedDocument
from src.entity_extraction import (
    StudyMetadataExtractor, PopulationExtractor,
    EndpointExtractor, VisitScheduleExtractor, OutputExtractor,
)
from src.entity_extraction.pkpd_timing import (
    PKPDExtractor, StudyTimingExtractor, TimingRuleGenerator,
)
from src.rule_engine import RuleEngine
from src.mock_shell import MockShellParser
from src.qc_engine import QCEngine
from src.export import ExportManager
from src.utils import get_logger

logger = get_logger(__name__)


class PipelineConfig:
    def __init__(
        self,
        confidence_threshold: float = 0.70,
        run_qc: bool = True,
        run_mock_shell: bool = True,
        export_json: bool = False,
        export_excel: bool = False,
        export_sas: bool = False,
        output_dir: Optional[Path] = None,
        parallel_extraction: bool = True,    # NEW: run extractors in parallel
        progress_callback: Optional[Callable[[str, float], None]] = None,  # NEW
    ) -> None:
        self.confidence_threshold = confidence_threshold
        self.run_qc = run_qc
        self.run_mock_shell = run_mock_shell
        self.export_json = export_json
        self.export_excel = export_excel
        self.export_sas = export_sas
        self.output_dir = output_dir or Path("./exports")
        self.parallel_extraction = parallel_extraction
        self.progress_callback = progress_callback or (lambda msg, pct: None)


class ExtractionPipeline:
    """Full end-to-end extraction pipeline with parallel entity extraction."""

    def __init__(self, config: Optional[PipelineConfig] = None) -> None:
        self.config = config or PipelineConfig()
        self.rule_engine = RuleEngine(confidence_threshold=self.config.confidence_threshold)
        self.qc_engine = QCEngine(confidence_threshold=self.config.confidence_threshold)
        self.mock_shell_parser = MockShellParser()
        self.export_manager = ExportManager(self.config.output_dir)
        self._cb = self.config.progress_callback

    def run(self, file_paths: List[Path]) -> ClinicalIntelligenceSchema:
        start = time.time()
        logger.info("Pipeline starting — %d input file(s)", len(file_paths))
        self._cb("Initialising pipeline", 0.0)

        schema = ClinicalIntelligenceSchema()

        # ── 1. Parse documents ─────────────────────────────────────────
        self._cb("Parsing documents", 0.05)
        parsed_docs: List[ParsedDocument] = []
        sap_doc: Optional[ParsedDocument] = None

        for path in file_paths:
            if not path.exists():
                logger.warning("File not found: %s", path)
                continue
            try:
                doc = parse_document(path)
                parsed_docs.append(doc)
                schema.documents.append(DocumentMetadata(
                    file_name=path.name,
                    file_type=path.suffix.lstrip(".").lower(),
                    file_size_bytes=path.stat().st_size,
                    role=self._detect_doc_role(path.name),
                ))
                if sap_doc is None and path.suffix.lower() in (".docx", ".rtf", ".txt"):
                    sap_doc = doc
                    logger.info("Primary SAP: %s — %d sections, %d tables, "
                                "%d appendix sections, diagram=%s",
                                doc.file_name, len(doc.sections), len(doc.tables),
                                len(doc.appendix_sections),
                                doc.has_study_schema_diagram)
            except Exception as exc:
                logger.error("Failed to parse %s: %s", path.name, exc)

        if not parsed_docs:
            logger.error("No documents could be parsed")
            return schema

        primary = sap_doc or parsed_docs[0]

        # Hash for audit trail
        try:
            schema.system_metadata.input_source_hash = (
                f"sha256:{self._hash_file(file_paths[0])}"
            )
        except Exception:
            pass

        # Propagate document-level flags to schema metadata
        schema.study_metadata.has_study_schema_diagram = primary.has_study_schema_diagram

        # ── 2. Parallel entity extraction ──────────────────────────────
        self._cb("Extracting entities", 0.15)
        if self.config.parallel_extraction:
            self._extract_parallel(schema, primary)
        else:
            self._extract_sequential(schema, primary)

        # ── 3. Output (TLF) extraction ─────────────────────────────────
        self._cb("Extracting outputs (TLFs)", 0.55)
        schema.outputs_master = OutputExtractor().extract(
            primary, schema.populations, schema.endpoints
        )
        logger.info("  Found %d outputs", len(schema.outputs_master))

        # Attach appendix flag to outputs that live in appendix sections
        app_sec_ids = set(primary.appendix_sections)
        for out in schema.outputs_master:
            if out.section_id in app_sec_ids:
                out.is_appendix_output = True
                # Find appendix label
                sec = primary.get_section_by_id(out.section_id)
                if sec and sec.appendix_label:
                    out.appendix_label = sec.appendix_label

        # ── 4. Mock shells ──────────────────────────────────────────────
        if self.config.run_mock_shell:
            self._cb("Parsing mock shells", 0.65)
            shell_docs = [d for d in parsed_docs if d is not primary and d.tables]
            self._attach_mock_shells(schema, shell_docs[0] if shell_docs else primary)

        # ── 5. Store sections + TOC map ────────────────────────────────
        schema.sections = [
            {"section_id": s.section_id, "title": s.title, "level": s.level,
             "parent_id": s.parent_id, "page_start": s.page_start,
             "is_appendix": s.is_appendix, "appendix_label": s.appendix_label}
            for s in primary.sections
        ]
        schema.toc_map = primary.toc_map
        schema.cross_refs = primary.cross_refs

        # ── 6. QC ──────────────────────────────────────────────────────
        if self.config.run_qc:
            self._cb("Running QC engine", 0.80)
            schema.qc_report = self.qc_engine.run(schema)

        # ── 7. Exports ─────────────────────────────────────────────────
        self._cb("Exporting", 0.90)
        if self.config.export_json:
            self.export_manager.export_json(schema)
        if self.config.export_excel:
            self.export_manager.export_excel(schema)
        if self.config.export_sas:
            self.export_manager.export_sas_metadata(schema)

        elapsed = int((time.time() - start) * 1000)
        schema.system_metadata.execution_time_ms = elapsed
        schema.system_metadata.human_review_status = "pending"
        self._cb("Complete", 1.0)
        logger.info("Pipeline complete in %d ms", elapsed)
        return schema

    # ── Parallel entity extraction ──────────────────────────────────────

    def _extract_parallel(self, schema: ClinicalIntelligenceSchema,
                          primary: ParsedDocument) -> None:
        """Run independent extractors concurrently, then rule engine sequentially."""

        extractors = {
            "study_meta":  lambda: StudyMetadataExtractor().extract(primary),
            "populations": lambda: PopulationExtractor().extract(primary),
            "endpoints":   lambda: EndpointExtractor().extract(primary),
            "visits":      lambda: VisitScheduleExtractor().extract(primary),
            "timing":      lambda: StudyTimingExtractor().extract(primary),
            "pkpd":        lambda: PKPDExtractor().extract(primary),
        }

        results: dict = {}
        with ThreadPoolExecutor(max_workers=4) as pool:
            futs = {pool.submit(fn): name for name, fn in extractors.items()}
            for fut in as_completed(futs):
                name = futs[fut]
                try:
                    results[name] = fut.result()
                    logger.info("  [parallel] %s done", name)
                except Exception as exc:
                    logger.error("  [parallel] %s FAILED: %s", name, exc)
                    results[name] = None

        schema.study_metadata = results.get("study_meta") or schema.study_metadata
        schema.populations = results.get("populations") or []
        schema.endpoints = results.get("endpoints") or []
        schema.visit_schedule = results.get("visits") or []
        schema.timing_definitions = results.get("timing") or []
        schema.pkpd_spec = results.get("pkpd")

        logger.info("  Parallel: %d pops, %d eps, %d visits, %d timing",
                    len(schema.populations), len(schema.endpoints),
                    len(schema.visit_schedule), len(schema.timing_definitions))

        # Rule engine is sequential (deduplication depends on accumulated state)
        logger.info("Running rule engine...")
        schema.rule_engine_output = self.rule_engine.extract_all(primary)
        logger.info("  Found %d rules", len(schema.rule_engine_output))

        # PK/PD metadata propagation
        self._apply_pkpd_meta(schema)

        # Timing rules → outputs (done after outputs are built, see step 3)
        # Stored here and applied in step 3 post-processing
        if schema.timing_definitions:
            schema._pending_timing_rules = TimingRuleGenerator().generate(
                schema.timing_definitions
            )

    def _extract_sequential(self, schema: ClinicalIntelligenceSchema,
                            primary: ParsedDocument) -> None:
        schema.study_metadata = StudyMetadataExtractor().extract(primary)
        schema.populations = PopulationExtractor().extract(primary)
        schema.endpoints = EndpointExtractor().extract(primary)
        schema.visit_schedule = VisitScheduleExtractor().extract(primary)
        schema.timing_definitions = StudyTimingExtractor().extract(primary)
        schema.pkpd_spec = PKPDExtractor().extract(primary)
        schema.rule_engine_output = self.rule_engine.extract_all(primary)
        self._apply_pkpd_meta(schema)

    @staticmethod
    def _apply_pkpd_meta(schema: ClinicalIntelligenceSchema) -> None:
        if not schema.pkpd_spec:
            return
        pk = schema.pkpd_spec
        schema.study_metadata.has_pk_analysis = (
            bool(pk.parameters) or pk.has_nca
        )
        schema.study_metadata.has_pd_analysis = pk.has_pd_endpoints
        schema.study_metadata.has_pkpd_analysis = (
            pk.has_exposure_response or (pk.has_nca and pk.has_pd_endpoints)
        )

    def _attach_mock_shells(self, schema: ClinicalIntelligenceSchema,
                            shell_doc: ParsedDocument) -> None:
        table_idx = 0
        for out in schema.outputs_master:
            if out.mock_shell is not None:
                continue
            if table_idx < len(shell_doc.tables):
                shell = self.mock_shell_parser.parse_for_output(
                    shell_doc.tables[table_idx], f"{out.output_id}_shell"
                )
                if shell:
                    out.mock_shell = shell
                table_idx += 1

    @staticmethod
    def _detect_doc_role(filename: str) -> str:
        lower = filename.lower()
        if "shell" in lower:
            return "Shell"
        if "adam" in lower or "adm" in lower:
            return "ADaM_Template"
        if "sdtm" in lower:
            return "SDTM"
        return "SAP"

    @staticmethod
    def _hash_file(path: Path) -> str:
        h = hashlib.sha256()
        with path.open("rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        return h.hexdigest()
