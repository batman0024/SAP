"""
Rule Engine: extracts structured rules from parsed SAP text.
Covers: date imputation, baseline, visit windows, missing data,
censoring, analysis flags, derivations, filters.
"""
from __future__ import annotations

import re
import uuid
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

from src.models.schema import ExtractedRule, RuleType, StudyDayConvention
from src.parsers import ParsedDocument, ParsedSection
from src.utils import (
    DATE_IMPUTATION_PATTERNS, CENSORING_PATTERNS,
    PK_PARAMETER_PATTERNS, PK_TIME_REFERENCE_PATTERNS, STUDY_DAY_PATTERNS,
    clean_text, get_logger, truncate, compute_confidence
)

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# Rule pattern definitions
# ---------------------------------------------------------------------------

@dataclass
class RulePattern:
    pattern: str
    rule_type: RuleType
    description_template: str
    confidence_base: float = 0.80
    adam_variables: List[str] = field(default_factory=list)
    datasets: List[str] = field(default_factory=list)
    pseudocode_template: Optional[str] = None


RULE_PATTERNS: List[RulePattern] = [
    # --- Baseline definitions ---
    RulePattern(
        pattern=r"baseline.{0,40}last\s+non.missing\s+(?:value|assessment|observation)\s+prior\s+to",
        rule_type=RuleType.BASELINE_DEFINITION,
        description_template="Baseline: last non-missing value prior to first dose",
        adam_variables=["BASE", "ABLFL", "BASETYPE"],
        datasets=["ADLB", "ADVS", "ADRS"],
        pseudocode_template="if ABLFL = 'Y' then BASE = AVAL; /* last non-missing pre-dose */",
        confidence_base=0.95,
    ),
    RulePattern(
        pattern=r"baseline\s+(?:is\s+)?(?:the\s+)?(?:average|mean)\s+of\s+screening\s+and\s+day\s*1",
        rule_type=RuleType.BASELINE_DEFINITION,
        description_template="Baseline: average of screening and Day 1 pre-dose values",
        adam_variables=["BASE", "ABLFL"],
        datasets=["ADLB", "ADVS"],
        pseudocode_template="BASE = mean(screening_val, day1_predose_val);",
        confidence_base=0.88,
    ),
    RulePattern(
        pattern=r"last\s+(?:non.missing\s+)?(?:value|observation)\s+(?:taken\s+)?(?:within|up\s+to)\s+(\d+)\s+days?\s+(?:before|prior\s+to)\s+first\s+dose",
        rule_type=RuleType.BASELINE_DEFINITION,
        description_template="Baseline: last value within N days before first dose",
        adam_variables=["BASE", "ABLFL"],
        datasets=["ADLB"],
        pseudocode_template="if (TRTSDT - ADT) <= N and ABLFL = 'Y' then BASE = AVAL;",
        confidence_base=0.87,
    ),

    # --- Visit window rules ---
    RulePattern(
        pattern=r"(?:visit\s+)?window\s+(?:for|of)\s+(?:week|day)\s+(\d+)\s+(?:is|:)\s+(?:day|week)\s+(\d+)\s+to\s+(?:day|week)\s+(\d+)",
        rule_type=RuleType.VISIT_WINDOW,
        description_template="Visit window: Week N = Day X to Day Y",
        adam_variables=["AVISIT", "AVISITN", "ADT"],
        datasets=["ADLB", "ADRS"],
        pseudocode_template="if AVISITN = N and (TRTSDT + X) <= ADT <= (TRTSDT + Y) then AVISIT = 'WEEK N';",
        confidence_base=0.90,
    ),
    RulePattern(
        pattern=r"multiple\s+(?:records|assessments|observations)\s+(?:within|in)\s+(?:the\s+)?(?:same\s+)?(?:visit\s+)?window.{0,80}(?:closest|nearest)\s+to\s+(?:the\s+)?nominal",
        rule_type=RuleType.VISIT_WINDOW,
        description_template="Multiple records in window: use closest to nominal date",
        adam_variables=["ADT", "AVISITN", "DTYPE"],
        datasets=["ADLB", "ADRS"],
        pseudocode_template="/* Select record with min(abs(ADT - nominal_date)); if tie, use later date */",
        confidence_base=0.85,
    ),
    RulePattern(
        pattern=r"unscheduled\s+(?:visit|assessment).{0,100}(?:not\s+(?:used|included)\s+in|excluded\s+from)\s+(?:primary|main)\s+anal",
        rule_type=RuleType.VISIT_WINDOW,
        description_template="Unscheduled visits excluded from primary analysis",
        adam_variables=["DTYPE", "AVISITN"],
        datasets=["ADRS", "ADTTE"],
        pseudocode_template="if DTYPE = 'UNSCHEDULED' then ANL01FL = '';",
        confidence_base=0.88,
    ),

    # --- Analysis flags ---
    RulePattern(
        pattern=r"ANL01FL\s*=\s*['\"]?Y['\"]?|primary\s+analysis\s+flag",
        rule_type=RuleType.FLAG,
        description_template="ANL01FL: primary analysis flag",
        adam_variables=["ANL01FL"],
        datasets=["ADLB", "ADRS"],
        pseudocode_template="if ITTFL = 'Y' and AVISITN in (primary_visits) and DTYPE = '' then ANL01FL = 'Y';",
        confidence_base=0.95,
    ),
    RulePattern(
        pattern=r"ABLFL\s*=\s*['\"]?Y['\"]?|baseline\s+record\s+flag",
        rule_type=RuleType.FLAG,
        description_template="ABLFL: baseline record flag",
        adam_variables=["ABLFL"],
        datasets=["ADLB", "ADVS", "ADRS"],
        pseudocode_template="if ADT <= TRTSDT and AVAL ne . then ABLFL = 'Y'; /* last pre-dose record */",
        confidence_base=0.93,
    ),

    # --- Filter rules ---
    RulePattern(
        pattern=r"(?:ITT|FAS|safety|per.protocol|intent.to.treat)\s+population.{0,60}([A-Z]{3,8}FL)\s*=\s*['\"]?Y['\"]?",
        rule_type=RuleType.FILTER,
        description_template="Population filter: FLAG = 'Y'",
        adam_variables=["ITTFL", "SAFFL", "PPROTFL"],
        datasets=["ADSL", "ADEFF"],
        pseudocode_template="where FLAGFL = 'Y';",
        confidence_base=0.95,
    ),
    RulePattern(
        pattern=r"exclude\s+(?:patients|subjects|participants).{0,80}(?:who|that)\s+(?:did\s+not\s+receive|received\s+no)\s+(?:study\s+)?(?:drug|treatment|medication)",
        rule_type=RuleType.FILTER,
        description_template="Exclude subjects who received no study drug",
        adam_variables=["SAFFL", "TRTSDT"],
        datasets=["ADSL"],
        pseudocode_template="where TRTSDT ne .;  /* must have treatment start date */",
        confidence_base=0.87,
    ),

    # --- Derivation rules ---
    RulePattern(
        pattern=r"change\s+from\s+baseline\s+(?:is\s+)?(?:calculated\s+(?:as|by)|defined\s+as)\s+(?:AVAL|value|score)\s*[-\u2013]\s*(?:BASE|baseline)",
        rule_type=RuleType.DERIVATION,
        description_template="CHG = AVAL - BASE (change from baseline)",
        adam_variables=["CHG", "AVAL", "BASE"],
        datasets=["ADLB", "ADVS", "ADRS"],
        pseudocode_template="CHG = AVAL - BASE;",
        confidence_base=0.97,
    ),
    RulePattern(
        pattern=r"percent\s+change\s+from\s+baseline.{0,50}(?:PCHG|100\s*[*x]\s*CHG\s*/\s*BASE|100\s*[*x]\s*\(AVAL\s*-\s*BASE\)\s*/\s*BASE)",
        rule_type=RuleType.DERIVATION,
        description_template="PCHG = 100 * (AVAL - BASE) / BASE (percent change)",
        adam_variables=["PCHG", "CHG", "AVAL", "BASE"],
        datasets=["ADLB", "ADRS"],
        pseudocode_template="PCHG = 100 * (AVAL - BASE) / BASE;  /* if BASE ne 0 */",
        confidence_base=0.93,
    ),

    # --- LOCF / BOCF ---
    RulePattern(
        pattern=r"(?:LOCF|last\s+observation\s+carried\s+forward)",
        rule_type=RuleType.LOCF,
        description_template="LOCF: last observation carried forward imputation",
        adam_variables=["DTYPE", "AVAL"],
        datasets=["ADRS", "ADTTE"],
        pseudocode_template="if DTYPE = 'LOCF' then AVAL = (last observed AVAL);",
        confidence_base=0.92,
    ),
    RulePattern(
        pattern=r"(?:BOCF|baseline\s+observation\s+carried\s+forward)",
        rule_type=RuleType.BOCF,
        description_template="BOCF: baseline observation carried forward imputation",
        adam_variables=["DTYPE", "AVAL", "BASE"],
        datasets=["ADRS", "ADTTE"],
        pseudocode_template="if DTYPE = 'BOCF' then AVAL = BASE;",
        confidence_base=0.92,
    ),
    RulePattern(
        pattern=r"multiple\s+imputation.{0,80}(?:\d+|1000|500)\s+imputation",
        rule_type=RuleType.IMPUTATION,
        description_template="Multiple imputation (MI) sensitivity analysis",
        adam_variables=["DTYPE", "AVAL"],
        datasets=["ADRS", "ADTTE"],
        pseudocode_template="/* proc mi / proc mianalyze; N imputations under MAR */",
        confidence_base=0.88,
    ),

    # --- Composite endpoint ---
    RulePattern(
        pattern=r"composite\s+(?:endpoint|outcome).{0,120}(?:whichever|first\s+(?:of|occurring))",
        rule_type=RuleType.COMPOSITE,
        description_template="Composite endpoint: first of multiple events",
        adam_variables=["AVAL", "CNSR", "EVNTDESC"],
        datasets=["ADTTE"],
        pseudocode_template="/* min(event1_date, event2_date, ...) — first event wins */",
        confidence_base=0.85,
    ),
]


# Date imputation rule patterns (from utils, structured separately)
DATE_RULE_PATTERNS: List[Tuple[str, str, List[str]]] = [
    (
        r"partial\s+(?:start\s+)?date.{0,60}(?:day|DD)\s+(?:imputed?\s+(?:as|to)\s+)?01",
        "Partial date (YYYY-MM): impute day as 01",
        ["ASTDT", "ASTDTF"],
    ),
    (
        r"partial\s+(?:end\s+)?date.{0,60}last\s+day\s+of\s+(?:the\s+)?month",
        "Partial end date (YYYY-MM): impute day as last day of month",
        ["AENDT", "AENDTF"],
    ),
    (
        r"(?:year\s+only|YYYY\s+only).{0,60}(?:January\s+1st?|01.01|first\s+day\s+of\s+(?:the\s+)?year)",
        "Year-only date: impute month and day as 01-01",
        ["ASTDT", "AENDT", "ASTDTF", "AENDTF"],
    ),
    (
        r"missing\s+(?:AE\s+)?(?:start\s+)?date.{0,80}(?:study\s+start|first\s+dose)",
        "Missing AE start date: use study start / first dose date",
        ["ASTDT", "ASTDTF"],
    ),
    (
        r"(ASTDTF|AENDTF|ADTF)\s*=\s*['\"]([MDHY]+)['\"]",
        "Date imputation flag set (D=day, M=month, H=hour)",
        ["ASTDTF", "AENDTF", "ADTF"],
    ),
]

CENSORING_RULE_PATTERNS: List[Tuple[str, str, List[str]]] = [
    (
        r"(?:withdrew|withdrawal|withdraw).{0,40}consent.{0,80}CNSR\s*=\s*1",
        "Withdrawal of consent: CNSR=1, ADT=last known alive date",
        ["CNSR", "ADT", "EVNTDESC"],
    ),
    (
        r"lost\s+to\s+follow.?up.{0,80}CNSR\s*=\s*1",
        "Lost to follow-up: CNSR=1, ADT=last contact date",
        ["CNSR", "ADT"],
    ),
    (
        r"administrative(?:ly)?\s+censor.{0,80}(?:data\s+cut|cutoff)",
        "Administrative censoring at data cutoff: CNSR=1, ADT=cutoff date",
        ["CNSR", "ADT"],
    ),
    (
        r"event\s+(?:observed|occurred).{0,40}CNSR\s*=\s*0",
        "Event observed: CNSR=0, ADT=event date",
        ["CNSR", "ADT", "EVNTDESC"],
    ),
    (
        r"competing\s+event.{0,100}CNSR\s*=\s*1",
        "Competing event censoring: CNSR=1, flag in EVNTDESC",
        ["CNSR", "ADT", "EVNTDESC", "SRCDOM"],
    ),
]


# ---------------------------------------------------------------------------
# Rule extractor
# ---------------------------------------------------------------------------

class RuleEngine:
    """Extract structured rules from parsed document sections."""

    def __init__(self, confidence_threshold: float = 0.60) -> None:
        self.confidence_threshold = confidence_threshold

    def extract_all(self, document: ParsedDocument) -> List[ExtractedRule]:
        """Run full rule extraction across all sections."""
        logger.info("Running rule engine on %d sections", len(document.sections))
        rules: List[ExtractedRule] = []

        for section in document.sections:
            text = section.get_text()
            if not text.strip():
                continue
            rules.extend(self._extract_from_text(text, section.section_id, section.page_start))

        # Deduplicate by normalized description
        import hashlib
        seen_descs: set = set()
        unique_rules: List[ExtractedRule] = []
        for r in rules:
            # Use full-text hash to avoid false deduplication on shared prefixes
            key = hashlib.md5(r.rule_text_verbatim.lower().encode()).hexdigest()
            if key not in seen_descs:
                seen_descs.add(key)
                unique_rules.append(r)

        logger.info("Rule engine extracted %d unique rules", len(unique_rules))
        return unique_rules

    def _extract_from_text(
        self,
        text: str,
        section_id: str,
        page_start: int
    ) -> List[ExtractedRule]:
        rules: List[ExtractedRule] = []

        # General rule patterns
        for rp in RULE_PATTERNS:
            matches = list(re.finditer(rp.pattern, text, re.IGNORECASE | re.DOTALL))
            for match in matches:
                snippet = truncate(match.group(0), 200)
                confidence = self._adjust_confidence(rp.confidence_base, match)
                if confidence < self.confidence_threshold:
                    continue
                rules.append(ExtractedRule(
                    rule_id=f"rule_{uuid.uuid4().hex[:8]}",
                    rule_type=rp.rule_type,
                    rule_text_verbatim=snippet,
                    rule_logic_structured={
                        "description": rp.description_template,
                        "variables": rp.adam_variables,
                    },
                    pseudocode=rp.pseudocode_template,
                    applies_to_datasets=rp.datasets,
                    applies_to_variables=rp.adam_variables,
                    confidence=confidence,
                    source_section=section_id,
                    source_page=page_start,
                ))

        # Date imputation patterns
        for pattern, description, variables in DATE_RULE_PATTERNS:
            matches = list(re.finditer(pattern, text, re.IGNORECASE | re.DOTALL))
            for match in matches:
                snippet = truncate(match.group(0), 200)
                rules.append(ExtractedRule(
                    rule_id=f"rule_{uuid.uuid4().hex[:8]}",
                    rule_type=RuleType.DATE_IMPUTATION,
                    rule_text_verbatim=snippet,
                    rule_logic_structured={"description": description},
                    applies_to_variables=variables,
                    applies_to_datasets=["ADAE", "ADEFF", "ADLB"],
                    confidence=0.88,
                    source_section=section_id,
                    source_page=page_start,
                ))

        # Censoring patterns
        for pattern, description, variables in CENSORING_RULE_PATTERNS:
            matches = list(re.finditer(pattern, text, re.IGNORECASE | re.DOTALL))
            for match in matches:
                snippet = truncate(match.group(0), 200)
                rules.append(ExtractedRule(
                    rule_id=f"rule_{uuid.uuid4().hex[:8]}",
                    rule_type=RuleType.CENSORING,
                    rule_text_verbatim=snippet,
                    rule_logic_structured={"description": description},
                    applies_to_variables=variables,
                    applies_to_datasets=["ADTTE"],
                    confidence=0.87,
                    source_section=section_id,
                    source_page=page_start,
                ))

        return rules

    @staticmethod
    def _adjust_confidence(base: float, match: re.Match) -> float:
        """Boost confidence if match is longer / more specific."""
        length_bonus = min(0.05, len(match.group(0)) / 1000)
        return min(1.0, base + length_bonus)
