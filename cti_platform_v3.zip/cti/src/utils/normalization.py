"""
Normalization maps for clinical trial domain concepts.

Design philosophy:
  - Every map is a plain dict/list constant — easy to extend in user config.
  - No business logic here; just lookup tables.
  - All regex patterns use raw strings and are pre-compiled at module load.

USER EXTENSION:
  Override or extend any map before pipeline runs by importing and mutating:
      from src.utils.normalization import POPULATION_NORMALIZATION
      POPULATION_NORMALIZATION[r"\\bCustomPop\\b"] = ("Custom Population", "CUST", 7)
"""
from __future__ import annotations

import re
from typing import Dict, List, Tuple


# ---------------------------------------------------------------------------
# Population normalization
# pattern -> (canonical_label, abbreviation, hierarchy_order)
# Lower order = higher priority (ITT/FAS = 1)
# ---------------------------------------------------------------------------

POPULATION_NORMALIZATION: Dict[str, Tuple[str, str, int]] = {
    r"\bintent.to.treat\b|\bITT\b":                ("Intent-to-Treat",        "ITT",  1),
    r"\bfull.analysis.set\b|\bFAS\b":              ("Full Analysis Set",       "FAS",  1),
    r"\bmodified.intent.to.treat\b|\bmITT\b":      ("Modified Intent-to-Treat","mITT", 2),
    r"\bper.protocol\b|\bPP\b.{0,20}(?:population|set|analysis)": ("Per Protocol", "PP", 3),
    r"\bsafety\b.{0,20}\bpopulation\b|\bSAF\b":   ("Safety",                 "SAF",  2),
    r"\bpharmacokinetic\b|\bPK\b.{0,20}(?:population|set)": ("Pharmacokinetic","PK",   4),
    r"\bpd\b.{0,20}(?:population|set)|pharmacodynamic.{0,20}(?:population|set)": ("Pharmacodynamic", "PD", 4),
    r"\bevaluable\b":                              ("Evaluable",              "EVAL", 5),
    r"\brandomized\b.{0,20}\bpopulation\b|\bRAND\b.{0,20}(?:population|set)": ("Randomized", "RAND", 1),
    r"\bbiomarker.evaluable\b|\bBME\b.{0,20}(?:population|set)": ("Biomarker Evaluable","BME", 6),
}

# ADaM flag variable by population abbreviation
POPULATION_FLAG_MAP: Dict[str, str] = {
    "ITT":  "ITTFL",
    "FAS":  "FASFL",
    "mITT": "MITTFL",
    "PP":   "PPROTFL",   # NOTE: sponsor-specific — verify against study ADaM spec
    "SAF":  "SAFFL",
    "PK":   "PKFL",
    "PD":   "PDFL",
    "EVAL": "EVALFL",
    "RAND": "RANDFL",
    "BME":  "BMEFL",
}

# Primary ADSL source for each population flag
POPULATION_DATASET_MAP: Dict[str, str] = {
    "ITT":  "ADSL",
    "FAS":  "ADSL",
    "mITT": "ADSL",
    "PP":   "ADSL",
    "SAF":  "ADSL",
    "PK":   "ADSL",
    "PD":   "ADSL",
    "EVAL": "ADSL",
    "RAND": "ADSL",
    "BME":  "ADSL",
}


# ---------------------------------------------------------------------------
# Analysis method normalization
# pattern -> canonical method name
# ---------------------------------------------------------------------------

METHOD_NORMALIZATION: Dict[str, str] = {
    r"\bANCOVA\b":                              "ANCOVA",
    r"\banalysis\s+of\s+covariance\b":          "ANCOVA",
    r"\bMMRM\b|\bmixed.model.repeat":           "MMRM",
    r"\bmixed\s+effects\s+model":               "MMRM",
    r"\blogistic\s+regression\b":               "Logistic Regression",
    r"\bCox\s+(proportional\s+hazards|regression)\b": "Cox Proportional Hazards",
    r"\bKaplan.Meier\b|\bKM\b":                "Kaplan-Meier",
    r"\bWilcoxon\b":                            "Wilcoxon Rank-Sum",
    r"\bCochran.Mantel.Haenszel\b|\bCMH\b":    "CMH Test",
    r"\bFisher.s exact\b":                      "Fisher's Exact Test",
    r"\bchi.square\b|\bchi2\b":                 "Chi-Square Test",
    r"\bt.test\b|\bstudent.s t\b":              "t-Test",
    r"\bANOVA\b":                               "ANOVA",
    r"\bmultiple\s+imputation\b":               "Multiple Imputation",
    r"\bLOCF\b|\blast\s+observation\s+carried\s+forward": "LOCF",
    r"\bBOCF\b|\bbaseline\s+observation\s+carried\s+forward": "BOCF",
    r"\bNCA\b|\bnon.compartmental\s+analysis\b": "Non-Compartmental Analysis (NCA)",
    r"\bpopulation\s+PK\b|\bPopPK\b|\bNONMEM\b": "Population PK Modeling",
    r"\bNLME\b|\bnonlinear\s+mixed\s+effects\b": "Nonlinear Mixed Effects Model",
    r"\bE/R\b|\bexposure.response\b":           "Exposure-Response Analysis",
}


# ---------------------------------------------------------------------------
# ADaM dataset inference hints
# Maps dataset name -> list of text signals that suggest it
# ADEFF removed — replaced with study-specific efficacy datasets
# ---------------------------------------------------------------------------

ADAM_DATASET_HINTS: Dict[str, List[str]] = {
    "ADSL":  ["demographics", "disposition", "baseline characteristics", "subject level",
               "enrolled", "randomized subjects"],
    "ADAE":  ["adverse event", " AE ", "safety", "toxicity", "TEAE", "serious adverse",
               "CTCAE", "MedDRA"],
    "ADLB":  ["laboratory", " lab ", "hematology", "chemistry", "urinalysis", "clinical laboratory"],
    "ADVS":  ["vital signs", "blood pressure", "heart rate", "weight", "BMI", "pulse",
               "respiratory rate", "temperature"],
    "ADRS":  ["response", "responder", "complete response", "partial response", "stable disease",
               "RECIST", "response rate", "ORR", "DCR"],
    "ADTTE": ["time to event", "time-to-event", "survival", "progression", "relapse",
               "death", "OS", "PFS", "EFS", "DFS", "censored", "Kaplan-Meier",
               "hazard ratio", "log-rank"],
    "ADPC":  ["PK concentration", "pharmacokinetic concentration", "plasma concentration",
               "serum concentration", "Cmax", "Tmax", "concentration-time",
               "LLOQ", "BLoQ", "below limit of quantification", "ADPC"],
    "ADPP":  ["PK parameter", "pharmacokinetic parameter", "AUC", "AUCinf", "AUClast",
               "half-life", "t1/2", "clearance", "volume of distribution", "Vd",
               "NCA", "non-compartmental", "ADPP"],
    "ADPK":  ["population PK", "PopPK", "NONMEM", "exposure-response", "E/R"],
    "ADQS":  ["questionnaire", "PRO", "patient reported", "quality of life", "QoL",
               "score", "FACIT", "EQ-5D", "SF-36", "PGIC", "CGIC", "patient global"],
    "ADCM":  ["concomitant medication", "prior medication", "rescue medication",
               "prohibited medication", "conmed"],
    "ADEX":  ["exposure", "dose", "treatment duration", "compliance", "dose intensity",
               "relative dose intensity", "RDI"],
    "ADBDS": ["biomarker", "genomic", "proteomic", "biomarker-evaluable", "ctDNA",
               "tumor mutation burden", "TMB", "PD-L1"],
    "ADDERM": ["dermatology", "skin", "EASI", "SCORAD", "IGA"],
    "ADEG":  ["ECG", "electrocardiogram", "QTc", "QT interval", "PR interval"],
}


# ---------------------------------------------------------------------------
# Output classification hints
# Maps OutputClass value -> text signals
# ---------------------------------------------------------------------------

OUTPUT_CLASS_HINTS: Dict[str, List[str]] = {
    "Efficacy":     ["efficacy", "primary", "secondary", "endpoint", "responder",
                     "score", "change from baseline", "response rate", "OS", "PFS"],
    "Safety":       ["safety", "adverse event", "AE", "TEAE", "SAE", "toxicity",
                     "death", "discontinuation", "tolerability", "CTCAE"],
    "Demographics": ["demographic", "baseline characteristic", "age", "sex", "race",
                     "weight", "height", "BMI", "medical history"],
    "Disposition":  ["disposition", "discontinued", "withdrawal", "completion",
                     "enrolled", "randomized", "screened", "study completion"],
    "PK":           ["pharmacokinetic", " PK ", "concentration", "AUC", "Cmax",
                     "Tmax", "half-life", "clearance", "NCA", "ADPC", "ADPP"],
    "PD":           ["pharmacodynamic", " PD ", "biomarker", "E/R", "exposure-response"],
    "QoL":          ["quality of life", "PRO", "questionnaire", "patient reported",
                     "QoL", "PGIC", "CGIC"],
    "Biomarker":    ["biomarker", "genomic", "proteomic", "biomarker-evaluable",
                     "ctDNA", "TMB"],
    "Subgroup":     ["subgroup", "stratification", "by age", "by sex", "by region",
                     "by race", "forest plot"],
    "Compliance":   ["compliance", "dose intensity", "exposure", "relative dose intensity"],
}


# ---------------------------------------------------------------------------
# Date imputation rule text patterns
# (pattern, human-readable description)
# ---------------------------------------------------------------------------

DATE_IMPUTATION_PATTERNS: List[Tuple[str, str]] = [
    (r"partial.{0,20}start.{0,20}date.{0,40}day.{0,20}01",
     "Partial start date (YYYY-MM): impute day as 01"),
    (r"partial.{0,20}end.{0,20}date.{0,40}last\s+day",
     "Partial end date (YYYY-MM): impute day as last day of month"),
    (r"missing.{0,20}date.{0,40}last\s+known",
     "Missing date: use last known date"),
    (r"impute.{0,20}(YYYY.MM|year\s+month).{0,30}(01|first)",
     "Year-month partial: impute day as 01"),
    (r"date\s+flag.{0,20}(ASTDTF|AENDTF|ADTF)",
     "Date imputation flag variable present"),
    (r"(ASTDTF|AENDTF|ADTF)\s*=\s*['\"]([MDHY]+)['\"]",
     "Date imputation flag explicitly set (D=day, M=month, H=hour, Y=year)"),
    (r"year.only.{0,40}(january\s+1|01.01|jan)",
     "Year-only date: impute month and day as 01-01"),
]


# ---------------------------------------------------------------------------
# Censoring rule text patterns
# (pattern, human-readable description)
# ---------------------------------------------------------------------------

CENSORING_PATTERNS: List[Tuple[str, str]] = [
    (r"(withdrew|withdrawal).{0,40}consent",
     "Withdrew consent: CNSR=1, ADT=last known alive date"),
    (r"lost.{0,20}follow.?up",
     "Lost to follow-up: CNSR=1, ADT=last contact date"),
    (r"administrative.{0,20}censor",
     "Administrative censoring at data cutoff: CNSR=1, ADT=cutoff date"),
    (r"competing.{0,20}event",
     "Competing event censoring: CNSR=1, flag in EVNTDESC"),
    (r"CNSR\s*=\s*0",
     "Event observed: CNSR=0, ADT=event date"),
    (r"CNSR\s*=\s*1",
     "Censored observation: CNSR=1"),
]


# ---------------------------------------------------------------------------
# PK-specific patterns for semantic extraction
# ---------------------------------------------------------------------------

PK_PARAMETER_PATTERNS: List[Tuple[str, str, str]] = [
    # (pattern, paramcd, param_description)
    (r"\bCmax\b",                               "CMAX",     "Maximum Observed Concentration (ng/mL)"),
    (r"\bTmax\b|\bTmax\b",                      "TMAX",     "Time to Maximum Concentration (h)"),
    (r"\bAUCinf\b|\bAUC0.inf\b|\bAUC_inf\b",   "AUCIFO",   "AUC from 0 to Infinity (ng*h/mL)"),
    (r"\bAUClast\b|\bAUC0.t\b|\bAUC_last\b",   "AUCLST",   "AUC from 0 to Last Measurable Timepoint (ng*h/mL)"),
    (r"\bAUCtau\b|\bAUC0.tau\b",                "AUCTAU",   "AUC over Dosing Interval (ng*h/mL)"),
    (r"\bt1/2\b|\bthalf\b|\belimination\s+half.life\b", "THALF", "Terminal Half-Life (h)"),
    (r"\bCL/?F\b|\boral\s+clearance\b",         "CLF",      "Apparent Oral Clearance (L/h)"),
    (r"\bVd/?F\b|\bVz/?F\b",                    "VZF",      "Apparent Volume of Distribution (L)"),
    (r"\bCmin\b|\btrough\s+concentration\b",    "CMIN",     "Minimum Observed Concentration (ng/mL)"),
    (r"\bCavg\b|\baverage\s+concentration\b",   "CAVG",     "Average Concentration (ng/mL)"),
    (r"\bMRT\b|\bmean\s+residence\s+time\b",    "MRT",      "Mean Residence Time (h)"),
    (r"\bRac\b|\baccumulation\s+ratio\b",       "RAC",      "Accumulation Ratio"),
    (r"\bF\b.{0,20}bioavailability|\bbioavailability\b", "F", "Bioavailability (%)"),
]

# BLoQ (Below Limit of Quantification) handling patterns
BLOQ_HANDLING_PATTERNS: List[Tuple[str, str]] = [
    (r"BLoQ.{0,60}(?:set\s+to|imputed?\s+(?:as|to))\s+0",
     "BLoQ set to 0 for PK analysis and descriptive statistics"),
    (r"BLoQ.{0,60}(?:set\s+to|imputed?\s+(?:as|to))\s+LLOQ\s*/\s*2",
     "BLoQ set to LLOQ/2 for analysis (M3 method)"),
    (r"BLoQ.{0,60}excluded",
     "BLoQ values excluded from PK analysis"),
    (r"LLOQ.{0,30}([\d.]+)\s*(ng[/\\]mL|µg[/\\]mL|mg[/\\]L)",
     "LLOQ value specified for the assay"),
]

# PK sampling time reference patterns
PK_TIME_REFERENCE_PATTERNS: List[Tuple[str, str]] = [
    (r"relative\s+to\s+(?:first\s+dose|dose\s+1|initial\s+dose)",
     "Time reference: first dose (ARELTM relative to first dose)"),
    (r"relative\s+to\s+(?:most\s+recent|last|preceding)\s+dose",
     "Time reference: most recent dose (ARELTM relative to preceding dose)"),
    (r"(?:nominal|planned)\s+(?:time|timepoint)",
     "Nominal time used for planned timepoint (ATPT/ATPTN)"),
    (r"predose.{0,40}(?:set\s+to\s+zero|ATPTN\s*=\s*0|time\s*=\s*0)",
     "Predose ATPTN set to 0 (standard ADPC convention)"),
]


# ---------------------------------------------------------------------------
# Study day / timing definition patterns
# ---------------------------------------------------------------------------

STUDY_DAY_PATTERNS: List[Tuple[str, str, str]] = [
    # (pattern, category, description)
    (r"study\s+day\s+1\s+(?:is|=|corresponds\s+to)\s+(?:the\s+)?(?:date\s+of\s+)?(?:first\s+dose|randomization|day\s+of\s+first\s+treatment)",
     "study_day_anchor",
     "Study Day 1 = first dose/randomization date (no Day 0)"),
    (r"study\s+day\s+0\s+(?:is|=|corresponds\s+to)\s+(?:the\s+)?(?:date\s+of\s+)?(?:first\s+dose|randomization)",
     "study_day_anchor",
     "Study Day 0 = first dose/randomization date (Day 0 convention)"),
    (r"ADY\s*=\s*ADT\s*-\s*TRTSDT\s*\+\s*(?:1|one)",
     "ady_formula",
     "Study day formula: ADY = ADT - TRTSDT + 1 (post-dose, no Day 0)"),
    (r"ADY\s*=\s*ADT\s*-\s*TRTSDT",
     "ady_formula",
     "Study day formula: ADY = ADT - TRTSDT (allows Day 0)"),
    (r"(?:follow.?up|post.treatment)\s+(?:period|phase).{0,80}(\d+)\s+(?:days?|weeks?)\s+(?:after\s+)?(?:last\s+dose|EOT|end\s+of\s+treatment)",
     "followup_definition",
     "Follow-up period defined as N days/weeks after last dose"),
    (r"(?:washout|post.dose).{0,60}(\d+)\s+(?:days?|weeks?|half.lives?)\s+after\s+(?:last\s+dose|EOT|end\s+of\s+treatment)",
     "washout_definition",
     "Washout/post-dose period: N days/weeks/half-lives after last dose"),
    (r"(?:safety\s+)?follow.?up.{0,60}(\d+)\s+days?\s+(?:\(|after\s+)(?:last\s+dose|last\s+administration|EOT)",
     "safety_followup",
     "Safety follow-up: N days after last dose"),
    (r"(?:TEAE|treatment.emergent).{0,80}(?:from|starting)\s+(?:first\s+dose|Day\s+1).{0,80}(?:up\s+to|through|until)\s+(\d+)\s+days?\s+after\s+(?:last\s+dose|EOT)",
     "teae_window",
     "TEAE window: from first dose to N days after last dose"),
    (r"on.treatment\s+period.{0,80}(?:from|Day\s+1).{0,100}(?:last\s+dose|EOT|end\s+of\s+treatment)",
     "on_treatment_period",
     "On-treatment period definition (spans first to last dose)"),
    (r"off.treatment.{0,80}(?:after|following)\s+(?:last\s+dose|EOT|discontinuation)",
     "off_treatment_period",
     "Off-treatment period definition"),
    # Specific day-after-last-dose patterns
    (r"(\d+)\s+days?\s+after\s+(?:the\s+)?last\s+(?:dose|administration)\s+of\s+study\s+(?:drug|treatment|medication)",
     "days_after_last_dose",
     "Specific number of days after last dose of study drug"),
    (r"within\s+(\d+)\s+days?\s+(?:of|following)\s+(?:the\s+)?last\s+(?:dose|administration)",
     "days_after_last_dose",
     "Within N days of last dose"),
]


# ---------------------------------------------------------------------------
# PD / Pharmacodynamic patterns
# ---------------------------------------------------------------------------

PD_PATTERNS: List[Tuple[str, str]] = [
    (r"\bEC50\b|\bIC50\b|\bED50\b",
     "Pharmacodynamic parameter: EC50/IC50/ED50 (half-maximal effect concentration)"),
    (r"\bEmax\b|\bmaximum\s+effect\b",
     "Pharmacodynamic parameter: Emax (maximum drug effect)"),
    (r"\bE/R\b|\bexposure.response\b|\bPK.PD\b|\bPKPD\b",
     "Exposure-response or PK/PD relationship analysis"),
    (r"\bbiomarker.{0,40}(?:endpoint|variable|measure)",
     "Pharmacodynamic biomarker endpoint"),
    (r"\btarget\s+(?:occupancy|engagement|saturation)",
     "Target occupancy/engagement as PD endpoint"),
    (r"\breceptor\s+(?:occupancy|binding)",
     "Receptor occupancy as PD endpoint"),
    (r"\beffect\s+compartment\b|\blink\s+model\b",
     "PK/PD link model (effect compartment)"),
]
