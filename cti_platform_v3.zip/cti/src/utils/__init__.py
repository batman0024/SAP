"""
Utility package — backward-compatible re-export of all public symbols.

Import from here or directly from submodules:
    from src.utils import clean_text, get_logger          # existing code works
    from src.utils.normalization import PK_PARAMETER_PATTERNS  # new code
"""
from src.utils.logging_util import get_logger
from src.utils.text import (
    clean_text,
    compute_confidence,
    extract_number_from_title,
    normalize_output_number,
    slugify,
    truncate,
)
from src.utils.normalization import (
    ADAM_DATASET_HINTS,
    BLOQ_HANDLING_PATTERNS,
    CENSORING_PATTERNS,
    DATE_IMPUTATION_PATTERNS,
    METHOD_NORMALIZATION,
    OUTPUT_CLASS_HINTS,
    PD_PATTERNS,
    PK_PARAMETER_PATTERNS,
    PK_TIME_REFERENCE_PATTERNS,
    POPULATION_DATASET_MAP,
    POPULATION_FLAG_MAP,
    POPULATION_NORMALIZATION,
    STUDY_DAY_PATTERNS,
)
from src.utils.classification import (
    classify_output,
    infer_adam_datasets,
    normalize_method,
    normalize_population,
)

__all__ = [
    "get_logger",
    "clean_text", "compute_confidence", "extract_number_from_title",
    "normalize_output_number", "slugify", "truncate",
    "ADAM_DATASET_HINTS", "BLOQ_HANDLING_PATTERNS", "CENSORING_PATTERNS",
    "DATE_IMPUTATION_PATTERNS", "METHOD_NORMALIZATION", "OUTPUT_CLASS_HINTS",
    "PD_PATTERNS", "PK_PARAMETER_PATTERNS", "PK_TIME_REFERENCE_PATTERNS",
    "POPULATION_DATASET_MAP", "POPULATION_FLAG_MAP", "POPULATION_NORMALIZATION",
    "STUDY_DAY_PATTERNS",
    "classify_output", "infer_adam_datasets", "normalize_method", "normalize_population",
]
