"""
Classification helpers: output class inference, ADaM dataset inference,
method normalization, population normalization.

These functions consume the normalization maps but add no new constants.
"""
from __future__ import annotations

import re
from typing import List, Optional, Tuple

from src.utils.normalization import (
    ADAM_DATASET_HINTS,
    METHOD_NORMALIZATION,
    OUTPUT_CLASS_HINTS,
    POPULATION_NORMALIZATION,
)


def classify_output(title: str, context: str = "") -> str:
    """
    Heuristic output class from title + surrounding context.
    Returns an OutputClass value string.
    Checks longer hint lists first; breaks on first match.
    """
    combined = (title + " " + context).lower()
    for cls, hints in OUTPUT_CLASS_HINTS.items():
        if any(h.lower() in combined for h in hints):
            return cls
    return "Other"


def infer_adam_datasets(title: str, context: str = "") -> List[str]:
    """
    Infer likely ADaM datasets from output title and context text.
    Returns deduplicated list preserving priority order.
    Never returns ADEFF (non-standard).
    """
    combined = (title + " " + context).lower()
    datasets: List[str] = []
    for ds, hints in ADAM_DATASET_HINTS.items():
        if any(h.lower() in combined for h in hints):
            datasets.append(ds)
    if not datasets:
        datasets.append("ADSL")
    return list(dict.fromkeys(datasets))  # deduplicate, preserve order


def normalize_population(text: str) -> Optional[Tuple[str, str, int]]:
    """
    Match free-form population text to (label, abbreviation, hierarchy_order).
    Returns None if no match found.
    """
    for pattern, result in POPULATION_NORMALIZATION.items():
        if re.search(pattern, text, re.IGNORECASE):
            return result
    return None


def normalize_method(text: str) -> Optional[str]:
    """Match analysis method text to canonical name."""
    for pattern, name in METHOD_NORMALIZATION.items():
        if re.search(pattern, text, re.IGNORECASE):
            return name
    return None
