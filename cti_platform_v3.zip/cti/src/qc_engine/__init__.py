"""
QC Engine: automated validation of extracted clinical intelligence.
Checks completeness, consistency, population integrity, endpoint coverage,
mock shell quality, confidence thresholds, and cross-document alignment.
"""
from __future__ import annotations

import re
import uuid
from typing import Dict, List, Optional, Set

from src.models.schema import (
    EndpointClassification,
    AnalysisOutput, ClinicalIntelligenceSchema, Endpoint, Population,
    QCIssue, QCReport, QCSeverity, VisitWindow
)
from src.utils import get_logger

logger = get_logger(__name__)

CONFIDENCE_THRESHOLD = 0.70
MIN_OUTPUTS_EXPECTED = 5


class QCEngine:
    """Run full QC validation on a ClinicalIntelligenceSchema instance."""

    def __init__(
        self,
        confidence_threshold: float = CONFIDENCE_THRESHOLD,
        min_outputs: int = MIN_OUTPUTS_EXPECTED,
    ) -> None:
        self.confidence_threshold = confidence_threshold
        self.min_outputs = min_outputs

    def run(self, schema: ClinicalIntelligenceSchema) -> QCReport:
        logger.info("Running QC engine on schema with %d outputs", len(schema.outputs_master))
        issues: List[QCIssue] = []

        issues.extend(self._check_study_metadata(schema))
        issues.extend(self._check_populations(schema))
        issues.extend(self._check_endpoints(schema))
        issues.extend(self._check_outputs(schema))
        issues.extend(self._check_output_completeness(schema))
        issues.extend(self._check_duplicate_outputs(schema))
        issues.extend(self._check_population_consistency(schema))
        issues.extend(self._check_mock_shells(schema))
        issues.extend(self._check_visit_schedule(schema))
        issues.extend(self._check_rule_coverage(schema))
        issues.extend(self._check_confidence_thresholds(schema))
        issues.extend(self._check_cross_references(schema))
        issues.extend(self._check_timing_definitions(schema))
        issues.extend(self._check_pkpd_spec(schema))
        issues.extend(self._check_population_flag_warnings(schema))

        errors = sum(1 for i in issues if i.severity == QCSeverity.ERROR)
        warnings = sum(1 for i in issues if i.severity == QCSeverity.WARNING)
        infos = sum(1 for i in issues if i.severity == QCSeverity.INFO)

        # Readiness score: penalize errors heavily, warnings moderately
        total_checks = max(1, len(schema.outputs_master) * 5 + 20)
        penalty = (errors * 3 + warnings * 1) / total_checks
        readiness = max(0.0, min(1.0, 1.0 - penalty))

        # Completeness
        complete_outputs = sum(
            1 for o in schema.outputs_master
            if o.population and o.analysis and o.data_specification
        )
        completeness_pct = (
            complete_outputs / len(schema.outputs_master) * 100
            if schema.outputs_master else 0.0
        )

        low_confidence = sum(
            1 for o in schema.outputs_master
            if o.confidence_score < self.confidence_threshold
        )

        report = QCReport(
            total_outputs=len(schema.outputs_master),
            total_issues=len(issues),
            errors=errors,
            warnings=warnings,
            infos=infos,
            overall_readiness_score=round(readiness, 3),
            issues=issues,
            completeness_pct=round(completeness_pct, 1),
            low_confidence_count=low_confidence,
        )

        logger.info(
            "QC complete — Errors: %d, Warnings: %d, Readiness: %.1f%%",
            errors, warnings, readiness * 100
        )
        return report

    # ------------------------------------------------------------------
    # Individual check methods
    # ------------------------------------------------------------------

    def _check_study_metadata(self, schema: ClinicalIntelligenceSchema) -> List[QCIssue]:
        issues = []
        meta = schema.study_metadata

        if not meta.protocol_id:
            issues.append(QCIssue(
                severity=QCSeverity.ERROR,
                category="Study Metadata",
                message="Protocol ID not found in document",
                suggested_fix="Verify the SAP document header contains a protocol number",
            ))
        if not meta.study_title:
            issues.append(QCIssue(
                severity=QCSeverity.WARNING,
                category="Study Metadata",
                message="Study title could not be extracted",
            ))
        if not meta.phase:
            issues.append(QCIssue(
                severity=QCSeverity.WARNING,
                category="Study Metadata",
                message="Study phase not detected",
            ))
        if not meta.nct_number:
            issues.append(QCIssue(
                severity=QCSeverity.INFO,
                category="Study Metadata",
                message="NCT number not found — may not be registered",
            ))
        return issues

    def _check_populations(self, schema: ClinicalIntelligenceSchema) -> List[QCIssue]:
        issues = []
        if not schema.populations:
            issues.append(QCIssue(
                severity=QCSeverity.ERROR,
                category="Populations",
                message="No analysis populations extracted",
                suggested_fix="Check the SAP section on 'Analysis Populations' and verify parsing",
            ))
            return issues

        abbrevs = [p.abbreviation for p in schema.populations]

        # Check ITT or FAS exists
        if "ITT" not in abbrevs and "FAS" not in abbrevs:
            issues.append(QCIssue(
                severity=QCSeverity.WARNING,
                category="Populations",
                message="No ITT or FAS population found — unusual for a Phase 2/3 trial",
                suggested_fix="Verify primary analysis population definition in SAP",
            ))

        # Check safety population
        if "SAF" not in abbrevs:
            issues.append(QCIssue(
                severity=QCSeverity.WARNING,
                category="Populations",
                message="No Safety population (SAF) identified",
            ))

        # Check each population has a flag variable
        for pop in schema.populations:
            if not pop.adam_flag_variable:
                issues.append(QCIssue(
                    severity=QCSeverity.WARNING,
                    category="Populations",
                    output_id=pop.population_id,
                    message=f"Population '{pop.abbreviation}' has no ADaM flag variable assigned",
                    suggested_fix=f"Assign flag variable (e.g., {pop.abbreviation}FL) in ADSL",
                ))
            if not pop.formal_definition:
                issues.append(QCIssue(
                    severity=QCSeverity.INFO,
                    category="Populations",
                    output_id=pop.population_id,
                    message=f"Population '{pop.abbreviation}' has no formal definition extracted",
                ))
        return issues

    def _check_endpoints(self, schema: ClinicalIntelligenceSchema) -> List[QCIssue]:
        issues = []
        if not schema.endpoints:
            issues.append(QCIssue(
                severity=QCSeverity.ERROR,
                category="Endpoints",
                message="No endpoints extracted from SAP",
                suggested_fix="Check the 'Objectives and Endpoints' section of the SAP",
            ))
            return issues

        primary_eps = [e for e in schema.endpoints if e.classification == EndpointClassification.PRIMARY.value]
        if not primary_eps:
            issues.append(QCIssue(
                severity=QCSeverity.ERROR,
                category="Endpoints",
                message="No primary endpoint identified",
                suggested_fix="Verify the primary endpoint section in the SAP",
            ))
        elif len(primary_eps) > 2:
            issues.append(QCIssue(
                severity=QCSeverity.WARNING,
                category="Endpoints",
                message=f"{len(primary_eps)} primary endpoints identified — unusual; verify SAP",
            ))

        # Check multiplicity for key secondary
        key_secondary = [e for e in schema.endpoints if e.classification == EndpointClassification.KEY_SECONDARY.value]
        for ep in key_secondary:
            if not ep.multiplicity:
                issues.append(QCIssue(
                    severity=QCSeverity.WARNING,
                    category="Endpoints",
                    output_id=ep.endpoint_id,
                    message=f"Key Secondary endpoint '{ep.description[:60]}' has no multiplicity adjustment defined",
                    suggested_fix="Define alpha allocation in multiplicity section of SAP",
                ))

        # ICH E9(R1) estimand check for primary
        for ep in primary_eps:
            if not ep.estimand:
                issues.append(QCIssue(
                    severity=QCSeverity.WARNING,
                    category="Endpoints",
                    output_id=ep.endpoint_id,
                    message=f"Primary endpoint missing ICH E9(R1) estimand definition",
                    suggested_fix="Add estimand framework (treatment, population, variable, ICEs, summary measure)",
                ))
        return issues

    def _check_outputs(self, schema: ClinicalIntelligenceSchema) -> List[QCIssue]:
        issues = []
        if len(schema.outputs_master) < self.min_outputs:
            issues.append(QCIssue(
                severity=QCSeverity.WARNING,
                category="Outputs",
                message=f"Only {len(schema.outputs_master)} outputs extracted (expected >= {self.min_outputs})",
                suggested_fix="Check TLF section of SAP and shell document are both parsed",
            ))

        for output in schema.outputs_master:
            if not output.title or len(output.title) < 5:
                issues.append(QCIssue(
                    severity=QCSeverity.ERROR,
                    category="Output Quality",
                    output_id=output.output_id,
                    message=f"Output {output.output_number} has missing or very short title",
                    suggested_fix="Verify title extraction from SAP and shell document",
                ))
            if not output.output_number:
                issues.append(QCIssue(
                    severity=QCSeverity.ERROR,
                    category="Output Quality",
                    output_id=output.output_id,
                    message=f"Output '{output.title or output.output_id}' has no output number",
                ))
        return issues

    def _check_output_completeness(self, schema: ClinicalIntelligenceSchema) -> List[QCIssue]:
        issues = []
        for output in schema.outputs_master:
            missing = []
            if not output.population:
                missing.append("population")
            if not output.analysis:
                missing.append("analysis method")
            if not output.data_specification or not output.data_specification.input_datasets:
                missing.append("ADaM datasets")

            if missing:
                severity = QCSeverity.ERROR if "population" in missing else QCSeverity.WARNING
                issues.append(QCIssue(
                    severity=severity,
                    category="Output Completeness",
                    output_id=output.output_id,
                    message=f"Output {output.output_number} missing: {', '.join(missing)}",
                    suggested_fix=f"Review SAP section for this output and verify extraction of {', '.join(missing)}",
                ))
        return issues

    def _check_duplicate_outputs(self, schema: ClinicalIntelligenceSchema) -> List[QCIssue]:
        issues = []
        seen_ids: Dict[str, str] = {}
        seen_nums: Dict[str, str] = {}

        for output in schema.outputs_master:
            if output.output_id in seen_ids:
                issues.append(QCIssue(
                    severity=QCSeverity.ERROR,
                    category="Duplicate Detection",
                    output_id=output.output_id,
                    message=f"Duplicate output_id: {output.output_id}",
                    suggested_fix="Ensure output IDs are unique; check parser deduplication logic",
                ))
            else:
                seen_ids[output.output_id] = output.output_id

            if output.output_number:
                if output.output_number in seen_nums:
                    issues.append(QCIssue(
                        severity=QCSeverity.ERROR,
                        category="Duplicate Detection",
                        output_id=output.output_id,
                        message=f"Duplicate output number: {output.output_number}",
                        suggested_fix="Two outputs share the same number — verify SAP numbering",
                    ))
                else:
                    seen_nums[output.output_number] = output.output_id
        return issues

    def _check_population_consistency(self, schema: ClinicalIntelligenceSchema) -> List[QCIssue]:
        issues = []
        # Check that outputs referencing same population use consistent flag variable
        pop_flags: Dict[str, Set[str]] = {}
        for output in schema.outputs_master:
            if output.population:
                abbrev = output.population.abbreviation
                flag = output.population.adam_flag_variable or ""
                if abbrev not in pop_flags:
                    pop_flags[abbrev] = set()
                if flag:
                    pop_flags[abbrev].add(flag)

        for abbrev, flags in pop_flags.items():
            if len(flags) > 1:
                issues.append(QCIssue(
                    severity=QCSeverity.ERROR,
                    category="Population Consistency",
                    message=f"Population '{abbrev}' has inconsistent flag variables: {flags}",
                    suggested_fix="Standardize flag variable name across all outputs",
                ))
        return issues

    def _check_mock_shells(self, schema: ClinicalIntelligenceSchema) -> List[QCIssue]:
        issues = []
        outputs_without_shells = 0
        for output in schema.outputs_master:
            if output.mock_shell is None:
                outputs_without_shells += 1
            elif output.mock_shell.parse_confidence < 0.50:
                issues.append(QCIssue(
                    severity=QCSeverity.WARNING,
                    category="Mock Shell",
                    output_id=output.output_id,
                    message=f"Output {output.output_number} mock shell has low parse confidence ({output.mock_shell.parse_confidence:.2f})",
                    suggested_fix="Review shell document table structure for this output",
                ))
            elif not output.mock_shell.columns:
                issues.append(QCIssue(
                    severity=QCSeverity.WARNING,
                    category="Mock Shell",
                    output_id=output.output_id,
                    message=f"Output {output.output_number} mock shell has no columns parsed",
                ))

        if outputs_without_shells > 0:
            issues.append(QCIssue(
                severity=QCSeverity.INFO,
                category="Mock Shell",
                message=f"{outputs_without_shells} outputs have no mock shell — shell document may not have been provided",
            ))
        return issues

    def _check_visit_schedule(self, schema: ClinicalIntelligenceSchema) -> List[QCIssue]:
        issues = []
        if not schema.visit_schedule:
            issues.append(QCIssue(
                severity=QCSeverity.WARNING,
                category="Visit Schedule",
                message="No visit schedule extracted",
                suggested_fix="Check if SAP contains visit window tables",
            ))
            return issues

        # Check primary timepoint exists
        primary_visits = [v for v in schema.visit_schedule if v.primary_timepoint]
        if not primary_visits:
            issues.append(QCIssue(
                severity=QCSeverity.INFO,
                category="Visit Schedule",
                message="No primary timepoint flagged in visit schedule",
            ))

        # Check windows are defined
        missing_windows = [v for v in schema.visit_schedule
                           if v.analysis_visit_flag and v.window_pre_days is None]
        if missing_windows:
            issues.append(QCIssue(
                severity=QCSeverity.WARNING,
                category="Visit Schedule",
                message=f"{len(missing_windows)} analysis visits have no window definition",
                detail=", ".join(v.visit_label for v in missing_windows[:5]),
            ))
        return issues

    def _check_rule_coverage(self, schema: ClinicalIntelligenceSchema) -> List[QCIssue]:
        issues = []
        rule_types = {r.rule_type for r in schema.rule_engine_output}

        # Expected rule types for a full SAP
        expected_types = {
            "baseline_definition", "visit_window", "filter",
            "derivation", "date_imputation"
        }
        missing_rule_types = expected_types - {rt.value for rt in rule_types}
        if missing_rule_types:
            issues.append(QCIssue(
                severity=QCSeverity.WARNING,
                category="Rule Coverage",
                message=f"Rule types not extracted: {', '.join(sorted(missing_rule_types))}",
                suggested_fix="Check SAP sections for baseline definitions, visit windows, and derivation rules",
            ))
        return issues

    def _check_confidence_thresholds(self, schema: ClinicalIntelligenceSchema) -> List[QCIssue]:
        issues = []
        low_conf_outputs = [
            o for o in schema.outputs_master
            if o.confidence_score < self.confidence_threshold
        ]
        if low_conf_outputs:
            issues.append(QCIssue(
                severity=QCSeverity.WARNING,
                category="Confidence",
                message=f"{len(low_conf_outputs)} outputs below confidence threshold ({self.confidence_threshold:.0%})",
                detail=", ".join(o.output_id for o in low_conf_outputs[:10]),
                suggested_fix="Review these outputs manually — extraction may be incomplete",
            ))

        # Individual output confidence
        for output in schema.outputs_master:
            if output.confidence_score < 0.50:
                issues.append(QCIssue(
                    severity=QCSeverity.ERROR,
                    category="Confidence",
                    output_id=output.output_id,
                    message=f"Output {output.output_number} confidence critically low ({output.confidence_score:.2f})",
                    suggested_fix="Manual review required for this output",
                ))
        return issues


    def _check_timing_definitions(self, schema: ClinicalIntelligenceSchema) -> List[QCIssue]:
        """Check that key timing definitions were extracted."""
        issues = []
        categories = {t.category for t in schema.timing_definitions}

        if "study_day_anchor" not in categories and "ady_formula" not in categories:
            issues.append(QCIssue(
                severity=QCSeverity.WARNING,
                category="Timing Definitions",
                message="Study day convention (Day 0 vs Day 1) not explicitly found in SAP",
                suggested_fix="Verify ADY formula in SAP programming notes section",
            ))
        if "teae_window" not in categories:
            issues.append(QCIssue(
                severity=QCSeverity.INFO,
                category="Timing Definitions",
                message="TEAE observation window (N days after last dose) not extracted",
                suggested_fix="Check SAP safety section for TEAE definition timing",
            ))
        return issues

    def _check_pkpd_spec(self, schema: ClinicalIntelligenceSchema) -> List[QCIssue]:
        """Check PK/PD specification completeness when PK/PD study detected."""
        issues = []
        if not schema.study_metadata.has_pk_analysis:
            return issues
        if schema.pkpd_spec is None:
            issues.append(QCIssue(
                severity=QCSeverity.ERROR,
                category="PK/PD",
                message="Study flagged as having PK analysis but no PK/PD spec was extracted",
                suggested_fix="Check ADPC/ADPP, PKAP, or PK sections of the SAP",
            ))
            return issues
        spec = schema.pkpd_spec
        if not spec.parameters:
            issues.append(QCIssue(
                severity=QCSeverity.WARNING,
                category="PK/PD",
                message="No PK parameters (Cmax, AUC, etc.) extracted from SAP",
                suggested_fix="Verify PK parameters section in SAP or PKAP",
            ))
        if spec.concentration_spec and spec.concentration_spec.bloq_handling is None:
            issues.append(QCIssue(
                severity=QCSeverity.WARNING,
                category="PK/PD",
                message="BLoQ handling rule not found in SAP",
                suggested_fix="Verify how BLoQ values are handled (set to 0, LLOQ/2, or excluded)",
            ))
        if spec.concentration_spec and spec.concentration_spec.time_reference is None:
            issues.append(QCIssue(
                severity=QCSeverity.INFO,
                category="PK/PD",
                message="ARELTM time reference (first dose vs most recent dose) not specified",
                suggested_fix="Check PK data handling section for ARELTM convention",
            ))
        return issues

    def _check_population_flag_warnings(self, schema: ClinicalIntelligenceSchema) -> List[QCIssue]:
        """Remind users that population flag variable names are sponsor-specific."""
        issues = []
        for pop in schema.populations:
            if pop.adam_flag_variable and pop.flag_verification_required:
                issues.append(QCIssue(
                    severity=QCSeverity.INFO,
                    category="Population Flags",
                    output_id=pop.population_id,
                    message=(
                        f"Population '{pop.abbreviation}' flag variable '{pop.adam_flag_variable}' "
                        f"is a default — verify against study-specific ADaM spec and SAP"
                    ),
                    suggested_fix="Confirm ADSL flag variable name with stat programmer",
                ))
        return issues
    def _check_cross_references(self, schema: ClinicalIntelligenceSchema) -> List[QCIssue]:
        issues = []
        output_ids = {o.output_id for o in schema.outputs_master}

        for output in schema.outputs_master:
            for rel in output.related_outputs:
                ref_id = rel.get("output_id", "")
                if ref_id and ref_id not in output_ids:
                    issues.append(QCIssue(
                        severity=QCSeverity.WARNING,
                        category="Cross Reference",
                        output_id=output.output_id,
                        message=f"Output {output.output_number} references non-existent output: {ref_id}",
                    ))

        # Check endpoint cross-references
        endpoint_ids = {e.endpoint_id for e in schema.endpoints}
        for output in schema.outputs_master:
            for ep in output.endpoints:
                if ep.endpoint_id not in endpoint_ids:
                    issues.append(QCIssue(
                        severity=QCSeverity.INFO,
                        category="Cross Reference",
                        output_id=output.output_id,
                        message=f"Output references endpoint not in global registry: {ep.endpoint_id}",
                    ))
        return issues
