"""
Central data models — Python standard dataclasses only (no external dependencies).
Compatible with Python 3.9+.

Design principles:
  - Every field has a safe default.
  - Enums use string values for JSON serialisation transparency.
  - Confidence scores clamped to [0.0, 1.0] via __post_init__.
  - datetime fields use timezone-aware ISO 8601 strings.
  - No business logic in models.

EXTENSIBILITY: Add new fields to any dataclass freely.
"""
from __future__ import annotations
import json, uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional

def _utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()

def _clamp(v: float) -> float:
    return max(0.0, min(1.0, float(v)))

class OutputType(str, Enum):
    TABLE = "Table"
    LISTING = "Listing"
    FIGURE = "Figure"
    APPENDIX = "Appendix"

class OutputClass(str, Enum):
    EFFICACY = "Efficacy"
    SAFETY = "Safety"
    PK = "PK"
    PD = "PD"
    BIOMARKER = "Biomarker"
    DEMOGRAPHICS = "Demographics"
    DISPOSITION = "Disposition"
    COMPLIANCE = "Compliance"
    QOL = "QoL"
    SUBGROUP = "Subgroup"
    OTHER = "Other"

class RuleType(str, Enum):
    DERIVATION = "derivation"
    FILTER = "filter"
    IMPUTATION = "imputation"
    DATE_IMPUTATION = "date_imputation"
    FLAG = "flag"
    CLASSIFICATION = "classification"
    CENSORING = "censoring"
    VISIT_WINDOW = "visit_window"
    BASELINE_DEFINITION = "baseline_definition"
    STUDY_DAY = "study_day"
    TIMING_DEFINITION = "timing_definition"
    PK_RULE = "pk_rule"
    PD_RULE = "pd_rule"
    LOCF = "LOCF"
    BOCF = "BOCF"
    WORST_CASE = "worst_case"
    COMPOSITE = "composite"

class QCSeverity(str, Enum):
    ERROR = "ERROR"
    WARNING = "WARNING"
    INFO = "INFO"

class EndpointClassification(str, Enum):
    PRIMARY = "Primary"
    KEY_SECONDARY = "Key Secondary"
    SECONDARY = "Secondary"
    EXPLORATORY = "Exploratory"
    SAFETY = "Safety"
    PK = "PK"
    PD = "PD"

class ImputationStrategy(str, Enum):
    """ICH E9(R1) Intercurrent Event strategies."""
    TREATMENT_POLICY = "Treatment policy"
    HYPOTHETICAL = "Hypothetical"
    COMPOSITE = "Composite"
    WHILE_ON_TREATMENT = "While on treatment"
    PRINCIPAL_STRATUM = "Principal stratum"

class MissingDataStrategy(str, Enum):
    """Missing data handling methods — separate from ICE strategies."""
    MAR = "Missing at Random (MAR)"
    MCAR = "Missing Completely at Random (MCAR)"
    MNAR = "Missing Not at Random (MNAR)"
    MULTIPLE_IMPUTATION = "Multiple Imputation"
    LOCF = "Last Observation Carried Forward (LOCF)"
    BOCF = "Baseline Observation Carried Forward (BOCF)"
    WORST_CASE = "Worst Case Imputation"
    COMPLETER = "Completer Analysis"

class StudyDayConvention(str, Enum):
    DAY_ONE = "Day 1 = first dose (no Day 0)"
    DAY_ZERO = "Day 0 = first dose"
    UNKNOWN = "Unknown"

class TieBreakingRule(str, Enum):
    CLOSEST_TO_NOMINAL = "Closest to nominal date"
    LATEST = "Latest date in window"
    EARLIEST = "Earliest date in window"
    UNSPECIFIED = "Not specified"

@dataclass
class SystemMetadata:
    parsing_job_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    parser_version: str = "3.1.0"
    input_source_hash: Optional[str] = None
    human_review_status: str = "pending"
    reviewed_by: Optional[str] = None
    review_date: Optional[str] = None
    review_notes: Optional[str] = None
    execution_time_ms: Optional[int] = None
    created_at: str = field(default_factory=_utcnow)

@dataclass
class DocumentMetadata:
    file_name: str = ""; file_type: str = ""; file_size_bytes: Optional[int] = None
    version: Optional[str] = None; created_date: Optional[str] = None
    parsed_date: str = field(default_factory=_utcnow)
    total_pages: Optional[int] = None; total_outputs: Optional[int] = None
    role: str = "SAP"  # SAP | Shell | Protocol | ADaM_Spec | PKAP

@dataclass
class StudyMetadata:
    protocol_id: Optional[str] = None; study_title: Optional[str] = None
    sponsor: Optional[str] = None; phase: Optional[str] = None
    indication: Optional[str] = None; therapeutic_area: Optional[str] = None
    nct_number: Optional[str] = None; eudract_number: Optional[str] = None
    regulatory_agencies: List[str] = field(default_factory=list)  # never defaults to FDA
    blinding: Optional[str] = None; randomization_ratio: Optional[str] = None
    data_cutoff_date: Optional[str] = None; primary_completion_date: Optional[str] = None
    has_study_schema_diagram: bool = False
    study_day_convention: str = StudyDayConvention.UNKNOWN.value
    has_pk_analysis: bool = False
    has_pd_analysis: bool = False
    has_pkpd_analysis: bool = False

@dataclass
class TimingDefinition:
    timing_id: str = field(default_factory=lambda: f"timing_{uuid.uuid4().hex[:8]}")
    category: str = ""      # study_day_anchor|followup_definition|teae_window|washout|on_treatment|ady_formula|days_after_last_dose
    description: str = ""
    verbatim_text: str = ""
    n_days: Optional[int] = None
    reference_event: Optional[str] = None  # "last dose"|"first dose"|"randomization"|"EOT"
    adam_variables: List[str] = field(default_factory=list)
    pseudocode: Optional[str] = None
    source_section: Optional[str] = None
    source_page: Optional[int] = None
    confidence: float = 0.0
    def __post_init__(self): self.confidence = _clamp(self.confidence)

@dataclass
class Population:
    population_id: str = ""; label: str = ""; abbreviation: str = ""
    hierarchy_order: int = 99; formal_definition: Optional[str] = None
    inclusion_criteria: List[str] = field(default_factory=list)
    exclusion_criteria: List[str] = field(default_factory=list)
    adam_flag_variable: Optional[str] = None
    flag_verification_required: bool = True  # sponsor conventions vary — always verify
    adam_dataset: str = "ADSL"
    derivation_rule: Optional[str] = None; expected_n: Optional[int] = None
    source_section: Optional[str] = None; source_page: Optional[int] = None
    source_text: Optional[str] = None; confidence: float = 0.0
    def __post_init__(self): self.confidence = _clamp(self.confidence)

@dataclass
class IntercurrentEvent:
    """ICH E9(R1) ICE: one event + one of the 5 defined strategies."""
    event_name: str = ""
    event_code: Optional[str] = None
    strategy: str = ImputationStrategy.TREATMENT_POLICY.value
    strategy_rationale: Optional[str] = None
    source_text: Optional[str] = None

@dataclass
class Estimand:
    """Full ICH E9(R1) estimand — all 5 attributes."""
    treatment: Optional[str] = None
    population_id: Optional[str] = None        # links to Population.population_id
    population_label: Optional[str] = None
    variable: Optional[str] = None
    intercurrent_events: List[IntercurrentEvent] = field(default_factory=list)
    summary_measure: Optional[str] = None
    sensitivity_analyses: List[str] = field(default_factory=list)
    missing_data_strategy: Optional[str] = None

@dataclass
class Multiplicity:
    procedure: Optional[str] = None; family: Optional[str] = None
    alpha: float = 0.05; alpha_allocated: Optional[float] = None
    testing_order: Optional[int] = None; testing_sequence: Optional[str] = None

@dataclass
class Endpoint:
    endpoint_id: str = ""
    classification: str = EndpointClassification.SECONDARY.value
    testing_order: Optional[int] = None; description: str = ""
    measurement_instrument: Optional[str] = None
    timepoints: List[str] = field(default_factory=list)
    summary_measure: Optional[str] = None; estimand: Optional[Estimand] = None
    multiplicity: Optional[Multiplicity] = None
    adam_variables: List[str] = field(default_factory=list)
    adam_datasets: List[str] = field(default_factory=list)  # study-specific
    sdtm_source: List[str] = field(default_factory=list)
    outputs_referencing: List[str] = field(default_factory=list)
    source_section: Optional[str] = None; source_page: Optional[int] = None
    source_text: Optional[str] = None; confidence: float = 0.0
    def __post_init__(self): self.confidence = _clamp(self.confidence)

@dataclass
class VisitWindow:
    visit_id: str = ""; visit_label: str = ""; visit_type: str = "On-treatment"
    nominal_day: Optional[int] = None; window_pre_days: Optional[int] = None
    window_post_days: Optional[int] = None; window_rule: Optional[str] = None
    tie_breaking_rule: str = TieBreakingRule.UNSPECIFIED.value
    unscheduled_excluded_from_primary: Optional[bool] = None
    adam_visit_value: Optional[str] = None; adam_visitnum: Optional[float] = None
    analysis_visit_flag: bool = False; primary_timepoint: bool = False
    date_imputation_rule: Optional[str] = None
    assessments_performed: List[str] = field(default_factory=list)
    source_page: Optional[int] = None; confidence: float = 0.0

@dataclass
class PKParameter:
    paramcd: str = ""; param: str = ""
    sdtm_source: str = "PP"; adam_dataset: str = "ADPP"
    unit: Optional[str] = None; log_transformed: bool = False
    summary_statistics: List[str] = field(default_factory=list)

@dataclass
class PKConcentrationSpec:
    analyte: Optional[str] = None; matrix: Optional[str] = None
    assay_lloq: Optional[float] = None; assay_lloq_unit: Optional[str] = None
    bloq_handling: Optional[str] = None
    time_reference: Optional[str] = None      # "first dose" | "most recent dose"
    predose_atptn_convention: Optional[str] = None  # "0" | "negative"
    nominal_timepoints: List[str] = field(default_factory=list)
    excluded_conditions: List[str] = field(default_factory=list)

@dataclass
class PKPDSpec:
    pk_populations: List[str] = field(default_factory=list)
    nca_software: Optional[str] = None
    parameters: List[PKParameter] = field(default_factory=list)
    concentration_spec: Optional[PKConcentrationSpec] = None
    has_nca: bool = False; has_pop_pk: bool = False
    has_exposure_response: bool = False; has_pd_endpoints: bool = False
    pd_biomarkers: List[str] = field(default_factory=list)
    er_model_type: Optional[str] = None
    adam_datasets_required: List[str] = field(default_factory=list)
    sdtm_domains_source: List[str] = field(default_factory=list)
    source_section: Optional[str] = None; confidence: float = 0.0
    def __post_init__(self): self.confidence = _clamp(self.confidence)

@dataclass
class ExtractedRule:
    rule_id: str = field(default_factory=lambda: f"rule_{uuid.uuid4().hex[:8]}")
    rule_type: RuleType = RuleType.DERIVATION; rule_text_verbatim: str = ""
    rule_logic_structured: Optional[Dict[str, Any]] = None; pseudocode: Optional[str] = None
    applies_to_datasets: List[str] = field(default_factory=list)
    applies_to_variables: List[str] = field(default_factory=list)
    applies_to_outputs: List[str] = field(default_factory=list)
    applies_to_populations: List[str] = field(default_factory=list)
    priority_order: int = 99; exception_conditions: List[str] = field(default_factory=list)
    confidence: float = 0.0; source_section: Optional[str] = None
    source_page: Optional[int] = None; validated: bool = False

@dataclass
class ProgrammingRule:
    rule: str = ""; rule_type: RuleType = RuleType.DERIVATION; severity: str = "mandatory"
    sas_hint: Optional[str] = None; r_hint: Optional[str] = None
    confidence: float = 0.0; source_text: Optional[str] = None; validated: bool = False

@dataclass
class MockShellColumn:
    position: int = 0; header: str = ""; width_chars: Optional[int] = None
    alignment: str = "left"; format_mask: Optional[str] = None; data_type: str = "string"

@dataclass
class MockShellRow:
    position: int = 0; label: str = ""; indent_level: int = 0
    is_header: bool = False; is_total: bool = False

@dataclass
class MockShell:
    table_id: Optional[str] = None
    columns: List[MockShellColumn] = field(default_factory=list)
    rows: List[MockShellRow] = field(default_factory=list)
    visits: List[str] = field(default_factory=list)
    treatment_arms: List[str] = field(default_factory=list)
    spanning_headers: List[Dict[str, Any]] = field(default_factory=list)
    footnotes: List[str] = field(default_factory=list)
    raw_text: Optional[str] = None; parse_confidence: float = 0.0

@dataclass
class Traceability:
    page_number: Optional[int] = None
    page_number_is_estimated: bool = True  # page estimates are unreliable; always flag
    paragraph_id: Optional[str] = None
    table_ref: Optional[str] = None; section_id: Optional[str] = None
    source_excerpt: Optional[str] = None; confidence: float = 0.0

@dataclass
class DataSpecification:
    input_datasets: List[str] = field(default_factory=list)
    key_variables: Dict[str, List[str]] = field(default_factory=dict)
    derivations: Dict[str, str] = field(default_factory=dict)
    time_points: List[str] = field(default_factory=list)
    analysis_visit: Optional[str] = None; where_clause: Optional[str] = None
    dataset_note: str = "Dataset names are indicative; verify against study-specific ADaM specs."

@dataclass
class AnalysisSpec:
    methods: List[str] = field(default_factory=list)
    model_statement: Optional[str] = None
    covariates: List[str] = field(default_factory=list)
    imputation: List[str] = field(default_factory=list)
    missing_data_assumption: Optional[str] = None
    statistical_tests: List[str] = field(default_factory=list)
    sensitivity_analyses: List[str] = field(default_factory=list)
    confidence: float = 0.0

@dataclass
class WorkflowStatus:
    shell_approved: bool = False; programmer: Optional[str] = None
    qc_analyst: Optional[str] = None; qc_status: str = "not_started"; locked: bool = False

@dataclass
class AnalysisOutput:
    output_id: str = ""; output_type: OutputType = OutputType.TABLE
    output_class: OutputClass = OutputClass.OTHER; output_number: Optional[str] = None
    title: Optional[str] = None; full_title: Optional[str] = None
    section_id: Optional[str] = None; display_order: int = 0
    population: Optional[Population] = None
    endpoints: List[Endpoint] = field(default_factory=list)
    analysis: Optional[AnalysisSpec] = None
    data_specification: Optional[DataSpecification] = None
    mock_shell: Optional[MockShell] = None
    programming_rules: List[ProgrammingRule] = field(default_factory=list)
    related_outputs: List[Dict[str, str]] = field(default_factory=list)
    traceability: Optional[Traceability] = None
    workflow_status: WorkflowStatus = field(default_factory=WorkflowStatus)
    confidence_score: float = 0.0
    is_appendix_output: bool = False
    appendix_label: Optional[str] = None
    def __post_init__(self): self.confidence_score = _clamp(self.confidence_score)

@dataclass
class QCIssue:
    issue_id: str = field(default_factory=lambda: f"qc_{uuid.uuid4().hex[:8]}")
    severity: QCSeverity = QCSeverity.WARNING; category: str = ""
    output_id: Optional[str] = None; message: str = ""
    detail: Optional[str] = None; suggested_fix: Optional[str] = None
    auto_fixable: bool = False

@dataclass
class QCReport:
    report_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    generated_at: str = field(default_factory=_utcnow)
    total_outputs: int = 0; total_issues: int = 0; errors: int = 0
    warnings: int = 0; infos: int = 0; overall_readiness_score: float = 0.0
    issues: List[QCIssue] = field(default_factory=list)
    completeness_pct: float = 0.0; low_confidence_count: int = 0

@dataclass
class ClinicalIntelligenceSchema:
    system_metadata: SystemMetadata = field(default_factory=SystemMetadata)
    documents: List[DocumentMetadata] = field(default_factory=list)
    study_metadata: StudyMetadata = field(default_factory=StudyMetadata)
    populations: List[Population] = field(default_factory=list)
    endpoints: List[Endpoint] = field(default_factory=list)
    visit_schedule: List[VisitWindow] = field(default_factory=list)
    timing_definitions: List[TimingDefinition] = field(default_factory=list)
    pkpd_spec: Optional[PKPDSpec] = None
    outputs_master: List[AnalysisOutput] = field(default_factory=list)
    rule_engine_output: List[ExtractedRule] = field(default_factory=list)
    qc_report: Optional[QCReport] = None
    sections: List[Dict[str, Any]] = field(default_factory=list)
    toc_map: Dict[str, str] = field(default_factory=dict)
    cross_refs: Dict[str, str] = field(default_factory=dict)
    _pending_timing_rules: List[Any] = field(default_factory=list)

    def get_output_by_id(self, oid: str) -> Optional[AnalysisOutput]:
        return next((o for o in self.outputs_master if o.output_id == oid), None)

    def get_population_by_abbrev(self, abbrev: str) -> Optional[Population]:
        return next((p for p in self.populations if p.abbreviation.upper() == abbrev.upper()), None)

    def outputs_by_class(self, oc: OutputClass) -> List[AnalysisOutput]:
        return [o for o in self.outputs_master if o.output_class == oc]

    def get_timing_by_category(self, category: str) -> List[TimingDefinition]:
        return [t for t in self.timing_definitions if t.category == category]

    def to_summary_dict(self) -> Dict[str, Any]:
        return {
            "protocol_id": self.study_metadata.protocol_id,
            "total_outputs": len(self.outputs_master),
            "total_populations": len(self.populations),
            "total_endpoints": len(self.endpoints),
            "total_rules": len(self.rule_engine_output),
            "total_visits": len(self.visit_schedule),
            "total_timing_definitions": len(self.timing_definitions),
            "has_pk": self.study_metadata.has_pk_analysis,
            "has_pd": self.study_metadata.has_pd_analysis,
            "qc_readiness": self.qc_report.overall_readiness_score if self.qc_report else 0.0,
        }

    def model_dump_json(self, indent: int = 2) -> str:
        def _s(obj: Any) -> Any:
            if isinstance(obj, Enum): return obj.value
            if isinstance(obj, (list, tuple)): return [_s(i) for i in obj]
            if isinstance(obj, dict): return {k: _s(v) for k, v in obj.items()}
            if hasattr(obj, "__dataclass_fields__"):
                return {k: _s(getattr(obj, k)) for k in obj.__dataclass_fields__}
            return obj
        return json.dumps(_s(self), indent=indent, default=str, ensure_ascii=False)
