"""
Export module: serialize ClinicalIntelligenceSchema to JSON, Excel, and SAS-ready formats.
"""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from src.models.schema import ClinicalIntelligenceSchema, AnalysisOutput
from src.utils import get_logger

logger = get_logger(__name__)


class ExportManager:
    """Handles all export formats for clinical intelligence data."""

    def __init__(self, output_dir: Path) -> None:
        self.output_dir = output_dir
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def export_json(self, schema: ClinicalIntelligenceSchema, filename: Optional[str] = None) -> Path:
        """Export full schema as formatted JSON."""
        if not filename:
            ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
            proto = schema.study_metadata.protocol_id or "UNKNOWN"
            filename = f"clinical_intelligence_{proto}_{ts}.json"

        output_path = self.output_dir / filename
        try:
            data = json.loads(schema.model_dump_json(indent=2))
            with output_path.open("w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, default=str, ensure_ascii=False)
            logger.info("JSON exported to %s", output_path)
        except Exception as exc:
            logger.error("JSON export failed: %s", exc)
            raise
        return output_path

    def export_excel(self, schema: ClinicalIntelligenceSchema, filename: Optional[str] = None) -> Path:
        """Export to multi-sheet Excel workbook."""
        try:
            import openpyxl
            from openpyxl.styles import Font, PatternFill, Alignment
        except ImportError:
            logger.error("openpyxl not installed — cannot export Excel")
            raise ImportError("openpyxl required for Excel export: pip install openpyxl")

        if not filename:
            ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
            proto = schema.study_metadata.protocol_id or "UNKNOWN"
            filename = f"clinical_intelligence_{proto}_{ts}.xlsx"

        output_path = self.output_dir / filename
        wb = openpyxl.Workbook()
        wb.remove(wb.active)

        header_font = Font(bold=True, color="FFFFFF")
        header_fill = PatternFill(start_color="1F3864", end_color="1F3864", fill_type="solid")
        center = Alignment(horizontal="center", vertical="center")

        def write_sheet(ws, headers: List[str], rows: List[List[Any]]) -> None:
            ws.append(headers)
            for cell in ws[1]:
                cell.font = header_font
                cell.fill = header_fill
                cell.alignment = center
            for row in rows:
                ws.append([str(v) if v is not None else "" for v in row])

        # Sheet 1: Study Summary
        ws_summary = wb.create_sheet("Study Summary")
        meta = schema.study_metadata
        write_sheet(ws_summary, ["Field", "Value"], [
            ["Protocol ID", meta.protocol_id or ""],
            ["Study Title", meta.study_title or ""],
            ["Sponsor", meta.sponsor or ""],
            ["Phase", meta.phase or ""],
            ["Indication", meta.indication or ""],
            ["NCT Number", meta.nct_number or ""],
            ["EudraCT", meta.eudract_number or ""],
            ["Blinding", meta.blinding or ""],
            ["Randomization Ratio", meta.randomization_ratio or ""],
            ["Total Outputs", len(schema.outputs_master)],
            ["Total Populations", len(schema.populations)],
            ["Total Endpoints", len(schema.endpoints)],
            ["Total Rules", len(schema.rule_engine_output)],
        ])

        # Sheet 2: Outputs Master
        ws_outputs = wb.create_sheet("Outputs Master")
        output_headers = [
            "Output ID", "Type", "Class", "Number", "Title",
            "Population", "Analysis Method", "Datasets",
            "Confidence", "Page", "QC Status"
        ]
        output_rows = []
        for o in schema.outputs_master:
            output_rows.append([
                o.output_id,
                o.output_type.value,
                o.output_class.value,
                o.output_number or "",
                o.title or "",
                o.population.abbreviation if o.population else "",
                ", ".join(o.analysis.methods) if o.analysis else "",
                ", ".join(o.data_specification.input_datasets) if o.data_specification else "",
                f"{o.confidence_score:.2f}",
                o.traceability.page_number if o.traceability else "",
                o.workflow_status.qc_status,
            ])
        write_sheet(ws_outputs, output_headers, output_rows)

        # Sheet 3: Populations
        ws_pops = wb.create_sheet("Populations")
        write_sheet(ws_pops,
            ["Population ID", "Label", "Abbreviation", "Flag Variable", "Dataset", "Definition", "Confidence"],
            [[p.population_id, p.label, p.abbreviation, p.adam_flag_variable or "",
              p.adam_dataset, p.formal_definition or "", f"{p.confidence:.2f}"]
             for p in schema.populations]
        )

        # Sheet 4: Endpoints
        ws_eps = wb.create_sheet("Endpoints")
        write_sheet(ws_eps,
            ["Endpoint ID", "Classification", "Testing Order", "Description", "Timepoints",
             "ADaM Variables", "Confidence"],
            [[e.endpoint_id, e.classification.value, e.testing_order or "",
              e.description, ", ".join(e.timepoints), ", ".join(e.adam_variables),
              f"{e.confidence:.2f}"]
             for e in schema.endpoints]
        )

        # Sheet 5: Rules
        ws_rules = wb.create_sheet("Rules")
        write_sheet(ws_rules,
            ["Rule ID", "Type", "Rule Text", "Pseudocode", "Datasets", "Variables", "Confidence"],
            [[r.rule_id, r.rule_type.value, r.rule_text_verbatim[:200],
              r.pseudocode or "", ", ".join(r.applies_to_datasets),
              ", ".join(r.applies_to_variables), f"{r.confidence:.2f}"]
             for r in schema.rule_engine_output]
        )

        # Sheet 6a: Timing Definitions (NEW)
        ws_timing = wb.create_sheet("Timing Definitions")
        write_sheet(ws_timing,
            ["ID", "Category", "Description", "N Days", "Reference Event",
             "ADaM Variables", "Pseudocode", "Page", "Confidence"],
            [[t.timing_id, t.category, t.description,
              str(t.n_days) if t.n_days is not None else "",
              t.reference_event or "",
              ", ".join(t.adam_variables),
              (t.pseudocode or "")[:200],
              str(t.source_page) if t.source_page else "",
              f"{t.confidence:.2f}"]
             for t in schema.timing_definitions]
        )

        # Sheet 6b: PK/PD Spec (NEW)
        if schema.pkpd_spec:
            ws_pk = wb.create_sheet("PK-PD Spec")
            pk = schema.pkpd_spec
            write_sheet(ws_pk, ["Field", "Value"], [
                ["Has NCA", "Yes" if pk.has_nca else "No"],
                ["Has PopPK", "Yes" if pk.has_pop_pk else "No"],
                ["Has Exposure-Response", "Yes" if pk.has_exposure_response else "No"],
                ["NCA Software", pk.nca_software or "Not specified"],
                ["ADaM Datasets Required", ", ".join(pk.adam_datasets_required)],
                ["SDTM Source Domains", ", ".join(pk.sdtm_domains_source)],
                ["PK Populations", ", ".join(pk.pk_populations)],
                ["E/R Model Type", pk.er_model_type or ""],
                ["PD Biomarkers", ", ".join(pk.pd_biomarkers)],
            ])
            if pk.concentration_spec:
                cs = pk.concentration_spec
                write_sheet(ws_pk, ["Field", "Value"], [
                    ["Matrix", cs.matrix or ""],
                    ["LLOQ", f"{cs.assay_lloq} {cs.assay_lloq_unit}" if cs.assay_lloq else ""],
                    ["BLoQ Handling", cs.bloq_handling or ""],
                    ["Time Reference (ARELTM)", cs.time_reference or ""],
                    ["Predose ATPTN Convention", cs.predose_atptn_convention or ""],
                ])
            if pk.parameters:
                ws_pk_params = wb.create_sheet("PK Parameters (ADPP)")
                write_sheet(ws_pk_params,
                    ["PARAMCD", "PARAM", "SDTM Source", "ADaM Dataset", "Unit",
                     "Log-transformed", "Summary Statistics"],
                    [[p.paramcd, p.param, p.sdtm_source, p.adam_dataset,
                      p.unit or "", "Yes" if p.log_transformed else "No",
                      ", ".join(p.summary_statistics)]
                     for p in pk.parameters]
                )

        # Sheet 6: Visit Schedule
        ws_visits = wb.create_sheet("Visit Schedule")
        write_sheet(ws_visits,
            ["Visit ID", "Label", "Type", "Nominal Day", "Window Pre", "Window Post",
             "AVISIT", "AVISITN", "Analysis Flag", "Primary"],
            [[v.visit_id, v.visit_label, v.visit_type, v.nominal_day or "",
              v.window_pre_days or "", v.window_post_days or "",
              v.adam_visit_value or "", v.adam_visitnum or "",
              "Y" if v.analysis_visit_flag else "N",
              "Y" if v.primary_timepoint else "N"]
             for v in schema.visit_schedule]
        )

        # Sheet 7: QC Report
        if schema.qc_report:
            ws_qc = wb.create_sheet("QC Report")
            write_sheet(ws_qc, ["Field", "Value"], [
                ["Readiness Score", f"{schema.qc_report.overall_readiness_score:.1%}"],
                ["Total Issues", schema.qc_report.total_issues],
                ["Errors", schema.qc_report.errors],
                ["Warnings", schema.qc_report.warnings],
                ["Info", schema.qc_report.infos],
                ["Completeness", f"{schema.qc_report.completeness_pct:.1f}%"],
                ["Low Confidence Outputs", schema.qc_report.low_confidence_count],
            ])

            ws_issues = wb.create_sheet("QC Issues")
            write_sheet(ws_issues,
                ["Issue ID", "Severity", "Category", "Output ID", "Message", "Suggested Fix"],
                [[i.issue_id, i.severity.value, i.category, i.output_id or "",
                  i.message, i.suggested_fix or ""]
                 for i in schema.qc_report.issues]
            )

        # Auto-size columns (approximate)
        for ws in wb.worksheets:
            for col in ws.columns:
                max_len = max((len(str(cell.value or "")) for cell in col), default=10)
                ws.column_dimensions[col[0].column_letter].width = min(max_len + 2, 60)

        wb.save(str(output_path))
        logger.info("Excel exported to %s", output_path)
        return output_path

    def export_sas_metadata(self, schema: ClinicalIntelligenceSchema, filename: Optional[str] = None) -> Path:
        """Export SAS-readable metadata file (SAS 7.5 transport via JSON)."""
        if not filename:
            ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
            filename = f"sas_metadata_{ts}.json"

        output_path = self.output_dir / filename
        sas_data: Dict[str, Any] = {
            "protocol_id": schema.study_metadata.protocol_id,
            "generated_at": datetime.utcnow().isoformat(),
            "outputs": [],
            "adam_datasets": [],
            "programming_rules": [],
        }

        # Outputs with SAS-relevant fields
        for o in schema.outputs_master:
            sas_output: Dict[str, Any] = {
                "output_id": o.output_id,
                "output_number": o.output_number,
                "title": o.title,
                "type": o.output_type.value,
                "population_flag": o.population.adam_flag_variable if o.population else None,
                "population_dataset": o.population.adam_dataset if o.population else "ADSL",
                "analysis_methods": o.analysis.methods if o.analysis else [],
                "input_datasets": o.data_specification.input_datasets if o.data_specification else [],
                "filter_vars": (o.data_specification.key_variables.get("filter_vars", [])
                                if o.data_specification else []),
                "analysis_vars": (o.data_specification.key_variables.get("analysis_vars", [])
                                  if o.data_specification else []),
                "programming_rules": [
                    {"rule": r.rule, "type": r.rule_type.value, "sas_hint": r.sas_hint or ""}
                    for r in o.programming_rules
                ],
            }
            sas_data["outputs"].append(sas_output)

        # ADaM dataset catalogue
        all_datasets: set = set()
        for o in schema.outputs_master:
            if o.data_specification:
                all_datasets.update(o.data_specification.input_datasets)
        sas_data["adam_datasets"] = sorted(all_datasets)

        # Programming rules
        for r in schema.rule_engine_output:
            sas_data["programming_rules"].append({
                "rule_id": r.rule_id,
                "type": r.rule_type.value,
                "text": r.rule_text_verbatim,
                "pseudocode": r.pseudocode or "",
                "datasets": r.applies_to_datasets,
                "variables": r.applies_to_variables,
                "confidence": r.confidence,
            })

        # Timing definitions for SAS programmers
        sas_data["timing_definitions"] = [
            {
                "timing_id": t.timing_id,
                "category": t.category,
                "description": t.description,
                "n_days": t.n_days,
                "reference_event": t.reference_event,
                "adam_variables": t.adam_variables,
                "pseudocode": t.pseudocode or "",
                "confidence": t.confidence,
            }
            for t in schema.timing_definitions
        ]

        # PK/PD spec for SAS programmers
        if schema.pkpd_spec:
            pk = schema.pkpd_spec
            sas_data["pkpd_spec"] = {
                "has_nca": pk.has_nca,
                "has_pop_pk": pk.has_pop_pk,
                "has_exposure_response": pk.has_exposure_response,
                "nca_software": pk.nca_software,
                "adam_datasets_required": pk.adam_datasets_required,
                "sdtm_domains_source": pk.sdtm_domains_source,
                "parameters": [
                    {"paramcd": p.paramcd, "param": p.param,
                     "sdtm_source": p.sdtm_source, "adam_dataset": p.adam_dataset,
                     "log_transformed": p.log_transformed}
                    for p in pk.parameters
                ],
            }

        with output_path.open("w", encoding="utf-8") as f:
            json.dump(sas_data, f, indent=2, default=str)

        logger.info("SAS metadata exported to %s", output_path)
        return output_path

    def export_summary_txt(self, schema: ClinicalIntelligenceSchema, filename: Optional[str] = None) -> Path:
        """Human-readable summary text file."""
        if not filename:
            filename = "extraction_summary.txt"
        output_path = self.output_dir / filename
        lines = [
            "=" * 70,
            "CLINICAL TRIAL INTELLIGENCE — EXTRACTION SUMMARY",
            "=" * 70,
            f"Protocol: {schema.study_metadata.protocol_id or 'N/A'}",
            f"Title: {schema.study_metadata.study_title or 'N/A'}",
            f"Phase: {schema.study_metadata.phase or 'N/A'}",
            f"Sponsor: {schema.study_metadata.sponsor or 'N/A'}",
            "",
            f"Outputs extracted: {len(schema.outputs_master)}",
            f"Populations: {len(schema.populations)} ({', '.join(p.abbreviation for p in schema.populations)})",
            f"Endpoints: {len(schema.endpoints)}",
            f"Rules: {len(schema.rule_engine_output)}",
            f"Visit windows: {len(schema.visit_schedule)}",
            "",
        ]
        if schema.qc_report:
            lines += [
                "QC SUMMARY",
                "-" * 40,
                f"Readiness score: {schema.qc_report.overall_readiness_score:.1%}",
                f"Errors: {schema.qc_report.errors}",
                f"Warnings: {schema.qc_report.warnings}",
                f"Completeness: {schema.qc_report.completeness_pct:.1f}%",
                "",
            ]
        lines += ["OUTPUTS", "-" * 40]
        for o in schema.outputs_master:
            pop_abbrev = o.population.abbreviation if o.population else "?"
            lines.append(f"  [{o.output_type.value[0]}] {o.output_number or '?'}: {(o.title or '')[:60]} [{pop_abbrev}] conf={o.confidence_score:.2f}")

        with output_path.open("w", encoding="utf-8") as f:
            f.write("\n".join(lines))

        logger.info("Summary exported to %s", output_path)
        return output_path
