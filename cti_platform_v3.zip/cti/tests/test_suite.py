"""
Pytest test suite for Clinical Trial Intelligence platform.
Covers: parsing, rule engine, entity extraction, QC engine, pipeline, export.
"""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path
from typing import List

import pytest

# Ensure src is importable
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.models.schema import (
    AnalysisOutput, ClinicalIntelligenceSchema, OutputClass, OutputType,
    Population, QCSeverity, RuleType
)
from src.parsers import parse_document, DocxParser, TextParser, ParsedDocument
from src.rule_engine import RuleEngine
from src.entity_extraction import (
    StudyMetadataExtractor, PopulationExtractor, EndpointExtractor,
    VisitScheduleExtractor, OutputExtractor
)
from src.mock_shell import MockShellParser
from src.qc_engine import QCEngine
from src.services import ExtractionPipeline, PipelineConfig
from src.export import ExportManager
from src.utils import (
    normalize_population, normalize_method, classify_output,
    infer_adam_datasets, extract_number_from_title, clean_text
)


# ===========================================================================
# Fixtures
# ===========================================================================

FIXTURES_DIR = Path(__file__).parent / "fixtures" / "mock_saps"


def get_fixture_paths() -> List[Path]:
    """Return available fixture paths."""
    paths = []
    for ext in ("*.docx", "*.txt", "*.rtf"):
        paths.extend(FIXTURES_DIR.glob(ext))
    return sorted(paths)


@pytest.fixture(scope="session")
def fixture_paths() -> List[Path]:
    """Generate fixtures if not present."""
    if not FIXTURES_DIR.exists():
        FIXTURES_DIR.mkdir(parents=True, exist_ok=True)

    paths = get_fixture_paths()
    if not paths:
        # Generate text fallbacks
        from tests.fixtures.mock_saps.generate_fixtures import generate_all_fixtures
        generate_all_fixtures(FIXTURES_DIR)
        paths = get_fixture_paths()
    return paths


@pytest.fixture(scope="session")
def primary_sap(fixture_paths) -> Path:
    """Return the first available SAP fixture."""
    if not fixture_paths:
        pytest.skip("No fixture files available")
    return fixture_paths[0]


@pytest.fixture(scope="session")
def parsed_primary(primary_sap) -> ParsedDocument:
    """Parse the primary SAP fixture once per session."""
    return parse_document(primary_sap)


@pytest.fixture(scope="session")
def full_schema(primary_sap) -> ClinicalIntelligenceSchema:
    """Run full pipeline on primary SAP fixture."""
    config = PipelineConfig(run_qc=True, run_mock_shell=True)
    pipeline = ExtractionPipeline(config=config)
    return pipeline.run([primary_sap])


@pytest.fixture()
def minimal_schema() -> ClinicalIntelligenceSchema:
    """Build a minimal schema for QC testing."""
    schema = ClinicalIntelligenceSchema()
    schema.study_metadata.protocol_id = "TEST-001"
    schema.study_metadata.study_title = "Test Trial"
    schema.study_metadata.phase = "3"

    pop_itt = Population(
        population_id="pop_itt",
        label="Intent-to-Treat",
        abbreviation="ITT",
        hierarchy_order=1,
        formal_definition="All randomized subjects who received at least one dose.",
        adam_flag_variable="ITTFL",
        confidence=0.95,
    )
    pop_saf = Population(
        population_id="pop_saf",
        label="Safety",
        abbreviation="SAF",
        hierarchy_order=2,
        adam_flag_variable="SAFFL",
        confidence=0.90,
    )
    schema.populations = [pop_itt, pop_saf]

    output = AnalysisOutput(
        output_id="out_t14_1_1",
        output_type=OutputType.TABLE,
        output_class=OutputClass.EFFICACY,
        output_number="14.1.1",
        title="Primary Efficacy Analysis at Week 12",
        population=pop_itt,
        confidence_score=0.94,
    )
    schema.outputs_master = [output]
    return schema


# ===========================================================================
# 1. Parser tests
# ===========================================================================

class TestParsers:
    def test_parse_document_returns_parsed_document(self, primary_sap):
        doc = parse_document(primary_sap)
        assert doc is not None
        assert doc.file_name == primary_sap.name
        assert doc.full_text  # not empty

    def test_parse_document_has_sections(self, parsed_primary):
        assert len(parsed_primary.sections) > 0

    def test_parse_document_sections_have_titles(self, parsed_primary):
        titled = [s for s in parsed_primary.sections if s.title.strip()]
        assert len(titled) > 0

    def test_parse_document_full_text_is_string(self, parsed_primary):
        assert isinstance(parsed_primary.full_text, str)
        assert len(parsed_primary.full_text) > 100

    def test_text_parser_handles_plain_text(self):
        with tempfile.NamedTemporaryFile(suffix=".txt", mode="w", delete=False, encoding="utf-8") as f:
            f.write("""Statistical Analysis Plan
Protocol Number: TST-999
NCT Number: NCT12345678

1. Endpoints
The primary efficacy endpoint is change from baseline in Score at Week 12.

2. Populations
The Intent-to-Treat (ITT) population includes all randomized subjects. ITTFL = 'Y'.

3. Outputs
Table 14.1.1: Primary Efficacy Analysis (ITT Population)
Table 14.2.1: Safety Summary (Safety Population)
""")
            tmp_path = Path(f.name)
        try:
            doc = parse_document(tmp_path)
            assert doc.full_text
            assert len(doc.sections) > 0
        finally:
            tmp_path.unlink(missing_ok=True)

    def test_parse_unknown_extension_falls_back(self):
        with tempfile.NamedTemporaryFile(suffix=".txt", mode="w", delete=False, encoding="utf-8") as f:
            f.write("Protocol: FALLBACK-001\nITT population: all randomized subjects.")
            tmp_path = Path(f.name)
        try:
            doc = parse_document(tmp_path)
            assert doc is not None
        finally:
            tmp_path.unlink(missing_ok=True)

    def test_parser_handles_missing_file_gracefully(self):
        from src.parsers import DocxParser
        bad_path = Path("/nonexistent/path/file.docx")
        # Should not raise; should return empty document
        result = DocxParser._empty_document(bad_path)
        assert result is not None
        assert result.file_name == "file.docx"


# ===========================================================================
# 2. Utility tests
# ===========================================================================

class TestUtils:
    @pytest.mark.parametrize("text,expected_abbrev", [
        ("Intent-to-Treat population", "ITT"),
        ("ITT population will be used", "ITT"),
        ("Full Analysis Set", "FAS"),
        ("Per Protocol population", "PP"),
        ("Safety population", "SAF"),
    ])
    def test_normalize_population(self, text, expected_abbrev):
        result = normalize_population(text)
        assert result is not None
        _, abbrev, _ = result
        assert abbrev == expected_abbrev

    @pytest.mark.parametrize("text,expected_method", [
        ("Analysis of covariance (ANCOVA)", "ANCOVA"),
        ("ANCOVA model", "ANCOVA"),
        ("Mixed Model for Repeated Measures (MMRM)", "MMRM"),
        ("Kaplan-Meier method", "Kaplan-Meier"),
        ("Cox proportional hazards model", "Cox Proportional Hazards"),
        ("logistic regression analysis", "Logistic Regression"),
    ])
    def test_normalize_method(self, text, expected_method):
        result = normalize_method(text)
        assert result == expected_method

    @pytest.mark.parametrize("title,expected_class", [
        ("Primary Efficacy Analysis at Week 12", "Efficacy"),
        ("Treatment-Emergent Adverse Events Summary", "Safety"),
        ("Demographic Characteristics at Baseline", "Demographics"),
        ("Pharmacokinetic Parameter Summary", "PK"),
    ])
    def test_classify_output(self, title, expected_class):
        result = classify_output(title)
        assert result == expected_class

    @pytest.mark.parametrize("title,expected_ds", [
        ("Adverse Event Summary by SOC", ["ADAE"]),
        ("Laboratory Parameter Changes", ["ADLB"]),
        ("Progression-Free Survival", ["ADTTE"]),
        ("Pharmacokinetic Parameters", ["ADPK"]),
        ("Efficacy Analysis Primary Endpoint Score", ["ADEFF"]),
    ])
    def test_infer_adam_datasets(self, title, expected_ds):
        result = infer_adam_datasets(title)
        for ds in expected_ds:
            assert ds in result

    @pytest.mark.parametrize("title,expected_num", [
        ("Table 14.1.1 Primary Efficacy", "14.1.1"),
        ("Listing 16.2.1 All Adverse Events", "16.2.1"),
        ("Figure 14.1.1 Kaplan-Meier", "14.1.1"),
    ])
    def test_extract_number_from_title(self, title, expected_num):
        result = extract_number_from_title(title)
        assert result == expected_num

    def test_clean_text_removes_extra_whitespace(self):
        dirty = "  This   has  extra   whitespace  \n  and newlines  "
        result = clean_text(dirty)
        assert "  " not in result
        assert result == "This has extra whitespace and newlines"


# ===========================================================================
# 3. Rule engine tests
# ===========================================================================

class TestRuleEngine:
    @pytest.fixture()
    def engine(self):
        return RuleEngine(confidence_threshold=0.50)

    def test_extract_baseline_rule(self, engine, parsed_primary):
        rules = engine.extract_all(parsed_primary)
        baseline_rules = [r for r in rules if r.rule_type == RuleType.BASELINE_DEFINITION]
        assert len(baseline_rules) > 0, "Baseline rule should be extracted from SAP"

    def test_extract_filter_rule(self, engine, parsed_primary):
        rules = engine.extract_all(parsed_primary)
        filter_rules = [r for r in rules if r.rule_type == RuleType.FILTER]
        assert len(filter_rules) > 0, "Filter rules (ITTFL etc.) should be extracted"

    def test_extract_derivation_rule(self, engine, parsed_primary):
        rules = engine.extract_all(parsed_primary)
        deriv_rules = [r for r in rules if r.rule_type == RuleType.DERIVATION]
        assert len(deriv_rules) > 0, "CHG = AVAL - BASE should be extracted"

    def test_rules_have_confidence(self, engine, parsed_primary):
        rules = engine.extract_all(parsed_primary)
        assert all(0.0 <= r.confidence <= 1.0 for r in rules)

    def test_rules_have_source_section(self, engine, parsed_primary):
        rules = engine.extract_all(parsed_primary)
        assert all(r.source_section is not None for r in rules)

    def test_date_imputation_extraction(self, engine):
        text_with_date_rules = """
        For partial start dates where only year and month are known (YYYY-MM format),
        the day will be imputed as 01 (first of the month). The imputation flag ASTDTF = 'D'.
        For partial end dates, the day will be imputed as the last day of the month.
        """
        from src.parsers import ParsedParagraph, ParsedSection, ParsedDocument
        para = ParsedParagraph("p_0", text_with_date_rules, "Normal", 0, 1, 0)
        section = ParsedSection("sec_0", "Date Rules", 1, None, 1, [para])
        section.full_text = text_with_date_rules
        doc = ParsedDocument("test.txt", "txt", 0, [para], [], [section], text_with_date_rules)
        rules = engine.extract_all(doc)
        date_rules = [r for r in rules if r.rule_type == RuleType.DATE_IMPUTATION]
        assert len(date_rules) > 0

    def test_censoring_rules_extraction(self, engine):
        text_with_censoring = """
        Event observed: CNSR = 0.
        Subjects who withdrew consent will be censored (CNSR = 1, ADT = last known alive date).
        Lost to follow-up censoring: CNSR = 1.
        Administrative censoring at data cutoff: CNSR = 1.
        """
        from src.parsers import ParsedParagraph, ParsedSection, ParsedDocument
        para = ParsedParagraph("p_0", text_with_censoring, "Normal", 0, 1, 0)
        section = ParsedSection("sec_0", "Censoring", 1, None, 1, [para])
        section.full_text = text_with_censoring
        doc = ParsedDocument("test.txt", "txt", 0, [para], [], [section], text_with_censoring)
        rules = engine.extract_all(doc)
        censor_rules = [r for r in rules if r.rule_type == RuleType.CENSORING]
        assert len(censor_rules) > 0

    def test_deduplication(self, engine, parsed_primary):
        rules = engine.extract_all(parsed_primary)
        rule_texts = [r.rule_text_verbatim[:80].lower() for r in rules]
        assert len(rule_texts) == len(set(rule_texts)), "Duplicate rules should be removed"


# ===========================================================================
# 4. Entity extraction tests
# ===========================================================================

class TestEntityExtraction:
    def test_population_extractor_finds_itt(self, parsed_primary):
        pops = PopulationExtractor().extract(parsed_primary)
        abbrevs = [p.abbreviation for p in pops]
        assert "ITT" in abbrevs or "FAS" in abbrevs

    def test_population_extractor_finds_safety(self, parsed_primary):
        pops = PopulationExtractor().extract(parsed_primary)
        abbrevs = [p.abbreviation for p in pops]
        assert "SAF" in abbrevs

    def test_populations_have_flag_variables(self, parsed_primary):
        pops = PopulationExtractor().extract(parsed_primary)
        for pop in pops:
            assert pop.adam_flag_variable, f"Population {pop.abbreviation} missing flag variable"

    def test_population_confidence_in_range(self, parsed_primary):
        pops = PopulationExtractor().extract(parsed_primary)
        for pop in pops:
            assert 0.0 <= pop.confidence <= 1.0

    def test_endpoint_extractor_finds_primary(self, parsed_primary):
        endpoints = EndpointExtractor().extract(parsed_primary)
        from src.models.schema import EndpointClassification
        primary_eps = [e for e in endpoints if e.classification == EndpointClassification.PRIMARY]
        assert len(primary_eps) >= 1

    def test_endpoint_extractor_finds_safety_endpoints(self, parsed_primary):
        endpoints = EndpointExtractor().extract(parsed_primary)
        from src.models.schema import EndpointClassification
        safety_eps = [e for e in endpoints if e.classification == EndpointClassification.SAFETY]
        assert len(safety_eps) >= 1

    def test_visit_extractor_produces_visits(self, parsed_primary):
        visits = VisitScheduleExtractor().extract(parsed_primary)
        assert len(visits) > 0

    def test_visits_have_adam_values(self, parsed_primary):
        visits = VisitScheduleExtractor().extract(parsed_primary)
        visits_with_adam = [v for v in visits if v.adam_visit_value]
        assert len(visits_with_adam) > 0

    def test_output_extractor_finds_tables(self, parsed_primary):
        pops = PopulationExtractor().extract(parsed_primary)
        endpoints = EndpointExtractor().extract(parsed_primary)
        outputs = OutputExtractor().extract(parsed_primary, pops, endpoints)
        tables = [o for o in outputs if o.output_type == OutputType.TABLE]
        assert len(tables) >= 3

    def test_output_numbers_are_unique(self, parsed_primary):
        pops = PopulationExtractor().extract(parsed_primary)
        endpoints = EndpointExtractor().extract(parsed_primary)
        outputs = OutputExtractor().extract(parsed_primary, pops, endpoints)
        numbers = [o.output_number for o in outputs if o.output_number]
        assert len(numbers) == len(set(numbers)), "Output numbers must be unique"

    def test_study_metadata_extracts_protocol_id(self, parsed_primary):
        meta = StudyMetadataExtractor().extract(parsed_primary)
        assert meta.protocol_id is not None

    def test_study_metadata_extracts_nct(self, parsed_primary):
        meta = StudyMetadataExtractor().extract(parsed_primary)
        assert meta.nct_number is not None
        assert meta.nct_number.startswith("NCT")


# ===========================================================================
# 5. Mock shell tests
# ===========================================================================

class TestMockShell:
    def test_mock_shell_parser_handles_empty_table(self):
        from src.parsers import ParsedTable
        table = ParsedTable("tbl_empty", 1, 0, rows=[])
        parser = MockShellParser()
        result = parser.parse_for_output(table, "tbl_empty")
        assert result is None

    def test_mock_shell_parser_parses_valid_table(self):
        from src.parsers import ParsedTable
        table = ParsedTable("tbl_001", 10, 5, rows=[
            ["Parameter", "Placebo (N=XXX)", "Active (N=XXX)", "Difference (95% CI)", "p-value"],
            ["N (analyzed)", "xxx", "xxx", "", ""],
            ["Baseline Mean (SD)", "xx.x (x.x)", "xx.x (x.x)", "", ""],
            ["LS Mean (SE)", "xx.x (x.x)", "xx.x (x.x)", "", ""],
            ["Difference", "", "", "xx.x (xx.x, xx.x)", "x.xxxx"],
            ["a ANCOVA model with treatment as factor.", "", "", "", ""],
        ])
        parser = MockShellParser()
        shell = parser.parse_for_output(table, "tbl_001_shell")
        assert shell is not None
        assert len(shell.columns) >= 4
        assert len(shell.rows) >= 2
        assert shell.parse_confidence > 0.3

    def test_mock_shell_detects_footnotes(self):
        from src.parsers import ParsedTable
        table = ParsedTable("tbl_fn", 5, 0, rows=[
            ["Parameter", "Treatment", "Control"],
            ["Score", "xx", "xx"],
            ["a ANCOVA model applied.", "", ""],
            ["b ITT population.", "", ""],
        ])
        parser = MockShellParser()
        shell = parser.parse_for_output(table, "tbl_fn")
        assert shell is not None
        assert len(shell.footnotes) > 0


# ===========================================================================
# 6. QC engine tests
# ===========================================================================

class TestQCEngine:
    def test_qc_runs_without_error(self, minimal_schema):
        engine = QCEngine()
        report = engine.run(minimal_schema)
        assert report is not None
        assert report.total_outputs == 1

    def test_qc_detects_missing_protocol_id(self):
        schema = ClinicalIntelligenceSchema()
        # No protocol ID set
        engine = QCEngine()
        report = engine.run(schema)
        error_messages = [i.message for i in report.issues if i.severity == QCSeverity.ERROR]
        assert any("Protocol ID" in m for m in error_messages)

    def test_qc_detects_missing_populations(self):
        schema = ClinicalIntelligenceSchema()
        schema.study_metadata.protocol_id = "TEST-001"
        engine = QCEngine()
        report = engine.run(schema)
        error_categories = [i.category for i in report.issues if i.severity == QCSeverity.ERROR]
        assert "Populations" in error_categories

    def test_qc_detects_duplicate_output_ids(self):
        from src.models.schema import Population
        schema = ClinicalIntelligenceSchema()
        schema.study_metadata.protocol_id = "TEST-002"
        pop = Population(population_id="pop_itt", label="ITT", abbreviation="ITT",
                         hierarchy_order=1, adam_flag_variable="ITTFL", confidence=0.9)
        schema.populations = [pop]
        output1 = AnalysisOutput(output_id="DUPE_ID", output_number="14.1.1",
                                 title="Table 1", population=pop, confidence_score=0.9)
        output2 = AnalysisOutput(output_id="DUPE_ID", output_number="14.1.2",
                                 title="Table 2", population=pop, confidence_score=0.9)
        schema.outputs_master = [output1, output2]
        engine = QCEngine()
        report = engine.run(schema)
        dup_issues = [i for i in report.issues if "Duplicate" in i.category and "output_id" in i.message.lower()]
        assert len(dup_issues) > 0

    def test_qc_readiness_score_is_between_0_and_1(self, full_schema):
        assert full_schema.qc_report is not None
        score = full_schema.qc_report.overall_readiness_score
        assert 0.0 <= score <= 1.0

    def test_qc_low_confidence_outputs_flagged(self):
        schema = ClinicalIntelligenceSchema()
        schema.study_metadata.protocol_id = "TEST-003"
        from src.models.schema import Population
        pop = Population(population_id="pop_itt", label="ITT", abbreviation="ITT",
                         hierarchy_order=1, adam_flag_variable="ITTFL", confidence=0.9)
        schema.populations = [pop]
        low_conf = AnalysisOutput(
            output_id="low_conf_out",
            output_number="14.9.1",
            title="Low Confidence Table",
            population=pop,
            confidence_score=0.30,  # very low
        )
        schema.outputs_master = [low_conf]
        report = QCEngine(confidence_threshold=0.70).run(schema)
        conf_issues = [i for i in report.issues if i.severity == QCSeverity.ERROR and "confidence" in i.message.lower()]
        assert len(conf_issues) > 0

    def test_qc_completeness_calculation(self, minimal_schema):
        report = QCEngine().run(minimal_schema)
        # Output has population but no analysis — completeness should be <100%
        assert report.completeness_pct < 100.0


# ===========================================================================
# 7. End-to-end pipeline tests
# ===========================================================================

class TestPipeline:
    def test_pipeline_returns_schema(self, primary_sap):
        config = PipelineConfig(run_qc=True)
        pipeline = ExtractionPipeline(config=config)
        schema = pipeline.run([primary_sap])
        assert isinstance(schema, ClinicalIntelligenceSchema)

    def test_pipeline_extracts_populations(self, full_schema):
        assert len(full_schema.populations) > 0

    def test_pipeline_extracts_outputs(self, full_schema):
        assert len(full_schema.outputs_master) > 0

    def test_pipeline_extracts_rules(self, full_schema):
        assert len(full_schema.rule_engine_output) > 0

    def test_pipeline_runs_qc(self, full_schema):
        assert full_schema.qc_report is not None

    def test_pipeline_handles_missing_file(self):
        config = PipelineConfig(run_qc=False)
        pipeline = ExtractionPipeline(config=config)
        result = pipeline.run([Path("/nonexistent/file.docx")])
        assert isinstance(result, ClinicalIntelligenceSchema)

    def test_pipeline_processes_all_fixtures(self, fixture_paths):
        config = PipelineConfig(run_qc=True)
        pipeline = ExtractionPipeline(config=config)
        for path in fixture_paths[:3]:  # test first 3 for speed
            schema = pipeline.run([path])
            assert isinstance(schema, ClinicalIntelligenceSchema)
            assert len(schema.outputs_master) > 0

    def test_pipeline_output_ids_are_unique(self, full_schema):
        output_ids = [o.output_id for o in full_schema.outputs_master]
        assert len(output_ids) == len(set(output_ids))

    def test_pipeline_system_metadata_populated(self, full_schema):
        assert full_schema.system_metadata.parsing_job_id
        assert full_schema.system_metadata.execution_time_ms is not None
        assert full_schema.system_metadata.execution_time_ms > 0


# ===========================================================================
# 8. Export tests
# ===========================================================================

class TestExport:
    def test_export_json(self, full_schema):
        with tempfile.TemporaryDirectory() as tmpdir:
            exporter = ExportManager(Path(tmpdir))
            path = exporter.export_json(full_schema, "test_export.json")
            assert path.exists()
            assert path.stat().st_size > 0
            with path.open() as f:
                data = json.load(f)
            assert "study_metadata" in data
            assert "outputs_master" in data

    def test_export_sas_metadata(self, full_schema):
        with tempfile.TemporaryDirectory() as tmpdir:
            exporter = ExportManager(Path(tmpdir))
            path = exporter.export_sas_metadata(full_schema, "test_sas.json")
            assert path.exists()
            with path.open() as f:
                data = json.load(f)
            assert "outputs" in data
            assert "programming_rules" in data

    def test_export_summary_txt(self, full_schema):
        with tempfile.TemporaryDirectory() as tmpdir:
            exporter = ExportManager(Path(tmpdir))
            path = exporter.export_summary_txt(full_schema)
            assert path.exists()
            content = path.read_text()
            assert "EXTRACTION SUMMARY" in content

    def test_export_excel(self, full_schema):
        try:
            import openpyxl
        except ImportError:
            pytest.skip("openpyxl not installed")
        with tempfile.TemporaryDirectory() as tmpdir:
            exporter = ExportManager(Path(tmpdir))
            path = exporter.export_excel(full_schema, "test_export.xlsx")
            assert path.exists()
            wb = openpyxl.load_workbook(str(path))
            sheet_names = wb.sheetnames
            assert "Study Summary" in sheet_names
            assert "Outputs Master" in sheet_names
            assert "QC Issues" in sheet_names


# ===========================================================================
# 9. DataQCBridge tests
# ===========================================================================

class TestDataQCBridge:
    def test_bridge_runs_without_data(self, full_schema):
        from src.services.data_qc_bridge import DataQCBridge
        bridge = DataQCBridge()
        result = bridge.validate(full_schema)
        assert result is not None
        assert isinstance(result.issues, list)

    def test_bridge_profiles_csv_datasets(self, full_schema):
        from src.services.data_qc_bridge import DataQCBridge
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create mock CSV datasets
            adsl = Path(tmpdir) / "ADSL.csv"
            adsl.write_text("USUBJID,TRT01P,ITTFL,SAFFL,PPROTFL,AGE,SEX\nSUBJ001,Active,Y,Y,Y,45,M\n")

            adae = Path(tmpdir) / "ADAE.csv"
            adae.write_text("USUBJID,AEDECOD,ASTDT,AENDT,AESER,AESEV\nSUBJ001,Headache,2026-01-01,2026-01-03,N,MILD\n")

            bridge = DataQCBridge()
            result = bridge.validate(full_schema, dataset_dir=Path(tmpdir))
            assert len(result.dataset_profiles) >= 2

    def test_bridge_detects_missing_population_flags(self, full_schema):
        from src.services.data_qc_bridge import DataQCBridge, DatasetProfile
        bridge = DataQCBridge()
        bridge._dataset_profiles = [
            DatasetProfile(
                dataset_name="ADSL",
                variables=["USUBJID", "TRT01P"],  # missing ITTFL, SAFFL intentionally
                n_records=100,
            )
        ]
        issues = bridge._check_population_flags(full_schema)
        # Should flag missing ITTFL / SAFFL
        assert len(issues) > 0


# ===========================================================================
# 10. Model tests
# ===========================================================================

class TestModels:
    def test_schema_serializes_to_json(self, minimal_schema):
        json_str = minimal_schema.model_dump_json()
        assert json_str
        data = json.loads(json_str)
        assert data["study_metadata"]["protocol_id"] == "TEST-001"

    def test_confidence_clamped_to_1(self):
        pop = Population(
            population_id="p1", label="ITT", abbreviation="ITT",
            hierarchy_order=1, confidence=1.5  # exceeds 1.0
        )
        assert pop.confidence == 1.0

    def test_confidence_clamped_to_0(self):
        pop = Population(
            population_id="p1", label="ITT", abbreviation="ITT",
            hierarchy_order=1, confidence=-0.5  # below 0.0
        )
        assert pop.confidence == 0.0

    def test_get_output_by_id(self, minimal_schema):
        output = minimal_schema.get_output_by_id("out_t14_1_1")
        assert output is not None
        assert output.output_number == "14.1.1"

    def test_get_output_by_id_missing(self, minimal_schema):
        output = minimal_schema.get_output_by_id("nonexistent_id")
        assert output is None

    def test_get_population_by_abbrev(self, minimal_schema):
        pop = minimal_schema.get_population_by_abbrev("ITT")
        assert pop is not None
        assert pop.abbreviation == "ITT"

    def test_to_summary_dict(self, full_schema):
        summary = full_schema.to_summary_dict()
        assert "total_outputs" in summary
        assert summary["total_outputs"] >= 0
