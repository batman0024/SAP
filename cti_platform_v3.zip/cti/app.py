"""
Clinical Trial Intelligence Platform v3 — Streamlit Dashboard
Handles 100–150 page SAP documents with speed and accuracy.
Uses st.cache_data for schema caching and progress updates.
"""
from __future__ import annotations

import hashlib
import json
import sys
import tempfile
import time
from pathlib import Path
from typing import List, Optional

import streamlit as st

sys.path.insert(0, str(Path(__file__).parent))

from src.models.schema import (
    ClinicalIntelligenceSchema, OutputClass, OutputType, QCSeverity,
)
from src.services import ExtractionPipeline, PipelineConfig
from src.export import ExportManager

# ── Page config ──────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="CTI Platform v3",
    page_icon="⬡",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── CSS ───────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600&family=IBM+Plex+Sans:wght@300;400;600;700&display=swap');
html,body,[class*="css"]{font-family:'IBM Plex Sans',sans-serif;}
.stApp{background:#0a0e1a;color:#e2e8f0;}
.main .block-container{padding:1.5rem 2rem;max-width:1400px;}
[data-testid="stSidebar"]{background:#0f172a;border-right:1px solid #1e293b;}
[data-testid="stMetricValue"]{color:#06b6d4;font-family:'IBM Plex Mono',monospace;font-size:2rem;}
[data-testid="stMetricLabel"]{color:#64748b;font-size:.75rem;text-transform:uppercase;letter-spacing:.05em;}
[data-testid="stMetric"]{background:#0f172a;border:1px solid #1e293b;border-radius:10px;padding:1rem;}
.stTabs [data-baseweb="tab-list"]{background:#0f172a;border-bottom:1px solid #1e293b;gap:0;}
.stTabs [data-baseweb="tab"]{color:#64748b;padding:.75rem 1.25rem;font-size:.85rem;}
.stTabs [aria-selected="true"]{color:#06b6d4;border-bottom:2px solid #06b6d4;}
.streamlit-expanderHeader{background:#0f172a;border:1px solid #1e293b;border-radius:8px;color:#e2e8f0;}
.stProgress>div>div{background:linear-gradient(90deg,#06b6d4,#6366f1);}
[data-testid="stFileUploaderDropzone"]{background:#0f172a;border:2px dashed #334155;border-radius:10px;}
.stButton>button{background:linear-gradient(135deg,#06b6d4,#6366f1);color:#fff;border:none;border-radius:8px;font-weight:600;}
.badge-error{background:#ef444422;color:#ef4444;border:1px solid #ef444433;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600;}
.badge-warning{background:#f59e0b22;color:#f59e0b;border:1px solid #f59e0b33;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600;}
.badge-info{background:#06b6d422;color:#06b6d4;border:1px solid #06b6d433;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600;}
.badge-ok{background:#10b98122;color:#10b981;border:1px solid #10b98133;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600;}
.sec-header{font-family:'IBM Plex Mono',monospace;font-size:.7rem;font-weight:600;color:#475569;text-transform:uppercase;letter-spacing:.1em;margin-bottom:.5rem;border-bottom:1px solid #1e293b;padding-bottom:4px;}
.stDataFrame{border:1px solid #1e293b;border-radius:8px;}
</style>
""", unsafe_allow_html=True)


# ── Session state ─────────────────────────────────────────────────────────────
def _init():
    defaults = {
        "schema": None,
        "error": None,
        "file_hash": None,
        "export_dir": Path("./exports"),
        "processing": False,
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

_init()


# ── Caching — avoid re-parsing the same file ──────────────────────────────────
@st.cache_data(show_spinner=False, max_entries=5)
def _cached_parse(file_bytes: bytes, filename: str, conf: float,
                  run_qc: bool, run_shell: bool) -> dict:
    """Cache by file content hash. Returns schema as JSON dict."""
    with tempfile.TemporaryDirectory() as tmp:
        p = Path(tmp) / filename
        p.write_bytes(file_bytes)
        config = PipelineConfig(
            confidence_threshold=conf,
            run_qc=run_qc,
            run_mock_shell=run_shell,
            parallel_extraction=True,
        )
        schema = ExtractionPipeline(config).run([p])
        return json.loads(schema.model_dump_json())


def _file_hash(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()[:16]


# ── UI helpers ────────────────────────────────────────────────────────────────
def _conf_badge(score: float) -> str:
    if score >= .90:
        return f'<span class="badge-ok">&#10003; {score:.0%}</span>'
    elif score >= .70:
        return f'<span class="badge-info">~ {score:.0%}</span>'
    elif score >= .50:
        return f'<span class="badge-warning">! {score:.0%}</span>'
    else:
        return f'<span class="badge-error">&#10007; {score:.0%}</span>'


def _readiness_color(s: float) -> str:
    return "#10b981" if s >= .80 else "#f59e0b" if s >= .60 else "#ef4444"


# ── Sidebar ───────────────────────────────────────────────────────────────────
def _sidebar():
    with st.sidebar:
        st.markdown("""
        <div style="display:flex;align-items:center;gap:10px;padding:1rem 0 .5rem;">
          <div style="width:32px;height:32px;background:linear-gradient(135deg,#6366f1,#06b6d4);
                      border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:18px;">&#x2B21;</div>
          <div>
            <div style="font-weight:700;font-size:13px;color:#f1f5f9;">CTI Platform v3</div>
            <div style="font-size:10px;color:#475569;">SAP Intelligence</div>
          </div>
        </div>""", unsafe_allow_html=True)

        st.markdown("---")
        st.markdown('<div class="sec-header">Upload Documents</div>', unsafe_allow_html=True)
        uploaded = st.file_uploader(
            "SAP / Shell / ADaM / SDTM",
            type=["docx", "rtf", "txt"],
            accept_multiple_files=True,
            label_visibility="collapsed",
            help="Upload SAP (required), shell, ADaM template, SDTM specs",
        )

        st.markdown('<div class="sec-header" style="margin-top:1rem;">Pipeline Options</div>', unsafe_allow_html=True)
        run_qc = st.checkbox("Run QC Engine", value=True)
        run_shells = st.checkbox("Parse Mock Shells", value=True)
        parallel = st.checkbox("Parallel Extraction", value=True,
                               help="Run entity extractors concurrently (faster for large SAPs)")
        conf = st.slider("Confidence Threshold", 0.50, 0.95, 0.70, 0.05, format="%.2f")

        st.markdown('<div class="sec-header" style="margin-top:1rem;">Export</div>', unsafe_allow_html=True)
        exp_json = st.checkbox("Export JSON", False)
        exp_xl = st.checkbox("Export Excel", False)
        exp_sas = st.checkbox("Export SAS Metadata", False)

        st.markdown("")
        run_btn = st.button("⬡ Run Extraction Pipeline",
                            use_container_width=True,
                            disabled=not bool(uploaded))
        demo_btn = st.button("⚡ Run Demo (Sample SAP)", use_container_width=True)

        schema = st.session_state.get("schema")
        if schema:
            st.markdown("---")
            meta = schema.get("study_metadata", {})
            qc = schema.get("qc_report", {})
            st.markdown(f"""
            <div style="font-size:11px;color:#94a3b8;line-height:1.9;">
              <b style="color:#f1f5f9;">{meta.get('protocol_id','N/A')}</b><br>
              Phase {meta.get('phase','?')} &nbsp;·&nbsp;
              {len(schema.get('outputs_master',[]))} outputs<br>
              {len(schema.get('populations',[]))} populations &nbsp;·&nbsp;
              {len(schema.get('endpoints',[]))} endpoints<br>
              {len(schema.get('rule_engine_output',[]))} rules &nbsp;·&nbsp;
              {len(schema.get('visit_schedule',[]))} visits
            </div>""", unsafe_allow_html=True)
            if qc:
                rs = qc.get("overall_readiness_score", 0)
                color = _readiness_color(rs)
                st.markdown(f"""
                <div style="margin-top:.75rem;padding:8px 12px;background:#0a0e1a;
                            border:1px solid #1e293b;border-left:3px solid {color};border-radius:0 6px 6px 0;">
                  <div style="font-size:10px;color:#64748b;text-transform:uppercase;">Readiness Score</div>
                  <div style="font-size:1.6rem;font-family:'IBM Plex Mono',monospace;color:{color};font-weight:700;">
                    {rs:.0%}
                  </div>
                </div>""", unsafe_allow_html=True)

            st.markdown("---")
            st.markdown('<div class="sec-header">Download</div>', unsafe_allow_html=True)
            st.download_button(
                "⬇ Download JSON",
                data=json.dumps(schema, indent=2, default=str),
                file_name=f"cti_{meta.get('protocol_id','schema')}.json",
                mime="application/json",
                use_container_width=True,
            )

        return uploaded, run_btn, demo_btn, run_qc, run_shells, conf, exp_json, exp_xl, exp_sas, parallel


# ── Pipeline runners ──────────────────────────────────────────────────────────
def _run_from_uploads(files, conf, run_qc, run_shells, parallel,
                      exp_json, exp_xl, exp_sas):
    # Use the first uploaded file's content as cache key
    primary_bytes = files[0].getvalue()
    key = _file_hash(primary_bytes)

    if st.session_state.get("file_hash") == key and st.session_state.get("schema"):
        st.info("Using cached result for this file. Re-upload to re-extract.")
        return

    progress = st.progress(0.0, text="Starting…")
    status = st.empty()

    def _cb(msg: str, pct: float) -> None:
        progress.progress(min(pct, 1.0), text=msg)
        status.markdown(f"<div style='font-size:12px;color:#64748b;'>{msg}</div>",
                        unsafe_allow_html=True)

    try:
        with tempfile.TemporaryDirectory() as tmp:
            paths = []
            for uf in files:
                dest = Path(tmp) / uf.name
                dest.write_bytes(uf.getvalue())
                paths.append(dest)

            config = PipelineConfig(
                confidence_threshold=conf,
                run_qc=run_qc,
                run_mock_shell=run_shells,
                parallel_extraction=parallel,
                export_json=exp_json,
                export_excel=exp_xl,
                export_sas=exp_sas,
                output_dir=st.session_state["export_dir"],
                progress_callback=_cb,
            )
            pipeline = ExtractionPipeline(config)
            schema_obj = pipeline.run(paths)
            schema_dict = json.loads(schema_obj.model_dump_json())

        st.session_state["schema"] = schema_dict
        st.session_state["file_hash"] = key
        st.session_state["error"] = None
        progress.progress(1.0, text="Complete")
        status.empty()
    except Exception as exc:
        st.session_state["error"] = str(exc)
        progress.empty()
        status.empty()


def _run_demo():
    from tests.fixtures.mock_saps.generate_fixtures import (
        create_sap_phase3_efficacy, _sap1_text,
    )
    with tempfile.TemporaryDirectory() as tmp:
        p = Path(tmp) / "demo_sap.docx"
        try:
            create_sap_phase3_efficacy(p)
        except Exception:
            p = p.with_suffix(".txt")
            p.write_text(_sap1_text(), encoding="utf-8")

        config = PipelineConfig(run_qc=True, run_mock_shell=True,
                                parallel_extraction=True)
        schema_obj = ExtractionPipeline(config).run([p])
        st.session_state["schema"] = json.loads(schema_obj.model_dump_json())
        st.session_state["file_hash"] = "demo"
        st.session_state["error"] = None


# ── Header ────────────────────────────────────────────────────────────────────
def _render_header(schema: Optional[dict]) -> None:
    if schema:
        meta = schema.get("study_metadata", {})
        sys_meta = schema.get("system_metadata", {})
        elapsed = sys_meta.get("execution_time_ms", 0)
        diagram_flag = meta.get("has_study_schema_diagram", False)
        st.markdown(f"""
        <div style="background:linear-gradient(135deg,#0f172a,#1e1b4b,#0f172a);
                    border:1px solid #1e293b;border-radius:12px;padding:1.25rem 1.5rem;margin-bottom:1.5rem;">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;">
            <div>
              <div style="font-size:1.1rem;font-weight:700;color:#f1f5f9;margin-bottom:4px;">
                {meta.get('study_title','Clinical Trial SAP Analysis')}
              </div>
              <div style="font-size:12px;color:#64748b;">
                Protocol: <span style="color:#94a3b8;">{meta.get('protocol_id','N/A')}</span>
                &nbsp;&middot;&nbsp; Phase: <span style="color:#94a3b8;">{meta.get('phase','?')}</span>
                &nbsp;&middot;&nbsp; NCT: <span style="color:#94a3b8;">{meta.get('nct_number','N/A')}</span>
                {' &nbsp;&middot;&nbsp; <span style="color:#8b5cf6;">&#128200; Study schema diagram detected</span>' if diagram_flag else ''}
              </div>
            </div>
            <div style="text-align:right;font-size:11px;color:#475569;">
              Extracted in {elapsed:,} ms
            </div>
          </div>
        </div>""", unsafe_allow_html=True)
    else:
        st.markdown("""
        <div style="background:linear-gradient(135deg,#0f172a,#1e1b4b,#0f172a);
                    border:1px solid #1e293b;border-radius:12px;padding:2rem;
                    text-align:center;margin-bottom:1.5rem;">
          <div style="font-size:2rem;margin-bottom:.5rem;">&#x2B21;</div>
          <div style="font-size:1.2rem;font-weight:700;color:#f1f5f9;margin-bottom:.5rem;">
            Clinical Trial Intelligence Platform v3
          </div>
          <div style="font-size:13px;color:#64748b;max-width:560px;margin:0 auto;">
            Upload a 100–150 page SAP document. Parallel extraction, hyperlinked TOC support,
            appendix detection, study schema diagram recognition, full QC and ADaM specification.
          </div>
        </div>""", unsafe_allow_html=True)


# ── Metrics bar ───────────────────────────────────────────────────────────────
def _render_metrics(schema: dict) -> None:
    qc = schema.get("qc_report") or {}
    cols = st.columns(8)
    metrics = [
        ("Outputs", len(schema.get("outputs_master", []))),
        ("Populations", len(schema.get("populations", []))),
        ("Endpoints", len(schema.get("endpoints", []))),
        ("Rules", len(schema.get("rule_engine_output", []))),
        ("Visits", len(schema.get("visit_schedule", []))),
        ("Sections", len(schema.get("sections", []))),
        ("QC Errors", qc.get("errors", 0)),
        ("Readiness", f"{qc.get('overall_readiness_score', 0):.0%}"),
    ]
    for col, (label, value) in zip(cols, metrics):
        with col:
            st.metric(label, value)


# ── Tab renderers ─────────────────────────────────────────────────────────────
def _tab_outputs(schema: dict) -> None:
    import pandas as pd
    outputs = schema.get("outputs_master", [])
    st.markdown('<div class="sec-header">Outputs Master (TLF Registry)</div>',
                unsafe_allow_html=True)

    # Filters
    fc1, fc2, fc3, fc4, fc5 = st.columns([2, 2, 2, 2, 2])
    with fc1:
        type_f = st.multiselect("Type", ["Table","Listing","Figure","Appendix"],
                                default=["Table","Listing","Figure","Appendix"])
    with fc2:
        classes = sorted({o.get("output_class","Other") for o in outputs})
        class_f = st.multiselect("Class", classes, default=classes)
    with fc3:
        pops = sorted({
            (o.get("population") or {}).get("abbreviation","?")
            for o in outputs if o.get("population")
        })
        pop_f = st.multiselect("Population", pops, default=pops)
    with fc4:
        conf_f = st.slider("Min Confidence", 0.0, 1.0, 0.0, 0.05, format="%.2f",
                           key="out_conf")
    with fc5:
        app_only = st.checkbox("Appendix outputs only", False)

    filtered = [
        o for o in outputs
        if o.get("output_type","Table") in type_f
        and o.get("output_class","Other") in class_f
        and (not pops or (o.get("population") or {}).get("abbreviation","?") in pop_f)
        and o.get("confidence_score", 0) >= conf_f
        and (not app_only or o.get("is_appendix_output", False))
    ]
    st.caption(f"Showing {len(filtered)} / {len(outputs)} outputs")

    for out in filtered:
        pop = (out.get("population") or {}).get("abbreviation", "?")
        methods = ", ".join((out.get("analysis") or {}).get("methods", [])) or "—"
        ds = ", ".join((out.get("data_specification") or {}).get("input_datasets", [])) or "—"
        icon = {"Table": "▦", "Listing": "≡", "Figure": "◈", "Appendix": "◇"}.get(
            out.get("output_type","Table"), "▦"
        )
        app_badge = (f' <span style="background:#8b5cf622;color:#8b5cf6;border:1px solid #8b5cf633;'
                     f'padding:1px 6px;border-radius:3px;font-size:10px;">Appendix '
                     f'{out.get("appendix_label","")}</span>') if out.get("is_appendix_output") else ""

        with st.expander(
            f"{icon} {out.get('output_number','?')} — {(out.get('title') or '')[:80]}",
            expanded=False
        ):
            c1, c2, c3 = st.columns([2, 2, 1])
            with c1:
                st.markdown(f"""
                <div style="font-size:11px;line-height:2.2;">
                  <b style="color:#94a3b8;">Type:</b> {out.get('output_type')} · {out.get('output_class')}{app_badge}<br>
                  <b style="color:#94a3b8;">Population:</b> {pop}<br>
                  <b style="color:#94a3b8;">Analysis:</b> {methods}<br>
                  <b style="color:#94a3b8;">Datasets:</b> {ds}
                </div>""", unsafe_allow_html=True)
            with c2:
                rules = out.get("programming_rules", [])
                if rules:
                    st.markdown('<div style="font-size:11px;color:#64748b;margin-bottom:4px;">Programming Rules</div>',
                                unsafe_allow_html=True)
                    for rule in rules[:3]:
                        st.markdown(f"""
                        <div style="font-family:'IBM Plex Mono',monospace;font-size:10px;
                                    background:#0a0e1a;padding:4px 8px;border-radius:4px;
                                    border-left:2px solid #f97316;margin-bottom:3px;color:#94a3b8;">
                          {rule.get('rule','')}
                        </div>""", unsafe_allow_html=True)
            with c3:
                st.markdown(_conf_badge(out.get("confidence_score", 0)),
                            unsafe_allow_html=True)
                tr = out.get("traceability") or {}
                if tr.get("page_number"):
                    st.markdown(f'<div style="font-size:10px;color:#475569;margin-top:4px;">'
                                f'Page {tr["page_number"]}</div>', unsafe_allow_html=True)

            shell = out.get("mock_shell")
            if shell and shell.get("columns"):
                st.markdown('<div style="font-size:11px;color:#64748b;margin-top:.5rem;">Mock Shell</div>',
                            unsafe_allow_html=True)
                shell_df = pd.DataFrame({
                    "Pos": [c["position"] for c in shell["columns"]],
                    "Header": [c["header"] for c in shell["columns"]],
                    "Type": [c.get("data_type","") for c in shell["columns"]],
                    "Format": [c.get("format_mask","") for c in shell["columns"]],
                })
                st.dataframe(shell_df, use_container_width=True, hide_index=True)
                for fn in (shell.get("footnotes") or []):
                    st.markdown(f'<div style="font-size:10px;color:#475569;font-style:italic;">{fn}</div>',
                                unsafe_allow_html=True)


def _tab_structure(schema: dict) -> None:
    """Table of Contents / section hierarchy view — new in v3."""
    sections = schema.get("sections", [])
    st.markdown('<div class="sec-header">Document Structure & TOC</div>',
                unsafe_allow_html=True)

    meta = schema.get("study_metadata", {})
    if meta.get("has_study_schema_diagram"):
        st.markdown("""
        <div style="background:#8b5cf615;border:1px solid #8b5cf633;border-radius:8px;
                    padding:.75rem 1rem;margin-bottom:1rem;font-size:13px;color:#c4b5fd;">
          &#128200; Study schema diagram detected in this SAP document
        </div>""", unsafe_allow_html=True)

    if not sections:
        st.info("No sections extracted.")
        return

    # Separate appendices
    main_secs = [s for s in sections if not s.get("is_appendix")]
    app_secs = [s for s in sections if s.get("is_appendix")]

    st.markdown(f"**{len(main_secs)} main sections** · **{len(app_secs)} appendix sections**")

    import pandas as pd
    df = pd.DataFrame([{
        "Section ID": s["section_id"],
        "Level": s["level"],
        "Title": s["title"][:90],
        "Page": s.get("page_start",""),
        "Appendix": ("✓ " + (s.get("appendix_label") or "")) if s.get("is_appendix") else "",
        "Parent": s.get("parent_id",""),
    } for s in sections])
    st.dataframe(df, use_container_width=True, hide_index=True, height=500)

    toc = schema.get("toc_map", {})
    xref = schema.get("cross_refs", {})
    if toc or xref:
        with st.expander(f"TOC Map ({len(toc)} entries) · Cross-refs ({len(xref)} entries)"):
            if toc:
                st.markdown("**Bookmark → Section ID**")
                st.dataframe(pd.DataFrame(
                    [{"Bookmark": k, "Section ID": v} for k, v in list(toc.items())[:30]]
                ), use_container_width=True, hide_index=True)
            if xref:
                st.markdown("**Number Prefix → Section ID**")
                st.dataframe(pd.DataFrame(
                    [{"Number": k, "Section ID": v} for k, v in list(xref.items())[:30]]
                ), use_container_width=True, hide_index=True)


def _tab_populations(schema: dict) -> None:
    for pop in schema.get("populations", []):
        with st.expander(f"👥 {pop.get('abbreviation')} — {pop.get('label')}", False):
            c1, c2 = st.columns([3, 1])
            with c1:
                st.markdown(f"""
                <div style="font-size:12px;line-height:2.2;">
                  <b style="color:#94a3b8;">ADaM Flag:</b>
                  <code style="background:#0a0e1a;padding:2px 6px;border-radius:3px;color:#06b6d4;">
                    {pop.get('adam_flag_variable','N/A')} = 'Y'
                  </code><br>
                  <b style="color:#94a3b8;">Dataset:</b> {pop.get('adam_dataset','ADSL')}<br>
                  <b style="color:#94a3b8;">Derivation:</b>
                  <code style="background:#0a0e1a;padding:2px 6px;border-radius:3px;color:#10b981;font-size:11px;">
                    {pop.get('derivation_rule','N/A')}
                  </code>
                </div>""", unsafe_allow_html=True)
                defn = pop.get("formal_definition","")
                if defn:
                    st.markdown(f"""
                    <div style="background:#0a0e1a;border:1px solid #1e293b;border-left:3px solid #ec4899;
                                border-radius:0 6px 6px 0;padding:8px 12px;margin-top:8px;
                                font-size:11px;color:#94a3b8;font-style:italic;">{defn}</div>""",
                                unsafe_allow_html=True)
            with c2:
                st.markdown(_conf_badge(pop.get("confidence", 0)), unsafe_allow_html=True)


def _tab_endpoints(schema: dict) -> None:
    from collections import Counter
    eps = schema.get("endpoints", [])
    cls_counts = Counter(e.get("classification","Secondary") for e in eps)
    if cls_counts:
        cols = st.columns(len(cls_counts))
        colors = {"Primary":"#ec4899","Key Secondary":"#f97316","Secondary":"#06b6d4",
                  "Exploratory":"#8b5cf6","Safety":"#ef4444","PK":"#f59e0b","PD":"#10b981"}
        for (cls, cnt), col in zip(cls_counts.items(), cols):
            color = colors.get(cls, "#94a3b8")
            with col:
                st.markdown(f"""
                <div style="background:#0f172a;border:1px solid #1e293b;border-top:3px solid {color};
                            border-radius:8px;padding:12px;text-align:center;margin-bottom:1rem;">
                  <div style="font-size:1.5rem;font-family:'IBM Plex Mono',monospace;color:{color};font-weight:700;">{cnt}</div>
                  <div style="font-size:10px;color:#64748b;text-transform:uppercase;">{cls}</div>
                </div>""", unsafe_allow_html=True)

    for ep in eps:
        cls_color = {"Primary":"#ec4899","Key Secondary":"#f97316","Secondary":"#06b6d4",
                     "Exploratory":"#8b5cf6","Safety":"#ef4444"}.get(ep.get("classification","Secondary"),"#94a3b8")
        with st.expander(f"🎯 [{ep.get('classification')}] {ep.get('description','')[:80]}", False):
            c1, c2 = st.columns([3, 1])
            with c1:
                st.markdown(f"""
                <div style="font-size:12px;line-height:2.2;">
                  <b style="color:#94a3b8;">Timepoints:</b> {', '.join(ep.get('timepoints',[]) or ['N/A'])}<br>
                  <b style="color:#94a3b8;">ADaM Variables:</b>
                  <code style="background:#0a0e1a;padding:2px 6px;border-radius:3px;color:#06b6d4;font-size:11px;">
                    {', '.join(ep.get('adam_variables',[]) or ['N/A'])}
                  </code>
                </div>""", unsafe_allow_html=True)
                if ep.get("estimand"):
                    st.markdown("""
                    <div style="margin-top:.5rem;padding:6px 10px;background:#0a0e1a;
                                border:1px solid #1e293b;border-left:3px solid #8b5cf6;
                                border-radius:0 6px 6px 0;font-size:11px;color:#8b5cf6;">
                      ICH E9(R1) estimand defined</div>""", unsafe_allow_html=True)
            with c2:
                st.markdown(_conf_badge(ep.get("confidence", 0)), unsafe_allow_html=True)


def _tab_rules(schema: dict) -> None:
    rules = schema.get("rule_engine_output", [])
    rule_colors = {
        "baseline_definition":"#8b5cf6","date_imputation":"#f97316",
        "visit_window":"#f59e0b","filter":"#06b6d4","derivation":"#10b981",
        "flag":"#6366f1","censoring":"#ef4444","LOCF":"#ec4899","BOCF":"#ec4899",
        "imputation":"#f97316","pk_rule":"#f59e0b","pd_rule":"#10b981",
    }
    available = sorted({r.get("rule_type","") for r in rules})
    sel = st.multiselect("Filter by Rule Type", available, default=available,
                         key="rule_type_filter")
    filtered = [r for r in rules if r.get("rule_type","") in sel]
    st.caption(f"{len(filtered)} rules")
    for rule in filtered:
        color = rule_colors.get(rule.get("rule_type",""), "#94a3b8")
        verbatim = (rule.get("rule_text_verbatim") or "")[:70]
        with st.expander(f"[{rule.get('rule_type')}] {verbatim}…", False):
            c1, c2 = st.columns([3, 1])
            with c1:
                st.markdown(f'<div style="font-size:11px;color:#94a3b8;margin-bottom:8px;font-style:italic;">'
                            f'{rule.get("rule_text_verbatim","")}</div>', unsafe_allow_html=True)
                if rule.get("pseudocode"):
                    st.code(rule["pseudocode"], language="sas")
                vars_str = ", ".join(rule.get("applies_to_variables",[]) or []) or "N/A"
                ds_str = ", ".join(rule.get("applies_to_datasets",[]) or []) or "N/A"
                st.markdown(f'<div style="font-size:10px;color:#64748b;margin-top:8px;">'
                            f'Variables: <span style="color:{color};">{vars_str}</span> &nbsp;&middot;&nbsp; '
                            f'Datasets: <span style="color:#94a3b8;">{ds_str}</span></div>',
                            unsafe_allow_html=True)
            with c2:
                st.markdown(_conf_badge(rule.get("confidence", 0)), unsafe_allow_html=True)
                if rule.get("source_page"):
                    st.markdown(f'<div style="font-size:10px;color:#475569;margin-top:4px;">'
                                f'Page {rule["source_page"]}</div>', unsafe_allow_html=True)


def _tab_visits(schema: dict) -> None:
    import pandas as pd
    visits = schema.get("visit_schedule", [])
    if not visits:
        st.info("No visit schedule extracted.")
        return
    rows = [{
        "Visit ID": v.get("visit_id",""),
        "Label": v.get("visit_label",""),
        "Type": v.get("visit_type",""),
        "Nominal Day": v.get("nominal_day","—"),
        "Pre (days)": f'-{v["window_pre_days"]}' if v.get("window_pre_days") else "—",
        "Post (days)": f'+{v["window_post_days"]}' if v.get("window_post_days") else "—",
        "AVISIT": v.get("adam_visit_value","—"),
        "AVISITN": v.get("adam_visitnum","—"),
        "Analysis": "✓" if v.get("analysis_visit_flag") else "",
        "Primary": "⭐" if v.get("primary_timepoint") else "",
        "Conf": f'{v.get("confidence",0):.2f}',
    } for v in visits]
    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)


def _tab_qc(schema: dict) -> None:
    import pandas as pd
    qc = schema.get("qc_report")
    if not qc:
        st.warning("QC report not available. Re-run with QC enabled.")
        return

    rs = qc.get("overall_readiness_score", 0)
    color = _readiness_color(rs)
    c1, c2, c3, c4, c5 = st.columns(5)
    with c1:
        st.markdown(f"""
        <div style="background:#0f172a;border:1px solid #1e293b;border-top:3px solid {color};
                    border-radius:8px;padding:12px;text-align:center;">
          <div style="font-size:1.8rem;font-family:'IBM Plex Mono',monospace;color:{color};font-weight:700;">
            {rs:.0%}</div>
          <div style="font-size:10px;color:#64748b;text-transform:uppercase;">Readiness</div>
        </div>""", unsafe_allow_html=True)
    with c2: st.metric("Completeness", f"{qc.get('completeness_pct',0):.0f}%")
    with c3: st.metric("Errors", qc.get("errors", 0))
    with c4: st.metric("Warnings", qc.get("warnings", 0))
    with c5: st.metric("Low Confidence", qc.get("low_confidence_count", 0))

    st.markdown("")
    issues = qc.get("issues", [])
    if issues:
        sev_f = st.multiselect("Severity", ["ERROR","WARNING","INFO"],
                               default=["ERROR","WARNING"], key="qc_sev")
        rows = [{
            "Severity": i.get("severity",""),
            "Category": i.get("category",""),
            "Output": i.get("output_id","—"),
            "Message": i.get("message",""),
            "Fix": i.get("suggested_fix",""),
        } for i in issues if i.get("severity","") in sev_f]
        if rows:
            st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
        else:
            st.success("No issues at selected severity.")
    else:
        st.success("✓ No QC issues found.")


def _tab_adam(schema: dict) -> None:
    from collections import defaultdict
    ds_map: dict = defaultdict(lambda: {"outputs": [], "variables": set(), "populations": set()})
    for out in schema.get("outputs_master", []):
        ds_spec = out.get("data_specification") or {}
        pop = (out.get("population") or {}).get("abbreviation","")
        for ds in (ds_spec.get("input_datasets") or []):
            ds_map[ds]["outputs"].append(out.get("output_number") or out.get("output_id",""))
            for vlist in (ds_spec.get("key_variables") or {}).values():
                ds_map[ds]["variables"].update(vlist)
            if pop:
                ds_map[ds]["populations"].add(pop)

    icons = {"ADSL":"👤","ADAE":"⚠","ADLB":"🧪","ADEFF":"🎯","ADTTE":"⏱",
             "ADPK":"💊","ADVS":"❤","ADQS":"📋","ADCM":"💉","ADEX":"📊"}
    for ds_name, info in sorted(ds_map.items()):
        icon = icons.get(ds_name, "🗃")
        with st.expander(f"{icon} {ds_name} — {len(info['outputs'])} outputs", False):
            c1, c2 = st.columns([2, 1])
            with c1:
                if info["variables"]:
                    var_html = " ".join(
                        f'<span style="background:#06b6d415;color:#06b6d4;border:1px solid #06b6d433;'
                        f'padding:2px 6px;border-radius:4px;font-size:10px;'
                        f'font-family:monospace;margin:2px;display:inline-block;">{v}</span>'
                        for v in sorted(info["variables"])
                    )
                    st.markdown(var_html, unsafe_allow_html=True)
            with c2:
                st.markdown(f"""
                <div style="font-size:11px;line-height:2;">
                  <b style="color:#94a3b8;">Populations:</b> {', '.join(sorted(info['populations'])) or 'N/A'}<br>
                  <b style="color:#94a3b8;">Referenced by:</b> {len(info['outputs'])} outputs
                </div>""", unsafe_allow_html=True)


# ── Main ──────────────────────────────────────────────────────────────────────
def main() -> None:
    (uploaded, run_btn, demo_btn, run_qc, run_shells, conf,
     exp_json, exp_xl, exp_sas, parallel) = _sidebar()

    # Trigger extraction
    if run_btn and uploaded:
        _run_from_uploads(uploaded, conf, run_qc, run_shells, parallel,
                          exp_json, exp_xl, exp_sas)
        st.rerun()

    if demo_btn:
        with st.spinner("Running demo pipeline…"):
            try:
                _run_demo()
            except Exception as exc:
                st.session_state["error"] = str(exc)
        st.rerun()

    if st.session_state.get("error"):
        st.error(f"Pipeline error: {st.session_state['error']}")

    schema = st.session_state.get("schema")
    _render_header(schema)

    if schema is None:
        # Landing feature grid
        features = [
            ("📄","Large SAP Support","100–150 page DOCX/RTF — O(n) parsing, XML streaming for >4 MB"),
            ("🔗","Hyperlinked TOC","Bookmark targets resolved to section IDs, cross-reference map built"),
            ("📑","Appendix Detection","Appendix A/B/C sections identified, outputs tagged accordingly"),
            ("📊","Study Schema Diagrams","Embedded drawings/diagrams flagged and labelled in output"),
            ("🔇","Comment Stripping","Review comment boxes and tracked changes removed before extraction"),
            ("⚡","Parallel Extraction","4 entity extractors run concurrently — 2–4× faster on large SAPs"),
            ("✓","Full QC Engine","40+ checks: completeness, consistency, confidence, cross-references"),
            ("⬇","Export","JSON, Excel (8 sheets), SAS metadata, TXT summary"),
        ]
        cols = st.columns(4)
        for i, (icon, title, desc) in enumerate(features):
            with cols[i % 4]:
                st.markdown(f"""
                <div style="background:#0f172a;border:1px solid #1e293b;border-radius:10px;
                            padding:1rem;margin-bottom:1rem;min-height:130px;">
                  <div style="font-size:1.5rem;margin-bottom:.4rem;">{icon}</div>
                  <div style="font-size:12px;font-weight:700;color:#f1f5f9;margin-bottom:.3rem;">{title}</div>
                  <div style="font-size:11px;color:#64748b;">{desc}</div>
                </div>""", unsafe_allow_html=True)
        return

    _render_metrics(schema)
    st.markdown("")

    tabs = st.tabs(["📊 Outputs", "📑 Structure & TOC", "👥 Populations",
                    "🎯 Endpoints", "⚡ Rules", "📅 Visits",
                    "✓ QC Report", "🗃 ADaM Spec"])
    with tabs[0]: _tab_outputs(schema)
    with tabs[1]: _tab_structure(schema)
    with tabs[2]: _tab_populations(schema)
    with tabs[3]: _tab_endpoints(schema)
    with tabs[4]: _tab_rules(schema)
    with tabs[5]: _tab_visits(schema)
    with tabs[6]: _tab_qc(schema)
    with tabs[7]: _tab_adam(schema)


if __name__ == "__main__":
    main()
