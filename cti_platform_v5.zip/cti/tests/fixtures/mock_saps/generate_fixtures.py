"""
Generate realistic mock SAP DOCX documents for testing.
Creates 5 diverse mock SAPs covering different trial types.
"""
from __future__ import annotations

from pathlib import Path
from typing import List, Optional

try:
    import docx
    from docx import Document
    from docx.shared import Pt, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    HAS_DOCX = True
except ImportError:
    HAS_DOCX = False


def _add_heading(doc, text: str, level: int = 1) -> None:
    doc.add_heading(text, level=level)


def _add_paragraph(doc, text: str) -> None:
    doc.add_paragraph(text)


def _add_table(doc, headers: List[str], rows: List[List[str]]) -> None:
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    hdr_cells = table.rows[0].cells
    for i, h in enumerate(headers):
        hdr_cells[i].text = h
    for row_data in rows:
        row_cells = table.add_row().cells
        for i, cell_val in enumerate(row_data):
            if i < len(row_cells):
                row_cells[i].text = cell_val


def create_sap_phase3_efficacy(output_path: Path) -> Path:
    """SAP 1: Phase 3 placebo-controlled efficacy trial."""
    if not HAS_DOCX:
        return _create_text_fallback(output_path, _sap1_text())

    doc = Document()
    doc.add_heading("Statistical Analysis Plan", 0)
    doc.add_heading("A Phase 3, Randomized, Double-Blind, Placebo-Controlled Trial of\nDrug ABC-123 in Patients with Moderate-to-Severe Disease Y", 1)

    _add_paragraph(doc, "Protocol Number: ABC-123-PHASE3")
    _add_paragraph(doc, "NCT Number: NCT01234567")
    _add_paragraph(doc, "EudraCT Number: 2023-001234-56")
    _add_paragraph(doc, "Sponsor: Pharma Innovations Inc.")
    _add_paragraph(doc, "Version: 3.0 | Date: 2026-03-15")

    _add_heading(doc, "1. Introduction", 1)
    _add_paragraph(doc, "This Statistical Analysis Plan (SAP) describes the statistical methodology for a Phase 3, Randomized, Double-Blind, Placebo-Controlled Trial.")

    _add_heading(doc, "2. Study Objectives and Endpoints", 1)
    _add_heading(doc, "2.1 Primary Endpoint", 2)
    _add_paragraph(doc, "The primary efficacy endpoint is change from baseline in Disease Y Symptom Score (DYSS) at Week 12. The primary endpoint will be analyzed using ANCOVA with treatment as factor and baseline score as covariate.")

    _add_heading(doc, "2.2 Key Secondary Endpoints", 2)
    _add_paragraph(doc, "Key secondary endpoints include: (1) Proportion of responders (>=50% reduction from baseline in DYSS) at Week 12; (2) Change from baseline in Patient Global Impression of Change (PGI-C) at Week 12; (3) Change from baseline in DYSS at Week 4 and Week 8.")

    _add_heading(doc, "2.3 Safety Endpoints", 2)
    _add_paragraph(doc, "Safety endpoints include: incidence of treatment-emergent adverse events (TEAEs), serious adverse events (SAEs), adverse events leading to discontinuation, and laboratory abnormalities.")

    _add_heading(doc, "3. Analysis Populations", 1)
    _add_paragraph(doc, "The Intent-to-Treat (ITT) population is defined as all randomized subjects who received at least one dose of study drug. All subjects in the ITT population will be analyzed as randomized regardless of protocol deviations. The ITT population flag variable is ITTFL = 'Y' in ADSL.")
    _add_paragraph(doc, "The Per Protocol (PP) population is defined as all subjects in the ITT population without major protocol deviations that could impact the primary efficacy assessment. The PP population flag variable is PPROTFL = 'Y' in ADSL.")
    _add_paragraph(doc, "The Safety population is defined as all randomized subjects who received at least one dose of study drug. The Safety population flag variable is SAFFL = 'Y' in ADSL.")

    _add_heading(doc, "4. Visit Schedule and Windows", 1)
    _add_table(doc,
        ["Visit", "Nominal Day", "Window"],
        [
            ["Screening", "-14", "Day -21 to Day -1"],
            ["Day 1 (Baseline)", "1", "Day 1 only"],
            ["Week 4", "29", "Day 22 to Day 35"],
            ["Week 8", "57", "Day 50 to Day 64"],
            ["Week 12 (Primary)", "85", "Day 78 to Day 92"],
            ["Follow-up (Week 16)", "113", "Day 106 to Day 120"],
        ]
    )
    _add_paragraph(doc, "For visits with multiple records within the analysis window, the record closest to the nominal visit date will be used. If two records are equidistant from the nominal date, the later record will be used.")

    _add_heading(doc, "5. Statistical Methods", 1)
    _add_heading(doc, "5.1 Primary Analysis", 2)
    _add_paragraph(doc, "The primary analysis will use Analysis of Covariance (ANCOVA) with treatment as a fixed factor and baseline DYSS score as a covariate, stratified by region and baseline severity. The analysis will be performed on the ITT population using observed cases only (no imputation). Treatment effect estimate with 95% CI and p-value will be reported.")

    _add_heading(doc, "5.2 Missing Data Handling", 2)
    _add_paragraph(doc, "For the primary analysis, no imputation will be performed; observed cases only. Sensitivity analyses will include: (1) Mixed Model for Repeated Measures (MMRM) using all available data under Missing at Random (MAR) assumption; (2) Multiple imputation (MI) with 1000 imputations under MAR; (3) Tipping point analysis for MNAR departures.")

    _add_heading(doc, "5.3 Multiplicity", 2)
    _add_paragraph(doc, "A hierarchical testing procedure (Hochberg procedure) will be used to control the familywise Type I error rate at 0.05 (two-sided). The primary endpoint will be tested first at alpha = 0.05. Key secondary endpoints will be tested sequentially.")

    _add_heading(doc, "6. Baseline Definition", 1)
    _add_paragraph(doc, "Baseline is defined as the last non-missing assessment prior to or on the date of first dose of study drug. The baseline flag variable is ABLFL = 'Y'. Change from baseline is calculated as CHG = AVAL - BASE. Percent change from baseline is calculated as PCHG = 100 * (AVAL - BASE) / BASE when BASE is non-zero.")

    _add_heading(doc, "7. Date Imputation Rules", 1)
    _add_paragraph(doc, "For partial start dates where only year and month are known (YYYY-MM format), the day will be imputed as 01 (first of the month). The imputation flag ASTDTF = 'D' will be set.")
    _add_paragraph(doc, "For partial end dates where only year and month are known, the day will be imputed as the last day of the month. The imputation flag AENDTF = 'D' will be set.")
    _add_paragraph(doc, "For year-only dates (YYYY format), both month and day will be imputed as 01-01 (January 1st). ASTDTF = 'MD' will be set.")

    _add_heading(doc, "8. Analysis Outputs", 1)
    _add_heading(doc, "8.1 Efficacy Tables", 2)

    # Table 14.1.1
    _add_paragraph(doc, "Table 14.1.1: Primary Efficacy Analysis: Change from Baseline in DYSS at Week 12 (ITT Population)")
    _add_table(doc,
        ["Parameter", "Placebo (N=XXX)", "ABC-123 10mg (N=XXX)", "Difference (95% CI)", "p-value"],
        [
            ["N (analyzed)", "xxx", "xxx", "", ""],
            ["Baseline Mean (SD)", "xx.x (x.x)", "xx.x (x.x)", "", ""],
            ["Week 12 LS Mean (SE)", "xx.x (x.x)", "xx.x (x.x)", "", ""],
            ["Difference (95% CI)", "", "", "xx.x (xx.x, xx.x)", "x.xxxx"],
        ]
    )
    _add_paragraph(doc, "a ANCOVA model with treatment as factor and baseline score as covariate.")
    _add_paragraph(doc, "b p-value from ANCOVA model; ITTFL = 'Y'; ANL01FL = 'Y'.")

    _add_paragraph(doc, "Table 14.1.2: Sensitivity Analysis: MMRM (ITT Population)")
    _add_paragraph(doc, "Table 14.1.3: Responder Analysis at Week 12 (ITT Population)")
    _add_paragraph(doc, "Table 14.2.1: Secondary Endpoint - PGI-C at Week 12 (ITT Population)")

    _add_heading(doc, "8.2 Safety Tables", 2)
    _add_paragraph(doc, "Table 14.3.1: Summary of Treatment-Emergent Adverse Events (Safety Population)")
    _add_paragraph(doc, "Table 14.3.2: Adverse Events by System Organ Class and Preferred Term (Safety Population)")
    _add_paragraph(doc, "Table 14.4.1: Laboratory Parameter Changes from Baseline (Safety Population)")
    _add_paragraph(doc, "Listing 16.2.1: All Adverse Events (Safety Population)")
    _add_paragraph(doc, "Figure 14.1.1: Time Profile of Mean DYSS Score Over Time (ITT Population)")

    _add_heading(doc, "9. Programming Rules", 1)
    _add_paragraph(doc, "Analysis flag ANL01FL = 'Y' will be set for records where ITTFL = 'Y' and AVISITN IN (4, 8, 12) and DTYPE = '' (not an imputed record).")
    _add_paragraph(doc, "Worst-case flag WORS01FL = 'Y' will be set for the maximum toxicity grade per subject per preferred term.")
    _add_paragraph(doc, "Treatment-emergent flag TRTEMFL = 'Y' for adverse events with onset date on or after first dose date.")
    _add_paragraph(doc, "Censoring rules for time-to-event analyses: Event observed (CNSR = 0); Withdrew consent (CNSR = 1, ADT = last known alive date); Lost to follow-up (CNSR = 1, ADT = last contact date); Administrative censoring at data cutoff (CNSR = 1, ADT = data cutoff date).")

    doc.save(str(output_path))
    return output_path


def create_sap_oncology_tte(output_path: Path) -> Path:
    """SAP 2: Oncology Phase 2 time-to-event study."""
    if not HAS_DOCX:
        return _create_text_fallback(output_path, _sap2_text())

    doc = Document()
    doc.add_heading("Statistical Analysis Plan", 0)
    doc.add_heading("Phase 2 Open-Label Study of Oncology Drug XYZ-456 in Advanced Solid Tumors", 1)
    _add_paragraph(doc, "Protocol Number: XYZ-456-ONC-P2")
    _add_paragraph(doc, "NCT Number: NCT09876543")
    _add_paragraph(doc, "Sponsor: Oncology Research Corp.")

    _add_heading(doc, "1. Primary Endpoint", 1)
    _add_paragraph(doc, "The primary efficacy endpoint is Progression-Free Survival (PFS), defined as the time from first dose to the first documentation of objective disease progression (per RECIST 1.1) or death from any cause, whichever occurs first.")

    _add_heading(doc, "2. Analysis Populations", 1)
    _add_paragraph(doc, "The Full Analysis Set (FAS) is defined as all subjects who received at least one dose of study drug. The FAS flag variable is FASFL = 'Y' in ADSL.")
    _add_paragraph(doc, "The Safety population includes all subjects who received any amount of study drug (SAFFL = 'Y').")
    _add_paragraph(doc, "The Biomarker Evaluable population includes all FAS subjects with a valid baseline biomarker assessment (BMEFL = 'Y').")

    _add_heading(doc, "3. Time-to-Event Analysis", 1)
    _add_paragraph(doc, "PFS will be analyzed using Kaplan-Meier methods. Median PFS with 95% CI (Brookmeyer-Crowley) will be reported. Censoring rules: subjects without a PFS event at the time of analysis will be censored at the date of last adequate tumor assessment. Subjects who withdrew consent will be censored at the date of consent withdrawal (CNSR = 1). Administrative censoring at data cutoff (CNSR = 1, ADT = data cutoff date).")
    _add_paragraph(doc, "Overall Survival (OS) is a secondary endpoint. ADTTE dataset will be used with PARAMCD = 'OS' for OS and PARAMCD = 'PFS' for PFS.")

    _add_heading(doc, "4. Censoring Rules", 1)
    _add_paragraph(doc, "For PFS: CNSR = 0 when disease progression or death is documented. CNSR = 1 for all other subjects (censored). The analysis variable AVAL = time in days from STARTDT to ADT.")
    _add_paragraph(doc, "Competing events (non-cancer death before progression) will be censored at the date of competing event in the primary analysis (CNSR = 1) and addressed in sensitivity analyses.")

    _add_heading(doc, "5. Analysis Outputs", 1)
    _add_paragraph(doc, "Table 14.1.1: Progression-Free Survival Analysis (FAS)")
    _add_paragraph(doc, "Table 14.1.2: Overall Survival Analysis (FAS)")
    _add_paragraph(doc, "Figure 14.1.1: Kaplan-Meier Curve for PFS (FAS)")
    _add_paragraph(doc, "Figure 14.1.2: Kaplan-Meier Curve for OS (FAS)")
    _add_paragraph(doc, "Table 14.2.1: Tumor Response Summary - ORR, CR, PR, SD, PD (FAS)")
    _add_paragraph(doc, "Table 14.3.1: TEAE Summary by Grade (Safety Population)")
    _add_paragraph(doc, "Listing 16.2.1: All Adverse Events Including Serious AEs")

    doc.save(str(output_path))
    return output_path


def create_sap_crossover(output_path: Path) -> Path:
    """SAP 3: Crossover PK/PD study."""
    if not HAS_DOCX:
        return _create_text_fallback(output_path, _sap3_text())

    doc = Document()
    doc.add_heading("Statistical Analysis Plan", 0)
    doc.add_heading("Phase 1 Crossover PK/PD Study of Drug PQR-789", 1)
    _add_paragraph(doc, "Protocol Number: PQR-789-PK-001")
    _add_paragraph(doc, "Sponsor: BioPharma Ltd.")

    _add_heading(doc, "1. Study Design", 1)
    _add_paragraph(doc, "This is a Phase 1, open-label, randomized, 2-period crossover study to assess the pharmacokinetics and pharmacodynamics of Drug PQR-789. Subjects will be randomized in a 1:1 ratio to one of two treatment sequences.")

    _add_heading(doc, "2. Endpoints", 1)
    _add_paragraph(doc, "Primary PK endpoint: Area Under the Curve from time 0 to last measurable concentration (AUClast). Secondary PK endpoints include: Cmax, Tmax, AUCinf, half-life (t1/2), CL/F, Vd/F.")
    _add_paragraph(doc, "PD endpoint: Change from baseline in biomarker BM-1 at Cmax.")

    _add_heading(doc, "3. Analysis Populations", 1)
    _add_paragraph(doc, "The PK population includes all randomized subjects with at least one evaluable PK profile. PK population flag: PKFL = 'Y' in ADSL.")
    _add_paragraph(doc, "The Safety population (SAFFL = 'Y') includes all subjects who received any study drug.")

    _add_heading(doc, "4. Statistical Methods", 1)
    _add_paragraph(doc, "PK parameters will be summarized descriptively. Geometric mean and geometric coefficient of variation will be reported for AUClast and Cmax. A linear mixed-effects model on log-transformed PK parameters will be used for comparative analysis with period, sequence, and treatment as fixed effects and subject nested within sequence as random effect.")

    _add_heading(doc, "5. Visit Windows", 1)
    _add_table(doc,
        ["Timepoint", "Nominal Time", "Window"],
        [
            ["Pre-dose", "0 h", "+/- 5 min"],
            ["0.5 h", "0.5 h", "+/- 2 min"],
            ["1 h", "1 h", "+/- 5 min"],
            ["2 h", "2 h", "+/- 5 min"],
            ["4 h", "4 h", "+/- 10 min"],
            ["8 h", "8 h", "+/- 15 min"],
            ["24 h", "24 h", "+/- 30 min"],
        ]
    )

    _add_heading(doc, "6. Outputs", 1)
    _add_paragraph(doc, "Table 14.1.1: PK Parameter Summary (PK Population)")
    _add_paragraph(doc, "Table 14.1.2: PK Statistical Comparison - Test vs Reference (PK Population)")
    _add_paragraph(doc, "Figure 14.1.1: Mean (+SD) Concentration-Time Profile (PK Population)")
    _add_paragraph(doc, "Table 14.2.1: PD Biomarker Summary (PK Population)")
    _add_paragraph(doc, "Table 14.3.1: Adverse Event Summary (Safety Population)")

    doc.save(str(output_path))
    return output_path


def create_sap_safety_extension(output_path: Path) -> Path:
    """SAP 4: Long-term safety extension study."""
    if not HAS_DOCX:
        return _create_text_fallback(output_path, _sap4_text())

    doc = Document()
    doc.add_heading("Statistical Analysis Plan", 0)
    doc.add_heading("Long-Term Safety Extension Study of Drug LMN-321", 1)
    _add_paragraph(doc, "Protocol Number: LMN-321-EXT-001")
    _add_paragraph(doc, "NCT Number: NCT05555555")
    _add_paragraph(doc, "Sponsor: Safety First Pharma")
    _add_paragraph(doc, "Study Phase: 3 Extension")

    _add_heading(doc, "1. Analysis Populations", 1)
    _add_paragraph(doc, "The Safety population is defined as all subjects who enrolled in the extension study and received at least one dose. SAFFL = 'Y' in ADSL.")
    _add_paragraph(doc, "The Evaluable population (EVALFL = 'Y') includes Safety population subjects with at least 6 months of treatment.")

    _add_heading(doc, "2. Safety Endpoints", 1)
    _add_paragraph(doc, "Primary safety endpoint: Incidence of treatment-emergent adverse events (TEAEs) over 24 months. Secondary safety endpoints: SAEs, AEs leading to discontinuation, clinical laboratory abnormalities (hematology, chemistry, urinalysis), vital sign changes, and Hy's Law evaluation.")

    _add_heading(doc, "3. Date Imputation", 1)
    _add_paragraph(doc, "Partial start dates with year and month only (YYYY-MM): day imputed as 01; ASTDTF = 'D'. Partial start dates with year only (YYYY): month and day imputed as 01-01; ASTDTF = 'MD'. Missing AE onset dates that are known to have started before study entry: ASTDT = study start date; ASTDTF = 'B'.")

    _add_heading(doc, "4. Visit Schedule", 1)
    _add_table(doc,
        ["Visit", "Month", "Window (Days)"],
        [
            ["Enrollment/Baseline", "0", "Day 1 only"],
            ["Month 3", "3", "+/- 14 days"],
            ["Month 6", "6", "+/- 14 days"],
            ["Month 12", "12", "+/- 14 days"],
            ["Month 18", "18", "+/- 14 days"],
            ["Month 24", "24", "+/- 14 days"],
            ["Early Termination", "NA", "As applicable"],
        ]
    )

    _add_heading(doc, "5. Analysis Outputs", 1)
    _add_paragraph(doc, "Table 14.1.1: Overall TEAE Summary (Safety Population)")
    _add_paragraph(doc, "Table 14.1.2: TEAEs by System Organ Class and Preferred Term (Safety Population)")
    _add_paragraph(doc, "Table 14.1.3: Treatment-Related TEAEs (Safety Population)")
    _add_paragraph(doc, "Table 14.1.4: Serious Adverse Events (Safety Population)")
    _add_paragraph(doc, "Table 14.1.5: AEs Leading to Discontinuation (Safety Population)")
    _add_paragraph(doc, "Table 14.2.1: Laboratory Parameter Shifts from Baseline (Safety Population)")
    _add_paragraph(doc, "Table 14.2.2: Hy's Law Evaluation (Safety Population)")
    _add_paragraph(doc, "Table 14.3.1: Vital Signs Summary (Safety Population)")
    _add_paragraph(doc, "Listing 16.1.1: All Serious Adverse Events")
    _add_paragraph(doc, "Listing 16.1.2: Deaths")

    doc.save(str(output_path))
    return output_path


def create_sap_adaptive(output_path: Path) -> Path:
    """SAP 5: Adaptive design study with subgroup analyses."""
    if not HAS_DOCX:
        return _create_text_fallback(output_path, _sap5_text())

    doc = Document()
    doc.add_heading("Statistical Analysis Plan", 0)
    doc.add_heading("Phase 2/3 Adaptive Seamless Study of Drug RST-654", 1)
    _add_paragraph(doc, "Protocol Number: RST-654-ADAPT-001")
    _add_paragraph(doc, "NCT Number: NCT07777777")
    _add_paragraph(doc, "Sponsor: Adaptive Therapeutics Inc.")
    _add_paragraph(doc, "Study Phase: 2/3")

    _add_heading(doc, "1. Adaptive Design Overview", 1)
    _add_paragraph(doc, "This is a Phase 2/3 adaptive seamless design. An interim analysis will be conducted after 50% of subjects complete Week 12. Based on interim results, the study may: (1) continue as planned; (2) drop an arm; or (3) stop early for efficacy or futility. The interim analysis will be reviewed by an independent Data Monitoring Committee (DMC).")
    _add_paragraph(doc, "Alpha spending function: O'Brien-Fleming. Overall one-sided alpha = 0.025. Interim alpha = 0.001; Final alpha allocated accordingly.")

    _add_heading(doc, "2. Analysis Populations", 1)
    _add_paragraph(doc, "The modified Intent-to-Treat (mITT) population includes all randomized subjects who received at least one dose and have at least one post-baseline efficacy assessment. mITT flag variable is MITTFL = 'Y' in ADSL.")
    _add_paragraph(doc, "The Full Analysis Set (FAS) is equivalent to ITT — all randomized subjects regardless of protocol deviations. FASFL = 'Y' in ADSL.")

    _add_heading(doc, "3. Subgroup Analyses", 1)
    _add_paragraph(doc, "Pre-specified subgroup analyses will be performed for: (1) Age group (<65, >=65 years); (2) Sex (Male/Female); (3) Region (North America, Europe, Asia-Pacific); (4) Baseline severity (Mild/Moderate/Severe); (5) Biomarker status (Positive/Negative).")

    _add_heading(doc, "4. Multiple Comparisons", 1)
    _add_paragraph(doc, "A graphical multiplicity procedure will be used. Primary endpoint tested at alpha = 0.025 (one-sided). Key secondary endpoints tested sequentially using the Hochberg procedure within the hierarchical testing framework.")

    _add_heading(doc, "5. BOCF Sensitivity Analysis", 1)
    _add_paragraph(doc, "A Baseline Observation Carried Forward (BOCF) analysis will be performed as a worst-case sensitivity analysis for subjects who discontinued before Week 12. For the BOCF analysis, DTYPE = 'BOCF' and AVAL = BASE will be set for missing Week 12 values.")

    _add_heading(doc, "6. Analysis Outputs", 1)
    _add_paragraph(doc, "Table 14.1.1: Primary Efficacy Analysis at Week 12 (mITT Population)")
    _add_paragraph(doc, "Table 14.1.2: Primary Efficacy - BOCF Sensitivity Analysis (mITT)")
    _add_paragraph(doc, "Table 14.1.3: Subgroup Analysis - Forest Plot Data (mITT)")
    _add_paragraph(doc, "Table 14.2.1: Interim Analysis Results (DMC Report)")
    _add_paragraph(doc, "Figure 14.1.1: Forest Plot - Primary Endpoint Subgroups")
    _add_paragraph(doc, "Figure 14.1.2: Adaptive Design Schema")
    _add_paragraph(doc, "Table 14.3.1: Adverse Events Summary (Safety Population)")
    _add_paragraph(doc, "Listing 16.2.1: Subjects Discontinued — Reason and Date")

    doc.save(str(output_path))
    return output_path


# ---------------------------------------------------------------------------
# Text fallbacks (when python-docx not available)
# ---------------------------------------------------------------------------

def _create_text_fallback(output_path: Path, content: str) -> Path:
    """Write as .txt if DOCX creation fails."""
    txt_path = output_path.with_suffix(".txt")
    txt_path.write_text(content, encoding="utf-8")
    return txt_path


def _sap1_text() -> str:
    return """Statistical Analysis Plan
A Phase 3, Randomized, Double-Blind, Placebo-Controlled Trial of Drug ABC-123
Protocol Number: ABC-123-PHASE3
NCT Number: NCT01234567
Sponsor: Pharma Innovations Inc.

1. Introduction
This Statistical Analysis Plan describes the statistical methodology for a Phase 3 trial.

2. Study Objectives and Endpoints
2.1 Primary Endpoint
The primary efficacy endpoint is change from baseline in Disease Y Symptom Score at Week 12.
Analysis method: ANCOVA with treatment as factor and baseline score as covariate.

2.2 Key Secondary Endpoints
Proportion of responders at Week 12; Change from baseline in PGI-C at Week 12.

2.3 Safety Endpoints
Incidence of TEAEs, SAEs, adverse events leading to discontinuation.

3. Analysis Populations
The Intent-to-Treat (ITT) population includes all randomized subjects who received at least one dose.
ITTFL = 'Y' in ADSL.
The Safety population includes all subjects who received study drug. SAFFL = 'Y' in ADSL.
The Per Protocol (PP) population includes subjects without major protocol deviations. PPROTFL = 'Y'.

4. Visit Schedule
Week 4 window: Day 22 to Day 35 (nominal Day 29).
Week 8 window: Day 50 to Day 64 (nominal Day 57).
Week 12 window: Day 78 to Day 92 (nominal Day 85).
Multiple records in window: use record closest to nominal date.

5. Baseline Definition
Baseline is defined as the last non-missing value prior to or on first dose date. ABLFL = 'Y'.
Change from baseline is calculated as CHG = AVAL - BASE.

6. Date Imputation
Partial start date (YYYY-MM): day imputed as 01; ASTDTF = 'D'.
Partial end date (YYYY-MM): day imputed as last day of month; AENDTF = 'D'.

7. Missing Data
Primary analysis: no imputation, observed cases only (ANCOVA).
Sensitivity: MMRM using all available data under MAR assumption.
Sensitivity: Multiple imputation with 1000 imputations.
LOCF sensitivity: last observation carried forward for dropouts.

8. Analysis Outputs
Table 14.1.1: Primary Efficacy Analysis at Week 12 (ITT Population)
Table 14.1.2: Sensitivity Analysis MMRM (ITT Population)
Table 14.1.3: Responder Analysis at Week 12 (ITT Population)
Table 14.2.1: Secondary Endpoint PGI-C at Week 12 (ITT Population)
Table 14.3.1: TEAE Summary (Safety Population)
Table 14.3.2: AEs by SOC and PT (Safety Population)
Table 14.4.1: Laboratory Changes (Safety Population)
Listing 16.2.1: All Adverse Events (Safety Population)
Figure 14.1.1: DYSS Score Over Time (ITT Population)

9. Programming Rules
ITTFL = 'Y' for ITT population subjects.
ANL01FL = 'Y' for ITTFL = 'Y' and AVISITN IN (4, 8, 12) and DTYPE = ''.
TRTEMFL = 'Y' for AEs with onset on or after first dose.
CNSR = 0 for event observed; CNSR = 1 for censored subjects.
Administrative censoring at data cutoff: CNSR = 1, ADT = data cutoff date.
Withdrew consent: CNSR = 1, ADT = last known alive date.
Lost to follow-up: CNSR = 1, ADT = last contact date.
"""


def _sap2_text() -> str:
    return """Statistical Analysis Plan
Phase 2 Open-Label Study XYZ-456 in Advanced Solid Tumors
Protocol Number: XYZ-456-ONC-P2
NCT Number: NCT09876543
Sponsor: Oncology Research Corp.

1. Primary Endpoint
Progression-Free Survival (PFS): time from first dose to disease progression or death.

2. Analysis Populations
Full Analysis Set (FAS): all subjects who received at least one dose. FASFL = 'Y'.
Safety population: SAFFL = 'Y'.
Biomarker Evaluable population: BMEFL = 'Y'.

3. Time-to-Event Analysis
PFS analyzed using Kaplan-Meier methods. Cox proportional hazards model.
Censoring rules: CNSR = 0 for events, CNSR = 1 for censored.
Administrative censoring at data cutoff: CNSR = 1.
Withdrew consent: CNSR = 1, ADT = last known alive date.

4. Analysis Outputs
Table 14.1.1: Progression-Free Survival Analysis (FAS)
Table 14.1.2: Overall Survival Analysis (FAS)
Figure 14.1.1: Kaplan-Meier Curve for PFS
Figure 14.1.2: Kaplan-Meier Curve for OS
Table 14.2.1: Tumor Response ORR CR PR (FAS)
Table 14.3.1: TEAE Summary by Grade (Safety Population)
Listing 16.2.1: All Adverse Events including SAEs
"""


def _sap3_text() -> str:
    return """Statistical Analysis Plan
Phase 1 Crossover PK Study PQR-789
Protocol Number: PQR-789-PK-001
Sponsor: BioPharma Ltd.

1. Endpoints
Primary PK: AUClast. Secondary PK: Cmax, Tmax, half-life.

2. Populations
PK population: PKFL = 'Y'. Safety: SAFFL = 'Y'.

3. Methods
Linear mixed-effects model on log-transformed parameters.

4. Outputs
Table 14.1.1: PK Parameter Summary (PK Population)
Table 14.1.2: PK Statistical Comparison (PK Population)
Figure 14.1.1: Concentration-Time Profile
Table 14.3.1: Adverse Event Summary (Safety Population)
"""


def _sap4_text() -> str:
    return """Statistical Analysis Plan
Long-Term Safety Extension Study LMN-321
Protocol Number: LMN-321-EXT-001
NCT Number: NCT05555555
Sponsor: Safety First Pharma

1. Populations
Safety population: SAFFL = 'Y'. Evaluable: EVALFL = 'Y'.

2. Date Imputation
Partial start dates (YYYY-MM): day imputed as 01; ASTDTF = 'D'.
Year-only dates: month day imputed as 01-01; ASTDTF = 'MD'.

3. Outputs
Table 14.1.1: TEAE Summary (Safety Population)
Table 14.1.2: TEAEs by SOC and PT
Table 14.1.4: Serious Adverse Events
Table 14.2.2: Hy's Law Evaluation
Table 14.3.1: Vital Signs Summary
Listing 16.1.1: All Serious Adverse Events
Listing 16.1.2: Deaths
"""


def _sap5_text() -> str:
    return """Statistical Analysis Plan
Phase 2/3 Adaptive Study RST-654
Protocol Number: RST-654-ADAPT-001
NCT Number: NCT07777777
Sponsor: Adaptive Therapeutics Inc.

1. Adaptive Design
Interim analysis after 50% complete Week 12.
Alpha spending: O'Brien-Fleming. Alpha = 0.025 one-sided.

2. Populations
mITT population: MITTFL = 'Y'. FAS: FASFL = 'Y'.

3. Missing Data
BOCF sensitivity: DTYPE = 'BOCF', AVAL = BASE for missing Week 12.
LOCF for secondary endpoints.

4. Outputs
Table 14.1.1: Primary Efficacy at Week 12 (mITT)
Table 14.1.2: Primary Efficacy BOCF Sensitivity
Table 14.1.3: Subgroup Analysis Forest Plot Data
Table 14.2.1: Interim Analysis Results (DMC Report)
Figure 14.1.1: Forest Plot Subgroups
Figure 14.1.2: Adaptive Design Schema
Table 14.3.1: Adverse Events (Safety Population)
Listing 16.2.1: Subjects Discontinued
"""


def generate_all_fixtures(fixture_dir: Path) -> List[Path]:
    """Generate all 5 mock SAP fixtures."""
    fixture_dir.mkdir(parents=True, exist_ok=True)
    creators = [
        (create_sap_phase3_efficacy, "sap_01_phase3_efficacy.docx"),
        (create_sap_oncology_tte, "sap_02_oncology_tte.docx"),
        (create_sap_crossover, "sap_03_crossover_pk.docx"),
        (create_sap_safety_extension, "sap_04_safety_extension.docx"),
        (create_sap_adaptive, "sap_05_adaptive_design.docx"),
    ]
    generated = []
    for creator_fn, filename in creators:
        path = fixture_dir / filename
        try:
            result_path = creator_fn(path)
            generated.append(result_path)
            print(f"  Created: {result_path.name}")
        except Exception as exc:
            print(f"  WARNING: Could not create {filename}: {exc}")
            # Create text fallback
            txt_path = fixture_dir / filename.replace(".docx", ".txt")
            txt_path.write_text(f"Mock SAP: {filename}\n\nProtocol: TEST-001\n", encoding="utf-8")
            generated.append(txt_path)
    return generated


if __name__ == "__main__":
    fixtures_dir = Path(__file__).parent
    print("Generating mock SAP fixtures...")
    paths = generate_all_fixtures(fixtures_dir)
    print(f"Generated {len(paths)} fixtures")
