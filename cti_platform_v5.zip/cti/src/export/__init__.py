"""CTI v4 Export Manager — JSON, Excel (multi-sheet), HTML report, SAS metadata."""
from __future__ import annotations
import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional
from src.models.schema import ClinicalIntelligenceSchema, AnalysisOutput
from src.utils import get_logger
logger = get_logger(__name__)


class ExportManager:
    def __init__(self, output_dir: Path) -> None:
        self.output_dir = output_dir
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def export_json(self, schema: ClinicalIntelligenceSchema,
                    filename: Optional[str] = None) -> Path:
        if not filename:
            ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
            proto = schema.study_metadata.protocol_id or "UNKNOWN"
            filename = f"cti_{proto}_{ts}.json"
        path = self.output_dir / filename
        with path.open("w", encoding="utf-8") as f:
            f.write(schema.model_dump_json(indent=2))
        logger.info("JSON: %s", path)
        return path

    def export_excel(self, schema: ClinicalIntelligenceSchema,
                     filename: Optional[str] = None) -> Path:
        try:
            import openpyxl
            from openpyxl.styles import Font, PatternFill, Alignment
        except ImportError:
            raise ImportError("openpyxl required")
        if not filename:
            ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
            filename = f"cti_{schema.study_metadata.protocol_id or 'schema'}_{ts}.xlsx"
        path = self.output_dir / filename
        wb = openpyxl.Workbook(); wb.remove(wb.active)
        hf = Font(bold=True, color="FFFFFF")
        hfill = PatternFill(start_color="1F3864", end_color="1F3864", fill_type="solid")
        center = Alignment(horizontal="center", vertical="center", wrap_text=True)

        def ws(name, headers, rows):
            sheet = wb.create_sheet(name)
            sheet.append(headers)
            for cell in sheet[1]:
                cell.font = hf; cell.fill = hfill; cell.alignment = center
            for row in rows:
                sheet.append([str(v) if v is not None else "" for v in row])
            for col in sheet.columns:
                w = max((len(str(cell.value or "")) for cell in col), default=8)
                sheet.column_dimensions[col[0].column_letter].width = min(w+2, 55)
            return sheet

        # Sheet 1: Study Summary
        meta = schema.study_metadata
        ws("Study Summary", ["Field", "Value"], [
            ["Protocol ID", meta.protocol_id or ""],
            ["Study Title", meta.study_title or ""],
            ["Sponsor", meta.sponsor or ""],
            ["Phase", meta.phase or ""],
            ["SAP Version", meta.sap_version or ""],
            ["SAP Date", meta.sap_date or ""],
            ["Amendment", meta.amendment_number or ""],
            ["NCT Number", meta.nct_number or ""],
            ["EudraCT", meta.eudract_number or ""],
            ["Blinding", meta.blinding or ""],
            ["Randomization Ratio", meta.randomization_ratio or ""],
            ["Total Outputs", len(schema.outputs_master)],
            ["Total Populations", len(schema.populations)],
            ["Total Endpoints", len(schema.endpoints)],
            ["Total Rules", len(schema.rule_engine_output)],
            ["Tracked Changes Stripped", schema.tracked_changes_stripped],
            ["Inline ADaM Annotations", schema.inline_annotations_count],
        ])

        # Sheet 2: Outputs
        ws("Outputs Master",
           ["Output ID","Type","Class","Number","Title","Population","Methods","Datasets","ADaM Annotations","Confidence","Page"],
           [[o.output_id, o.output_type.value, o.output_class.value, o.output_number or "",
             o.title or "", (o.population.abbreviation if o.population else ""),
             ", ".join(o.analysis.methods if o.analysis else []),
             ", ".join(o.data_specification.input_datasets if o.data_specification else []),
             "; ".join((o.data_specification.adam_annotations[:3] if o.data_specification else [])),
             f"{o.confidence_score:.2f}",
             o.traceability.page_number if o.traceability else ""]
            for o in schema.outputs_master])

        # Sheet 3: Populations
        ws("Populations",
           ["ID","Label","Abbreviation","Flag","Dataset","Derivation","Definition","Dynamic","Confidence"],
           [[p.population_id, p.label, p.abbreviation, p.adam_flag_variable or "",
             p.adam_dataset, p.derivation_rule or "", p.formal_definition or "",
             "Yes" if p.is_dynamic else "No", f"{p.confidence:.2f}"]
            for p in schema.populations])

        # Sheet 4: Endpoints
        ws("Endpoints",
           ["ID","Classification","Description","Timepoints","ADaM Variables","From Table","Confidence"],
           [[e.endpoint_id, e.classification, e.description,
             ", ".join(e.timepoints), ", ".join(e.adam_variables),
             "Yes" if e.from_table else "No", f"{e.confidence:.2f}"]
            for e in schema.endpoints])

        # Sheet 5: Rules
        ws("Rules",
           ["ID","Type","Rule Text","Pseudocode","Datasets","Variables","Confidence","Page"],
           [[r.rule_id, r.rule_type.value, r.rule_text_verbatim[:200],
             r.pseudocode or "", ", ".join(r.applies_to_datasets),
             ", ".join(r.applies_to_variables), f"{r.confidence:.2f}",
             r.source_page or ""]
            for r in schema.rule_engine_output])

        # Sheet 6: Visit Schedule
        ws("Visit Schedule",
           ["ID","Label","Type","Nominal Day","Pre Days","Post Days","AVISIT","AVISITN","Analysis","Primary","Conf"],
           [[v.visit_id, v.visit_label, v.visit_type, v.nominal_day or "",
             v.window_pre_days or "", v.window_post_days or "",
             v.adam_visit_value or "", v.adam_visitnum or "",
             "Y" if v.analysis_visit_flag else "N",
             "Y" if v.primary_timepoint else "N", f"{v.confidence:.2f}"]
            for v in schema.visit_schedule])

        # Sheet 7: Programming Rules (from outputs)
        all_prog = []
        for o in schema.outputs_master:
            for r in o.programming_rules:
                all_prog.append([o.output_number or "", r.rule, r.rule_type.value,
                                  r.sas_hint or "", r.adam_variable or "",
                                  r.adam_dataset or "", f"{r.confidence:.2f}"])
        ws("Programming Rules", ["Output","Rule","Type","SAS Hint","Variable","Dataset","Confidence"], all_prog)

        # Sheet 8: QC Report
        if schema.qc_report:
            qc = schema.qc_report
            ws("QC Summary", ["Field","Value"], [
                ["Readiness Score", f"{qc.overall_readiness_score:.1%}"],
                ["Total Issues", qc.total_issues],
                ["Errors", qc.errors],
                ["Warnings", qc.warnings],
                ["Info", qc.infos],
                ["Completeness %", f"{qc.completeness_pct:.1f}%"],
                ["Low Confidence Outputs", qc.low_confidence_count],
            ])
            ws("QC Issues",
               ["Issue ID","Severity","Category","Output ID","Message","Suggested Fix"],
               [[i.issue_id, i.severity.value, i.category, i.output_id or "",
                 i.message, i.suggested_fix or ""]
                for i in qc.issues])

        wb.save(str(path))
        logger.info("Excel: %s", path)
        return path

    def export_html_report(self, schema: ClinicalIntelligenceSchema,
                            filename: Optional[str] = None) -> Path:
        """Generate interactive HTML report."""
        if not filename:
            ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
            filename = f"cti_report_{schema.study_metadata.protocol_id or 'report'}_{ts}.html"
        path = self.output_dir / filename
        meta = schema.study_metadata
        qc = schema.qc_report

        # Build outputs table rows
        out_rows = ""
        for o in schema.outputs_master:
            pop = (o.population.abbreviation if o.population else "")
            conf = o.confidence_score
            conf_cls = "ok" if conf >= 0.85 else "warn" if conf >= 0.65 else "err"
            out_rows += f"""
            <tr>
              <td><code>{o.output_number or '?'}</code></td>
              <td><span class="badge-{o.output_type.value.lower()}">{o.output_type.value[0]}</span></td>
              <td>{o.output_class.value}</td>
              <td>{(o.title or '')[:70]}</td>
              <td><code>{pop}</code></td>
              <td><span class="conf conf-{conf_cls}">{conf:.0%}</span></td>
            </tr>"""

        # Build populations
        pop_cards = ""
        for p in schema.populations:
            pop_cards += f"""
            <div class="pop-card">
              <div class="pop-abbrev">{p.abbreviation}</div>
              <div class="pop-label">{p.label}</div>
              <div class="pop-flag"><code>{p.adam_flag_variable or 'N/A'}</code></div>
              {f'<div class="pop-def">{p.formal_definition[:120]}...</div>' if p.formal_definition else ''}
              {"<span class='dynamic-badge'>DYNAMIC</span>" if p.is_dynamic else ""}
            </div>"""

        # Build endpoints
        ep_rows = ""
        for e in schema.endpoints:
            cls_color = {"Primary":"#ec4899","Key Secondary":"#f97316","Secondary":"#06b6d4",
                         "Safety":"#ef4444","PK":"#f59e0b","Exploratory":"#8b5cf6"}.get(e.classification,"#94a3b8")
            src = "Table" if e.from_table else "Prose"
            ep_rows += f"""
            <tr>
              <td><span style="color:{cls_color};font-weight:700;">{e.classification}</span></td>
              <td>{e.description[:120]}</td>
              <td>{', '.join(e.timepoints[:3]) or '—'}</td>
              <td><span class="src-badge">{src}</span></td>
              <td>{e.confidence:.0%}</td>
            </tr>"""

        # Build rules
        rule_rows = ""
        for r in schema.rule_engine_output[:50]:
            rule_rows += f"""
            <tr>
              <td><code>{r.rule_type.value}</code></td>
              <td>{r.rule_text_verbatim[:120]}</td>
              <td><code>{', '.join(r.applies_to_variables[:4])}</code></td>
              <td>{r.confidence:.0%}</td>
            </tr>"""

        readiness = qc.overall_readiness_score if qc else 0
        readiness_color = "#10b981" if readiness >= 0.80 else "#f59e0b" if readiness >= 0.60 else "#ef4444"

        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>CTI Report — {meta.protocol_id or 'N/A'}</title>
<style>
:root{{--bg:#0a0e1a;--surface:#0f172a;--border:#1e293b;--text:#e2e8f0;
  --muted:#64748b;--cyan:#06b6d4;--green:#10b981;--amber:#f59e0b;--red:#ef4444;}}
*{{box-sizing:border-box;margin:0;padding:0;}}
body{{font-family:'Segoe UI',sans-serif;background:var(--bg);color:var(--text);font-size:13px;line-height:1.6;}}
.header{{background:linear-gradient(135deg,var(--surface),#1e1b4b);padding:2rem 3rem;border-bottom:1px solid var(--border);}}
.header h1{{font-size:1.5rem;font-weight:700;margin-bottom:.3rem;}}
.header .meta{{font-size:12px;color:var(--muted);}}
.metrics{{display:flex;gap:1rem;padding:1.5rem 3rem;background:var(--surface);border-bottom:1px solid var(--border);flex-wrap:wrap;}}
.metric{{background:var(--bg);border:1px solid var(--border);border-radius:8px;padding:.75rem 1.25rem;min-width:100px;}}
.metric .n{{font-size:2rem;font-weight:700;color:var(--cyan);font-family:monospace;}}
.metric .l{{font-size:10px;color:var(--muted);text-transform:uppercase;letter-spacing:.05em;}}
.readiness-box{{background:var(--bg);border:2px solid {readiness_color};border-radius:8px;padding:.75rem 1.25rem;}}
.readiness-box .n{{color:{readiness_color};}}
.content{{padding:2rem 3rem;}}
section{{margin-bottom:2.5rem;}}
h2{{font-size:1rem;font-weight:700;color:var(--text);border-bottom:1px solid var(--border);
   padding-bottom:.4rem;margin-bottom:1rem;display:flex;align-items:center;gap:.5rem;}}
table{{width:100%;border-collapse:collapse;font-size:12px;}}
th{{background:var(--surface);color:var(--muted);font-weight:700;text-align:left;
    padding:6px 10px;border:1px solid var(--border);font-size:10px;text-transform:uppercase;}}
td{{padding:6px 10px;border:1px solid var(--border);color:#cbd5e1;vertical-align:top;}}
tr:nth-child(even) td{{background:rgba(255,255,255,.02);}}
code{{background:var(--border);padding:1px 5px;border-radius:3px;color:var(--cyan);font-size:11px;}}
.badge-table{{background:rgba(99,102,241,.2);color:#a5b4fc;padding:1px 6px;border-radius:3px;font-size:10px;font-weight:700;}}
.badge-listing{{background:rgba(6,182,212,.2);color:var(--cyan);padding:1px 6px;border-radius:3px;font-size:10px;font-weight:700;}}
.badge-figure{{background:rgba(16,185,129,.2);color:var(--green);padding:1px 6px;border-radius:3px;font-size:10px;font-weight:700;}}
.conf{{padding:2px 8px;border-radius:4px;font-size:10px;font-weight:700;}}
.conf-ok{{background:rgba(16,185,129,.15);color:var(--green);}}
.conf-warn{{background:rgba(245,158,11,.15);color:var(--amber);}}
.conf-err{{background:rgba(239,68,68,.15);color:var(--red);}}
.pop-grid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:.75rem;}}
.pop-card{{background:var(--surface);border:1px solid var(--border);border-radius:8px;padding:1rem;}}
.pop-abbrev{{font-size:1.4rem;font-weight:700;color:var(--cyan);font-family:monospace;}}
.pop-label{{font-size:11px;color:var(--text);margin:.2rem 0;}}
.pop-flag{{font-size:11px;color:var(--muted);}}
.pop-def{{font-size:10px;color:var(--muted);margin-top:.4rem;font-style:italic;}}
.dynamic-badge{{background:rgba(139,92,246,.2);color:#c4b5fd;padding:1px 6px;border-radius:3px;font-size:9px;font-weight:700;margin-top:.3rem;display:inline-block;}}
.src-badge{{background:rgba(6,182,212,.1);color:var(--cyan);padding:1px 5px;border-radius:3px;font-size:10px;}}
.tracked-changes{{background:rgba(16,185,129,.08);border:1px solid rgba(16,185,129,.3);
                  border-radius:6px;padding:.5rem 1rem;margin-bottom:1rem;font-size:12px;color:#6ee7b7;}}
footer{{text-align:center;padding:2rem;color:var(--muted);font-size:11px;border-top:1px solid var(--border);}}
</style>
</head>
<body>

<div class="header">
  <h1>&#x2B21; Clinical Trial Intelligence Report</h1>
  <div class="meta">
    Protocol: <strong>{meta.protocol_id or 'N/A'}</strong> &nbsp;&middot;&nbsp;
    Phase: <strong>{meta.phase or '?'}</strong> &nbsp;&middot;&nbsp;
    SAP Version: <strong>{meta.sap_version or 'N/A'}</strong> &nbsp;&middot;&nbsp;
    Amendment: <strong>{meta.amendment_number or 'N/A'}</strong> &nbsp;&middot;&nbsp;
    NCT: <strong>{meta.nct_number or 'N/A'}</strong>
    <br>Generated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')} &nbsp;&middot;&nbsp;
    CTI Platform v4.0
    {"&nbsp;&middot;&nbsp; <strong style='color:#6ee7b7;'>Tracked changes stripped</strong>" if schema.tracked_changes_stripped else ""}
  </div>
</div>

<div class="metrics">
  <div class="metric"><div class="n">{len(schema.outputs_master)}</div><div class="l">Outputs</div></div>
  <div class="metric"><div class="n">{len(schema.populations)}</div><div class="l">Populations</div></div>
  <div class="metric"><div class="n">{len(schema.endpoints)}</div><div class="l">Endpoints</div></div>
  <div class="metric"><div class="n">{len(schema.rule_engine_output)}</div><div class="l">Rules</div></div>
  <div class="metric"><div class="n">{len(schema.visit_schedule)}</div><div class="l">Visits</div></div>
  <div class="metric"><div class="n">{schema.inline_annotations_count}</div><div class="l">ADaM Annotations</div></div>
  <div class="metric readiness-box">
    <div class="n">{readiness:.0%}</div>
    <div class="l">QC Readiness</div>
  </div>
</div>

<div class="content">

{"<div class='tracked-changes'>&#10003; Tracked changes (strikethrough deleted text) were detected and stripped from extraction.</div>" if schema.tracked_changes_stripped else ""}

<section>
  <h2>&#x25A6; Analysis Outputs ({len(schema.outputs_master)})</h2>
  <table>
    <tr><th>Number</th><th>T</th><th>Class</th><th>Title</th><th>Population</th><th>Confidence</th></tr>
    {out_rows}
  </table>
</section>

<section>
  <h2>&#x1F465; Analysis Populations ({len(schema.populations)})</h2>
  <div class="pop-grid">{pop_cards}</div>
</section>

<section>
  <h2>&#x1F3AF; Endpoints ({len(schema.endpoints)})</h2>
  <table>
    <tr><th>Classification</th><th>Description</th><th>Timepoints</th><th>Source</th><th>Conf</th></tr>
    {ep_rows}
  </table>
</section>

<section>
  <h2>&#x26A1; Extracted Rules ({len(schema.rule_engine_output)})</h2>
  <table>
    <tr><th>Rule Type</th><th>Rule Text</th><th>ADaM Variables</th><th>Confidence</th></tr>
    {rule_rows}
  </table>
</section>

{"<section><h2>&#10003; QC Report</h2><table><tr><th>Severity</th><th>Category</th><th>Message</th></tr>" + "".join(f"<tr><td><strong style='color:" + ("#ef4444" if i.severity.value=="ERROR" else "#f59e0b" if i.severity.value=="WARNING" else "#06b6d4") + f";'>{i.severity.value}</strong></td><td>{i.category}</td><td>{i.message}</td></tr>" for i in (qc.issues if qc else [])) + "</table></section>" if qc else ""}

</div>
<footer>Clinical Trial Intelligence Platform v4.0 &nbsp;&middot;&nbsp; For Research Use</footer>
</body></html>"""

        path.write_text(html, encoding="utf-8")
        logger.info("HTML report: %s", path)
        return path

    def export_sas_metadata(self, schema: ClinicalIntelligenceSchema,
                             filename: Optional[str] = None) -> Path:
        if not filename:
            filename = f"sas_metadata_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.json"
        path = self.output_dir / filename
        data: Dict[str, Any] = {
            "protocol_id": schema.study_metadata.protocol_id,
            "sap_version": schema.study_metadata.sap_version,
            "generated_at": datetime.utcnow().isoformat(),
            "outputs": [],
            "adam_datasets": sorted({ds for o in schema.outputs_master
                                      for ds in (o.data_specification.input_datasets if o.data_specification else [])}),
            "programming_rules": [],
            "populations": [{"abbreviation": p.abbreviation, "flag": p.adam_flag_variable,
                              "dataset": p.adam_dataset, "derivation": p.derivation_rule}
                             for p in schema.populations],
            "inline_adam_annotations": list(set(
                ann for o in schema.outputs_master
                for ann in (o.data_specification.adam_annotations if o.data_specification else [])
            ))[:50],
        }
        for o in schema.outputs_master:
            data["outputs"].append({
                "output_id": o.output_id, "output_number": o.output_number,
                "title": o.title, "type": o.output_type.value,
                "population_flag": (o.population.adam_flag_variable if o.population else None),
                "input_datasets": (o.data_specification.input_datasets if o.data_specification else []),
                "programming_rules": [{"rule": r.rule, "type": r.rule_type.value,
                                        "sas_hint": r.sas_hint or "", "variable": r.adam_variable or ""}
                                       for r in o.programming_rules],
            })
        for r in schema.rule_engine_output:
            data["programming_rules"].append({
                "rule_id": r.rule_id, "type": r.rule_type.value,
                "text": r.rule_text_verbatim[:200],
                "pseudocode": r.pseudocode or "",
                "variables": r.applies_to_variables,
            })
        with path.open("w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, default=str)
        logger.info("SAS metadata: %s", path)
        return path

    def export_summary_txt(self, schema: ClinicalIntelligenceSchema,
                            filename: Optional[str] = None) -> Path:
        if not filename: filename = "extraction_summary.txt"
        path = self.output_dir / filename
        meta = schema.study_metadata; qc = schema.qc_report
        lines = [
            "=" * 70, "CLINICAL TRIAL INTELLIGENCE — EXTRACTION SUMMARY v4",
            "=" * 70,
            f"Protocol:    {meta.protocol_id or 'N/A'}",
            f"Title:       {meta.study_title or 'N/A'}",
            f"Phase:       {meta.phase or 'N/A'}",
            f"SAP Version: {meta.sap_version or 'N/A'}",
            f"Amendment:   {meta.amendment_number or 'N/A'}",
            f"SAP Date:    {meta.sap_date or 'N/A'}",
            f"Tracked changes stripped: {schema.tracked_changes_stripped}",
            f"Inline ADaM annotations: {schema.inline_annotations_count}",
            "",
            f"Outputs:     {len(schema.outputs_master)}",
            f"Populations: {len(schema.populations)} ({', '.join(p.abbreviation for p in schema.populations)})",
            f"Endpoints:   {len(schema.endpoints)}",
            f"Rules:       {len(schema.rule_engine_output)}",
            f"Visits:      {len(schema.visit_schedule)}",
            "",
        ]
        if qc:
            lines += ["QC SUMMARY", "-"*40,
                      f"Readiness: {qc.overall_readiness_score:.1%}",
                      f"Errors: {qc.errors}  Warnings: {qc.warnings}", ""]
        lines += ["OUTPUTS", "-"*40]
        for o in schema.outputs_master:
            pa = o.population.abbreviation if o.population else "?"
            lines.append(f"  [{o.output_type.value[0]}] {o.output_number or '?'}: "
                         f"{(o.title or '')[:65]} [{pa}] conf={o.confidence_score:.2f}")
        path.write_text("\n".join(lines), encoding="utf-8")
        return path
