"""
CTI v4 Parser — Real-world SAP handling.
KEY v4 FIXES vs real screenshots:
  - Tracked changes (w:del strikethrough red text) STRIPPED — not included in text
  - w:ins (accepted insertions) included
  - Inline ADaM annotations extracted (ADSL.SAFFL='Y' in green/colored runs)
  - 5-level output numbering (15.8.1.3.1) supported
  - SAP version extraction (Version 0.1, Amendment 2)
  - O(n) paragraph matching
  - XML streaming for large files
  - Parallel section text build
  - Appendix detection
  - Study schema diagram detection
"""
from __future__ import annotations
import re, zipfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple
from xml.etree import ElementTree as ET
from src.utils import get_logger, clean_text

logger = get_logger(__name__)

_W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
_LARGE = 4 * 1024 * 1024

def _qn(local: str) -> str:
    return f"{{{_W}}}{local}"

# Tags to STRIP (tracked deletions, comments)
_DEL_TAGS: Set[str] = {
    _qn(t) for t in ("del", "delText", "delInstrText",
                     "commentRangeStart", "commentRangeEnd", "comment",
                     "proofErr", "bookmarkEnd", "permStart", "permEnd")
}

# Pattern: inline ADaM variable annotations like ADSL.SAFFL='Y' or ADSL.PKxFL='Y'
_ADAM_INLINE_RE = re.compile(
    r"ADSL?\.[A-Z][A-Z0-9]{2,12}(?:FL|RS|DT|CD|TM|N|C)?\s*(?:=\s*['\"]?[A-Z0-9_]+['\"]?)?",
    re.IGNORECASE
)
_VERSION_RE = re.compile(r"[Vv]ersion\s+([\d]+\.[\d]+(?:\.[\d]+)?|\d+)")
_AMENDMENT_RE = re.compile(r"[Aa]mendment\s+(\d+|[A-Z])\b")
_NUMBERED_HEAD_RE = re.compile(r"^(\d+(?:\.\d+){0,5})\s+(.+)$")
_APPENDIX_RE = re.compile(r"^(?:APPENDIX|Appendix|ANNEX|Annex)\s*([A-Z\d]?)[:\s\-]*(.*)", re.IGNORECASE)
_TOC_STYLE_RE = re.compile(r"toc\s*\d|contents?\s*\d", re.IGNORECASE)


# ── Data containers ───────────────────────────────────────────────────────────

@dataclass
class ParsedParagraph:
    paragraph_id: str; text: str; style: str; level: int
    page_estimate: int; index: int
    has_hyperlink: bool = False; bookmark_id: Optional[str] = None
    is_toc_entry: bool = False; has_drawing: bool = False
    adam_annotations: List[str] = field(default_factory=list)  # NEW
    is_deleted: bool = False  # NEW: was this deleted content?

@dataclass
class ParsedTable:
    table_id: str; page_estimate: int; paragraph_index: int
    rows: List[List[str]] = field(default_factory=list)
    caption: str = ""; has_header: bool = True
    is_study_schema: bool = False
    adam_annotations: List[str] = field(default_factory=list)  # NEW
    @property
    def num_rows(self): return len(self.rows)
    @property
    def num_cols(self): return max((len(r) for r in self.rows), default=0)

@dataclass
class ParsedSection:
    section_id: str; title: str; level: int
    parent_id: Optional[str]; page_start: int
    paragraphs: List[ParsedParagraph] = field(default_factory=list)
    tables: List[ParsedTable] = field(default_factory=list)
    full_text: str = ""; is_appendix: bool = False
    appendix_label: Optional[str] = None
    adam_annotations: List[str] = field(default_factory=list)  # NEW
    def get_text(self) -> str:
        return self.full_text or " ".join(p.text for p in self.paragraphs)

@dataclass
class ParsedDocument:
    file_name: str; file_type: str; file_size_bytes: int
    paragraphs: List[ParsedParagraph] = field(default_factory=list)
    tables: List[ParsedTable] = field(default_factory=list)
    sections: List[ParsedSection] = field(default_factory=list)
    full_text: str = ""; total_pages: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)
    toc_map: Dict[str, str] = field(default_factory=dict)
    cross_refs: Dict[str, str] = field(default_factory=dict)
    has_study_schema_diagram: bool = False
    appendix_sections: List[str] = field(default_factory=list)
    tracked_changes_stripped: bool = False  # NEW
    sap_version: Optional[str] = None       # NEW
    sap_amendment: Optional[str] = None     # NEW
    all_adam_annotations: List[str] = field(default_factory=list)  # NEW

    def get_section_by_id(self, sid: str) -> Optional[ParsedSection]:
        return next((s for s in self.sections if s.section_id == sid), None)
    def find_sections_containing(self, kw: str) -> List[ParsedSection]:
        kw = kw.lower()
        return [s for s in self.sections if kw in s.title.lower() or kw in s.get_text().lower()]


# ── XML helpers ───────────────────────────────────────────────────────────────

def _para_text_strip_deleted(para_el: ET.Element) -> Tuple[str, bool, List[str]]:
    """
    Extract clean text from <w:p>, stripping ALL deleted/comment content.
    Uses ITERATIVE stack walk to avoid RecursionError on deeply nested DOCX.
    Returns (clean_text, had_deletions, adam_annotations).
    """
    _t = _qn("t"); _del = _qn("del"); _ins = _qn("ins")
    parts: List[str] = []
    had_del = False
    annotations: List[str] = []

    # Iterative DFS: stack = (element, in_deleted)
    stack = [(para_el, False)]
    while stack:
        el, in_del = stack.pop()
        if el.tag in _DEL_TAGS or el.tag == _del:
            had_del = True
            continue  # skip entire subtree of deleted/comment content
        if el.tag == _ins:
            # accepted revision — include children but not in_del
            for ch in reversed(list(el)):
                stack.append((ch, False))
            continue
        if el.tag == _t:
            if not in_del:
                txt = el.text or ""
                parts.append(txt)
                found = _ADAM_INLINE_RE.findall(txt)
                annotations.extend(found)
            continue
        # Push children in reverse order so first child processed first
        for ch in reversed(list(el)):
            stack.append((ch, in_del))

    text = "".join(parts)
    return text, had_del, annotations


def _detect_heading_level(style: str, text: str) -> int:
    # Style-based
    m = re.match(r"(?:heading|h)\s*(\d+)|title|subtitle", style, re.IGNORECASE)
    if m:
        g = m.group(1)
        return int(g) if g else 1
    # Appendix heading
    if _APPENDIX_RE.match(text.strip()):
        return 1
    # Numbered heading (up to 5 levels)
    m = _NUMBERED_HEAD_RE.match(text.strip())
    if m:
        return m.group(1).count(".") + 1
    # ALL CAPS short
    if len(text) < 80 and re.match(r"^[A-Z][A-Z\s\d\-\/]{4,}$", text.strip()):
        return 1
    return 0


def _estimate_page(idx: int, avg: int = 9) -> int:
    return max(1, idx // avg + 1)


def _has_drawing(el: ET.Element) -> bool:
    for ch in el.iter():
        if ch.tag in (_qn("drawing"), _qn("pict")):
            return True
    return False


def _has_hyperlink(el: ET.Element) -> bool:
    return el.find(f".//{_qn('hyperlink')}") is not None


def _bookmark_name(el: ET.Element) -> Optional[str]:
    for bm in el.iter(_qn("bookmarkStart")):
        nm = bm.get(_qn("name"), "")
        if nm and not nm.startswith("_"):
            return nm
    return None


# ── DOCX Parser ───────────────────────────────────────────────────────────────

class DocxParser:
    def __init__(self, avg: int = 9):
        self.avg = avg

    def parse(self, file_path: Path) -> ParsedDocument:
        logger.info("Parsing DOCX: %s (%.1f KB)", file_path.name, file_path.stat().st_size/1024)
        try:
            import docx as _docx
            if file_path.stat().st_size > _LARGE:
                logger.info("Large file → XML streaming path")
                return self._parse_xml(file_path)
            return self._parse_python_docx(file_path, _docx)
        except ImportError:
            return self._parse_xml(file_path)
        except Exception as exc:
            logger.error("DOCX parse error: %s", exc)
            return self._parse_xml(file_path)

    def _parse_python_docx(self, file_path: Path, docx_mod: Any) -> ParsedDocument:
        doc = docx_mod.Document(str(file_path))
        # O(n) lookup maps — eliminates O(n²) inner loop from v2
        para_by_eid = {id(p._element): p for p in doc.paragraphs}
        tbl_by_eid  = {id(t._element): t for t in doc.tables}

        paragraphs: List[ParsedParagraph] = []
        tables: List[ParsedTable] = []
        para_index = 0
        has_diagram = False
        all_annotations: List[str] = []
        had_any_del = False

        for element in doc.element.body:
            local = element.tag.rsplit("}", 1)[-1]

            if local == "p":
                p_obj = para_by_eid.get(id(element))
                if p_obj is None:
                    para_index += 1; continue

                # Strip tracked deletions, extract ADaM annotations
                raw_text, had_del, annotations = _para_text_strip_deleted(element)
                text = clean_text(raw_text)
                if had_del:
                    had_any_del = True
                all_annotations.extend(annotations)

                has_draw = _has_drawing(element)
                if has_draw:
                    has_diagram = True
                    if not text: text = "[DIAGRAM]"
                if not text:
                    para_index += 1; continue

                style = (p_obj.style.name if p_obj.style else "Normal") or "Normal"
                paragraphs.append(ParsedParagraph(
                    paragraph_id=f"para_{para_index:05d}",
                    text=text, style=style,
                    level=_detect_heading_level(style, text),
                    page_estimate=_estimate_page(para_index, self.avg),
                    index=para_index,
                    has_hyperlink=_has_hyperlink(element),
                    bookmark_id=_bookmark_name(element),
                    is_toc_entry=bool(_TOC_STYLE_RE.search(style)),
                    has_drawing=has_draw,
                    adam_annotations=annotations,
                ))
                para_index += 1

            elif local == "tbl":
                tbl_obj = tbl_by_eid.get(id(element))
                if tbl_obj is None:
                    para_index += 1; continue
                rows = []
                tbl_annotations: List[str] = []
                for row in tbl_obj.rows:
                    r = []
                    for cell in row.cells:
                        cell_text, _, cell_ann = _para_text_strip_deleted(
                            cell._tc if hasattr(cell, '_tc') else cell._element
                        )
                        r.append(clean_text(cell_text) or clean_text(cell.text))
                        tbl_annotations.extend(cell_ann)
                    rows.append(r)
                all_annotations.extend(tbl_annotations)
                is_schema = len(rows)==1 and len(rows[0])==1 and not rows[0][0].strip()
                if is_schema: has_diagram = True
                tables.append(ParsedTable(
                    table_id=f"tbl_{len(tables):04d}",
                    page_estimate=_estimate_page(para_index, self.avg),
                    paragraph_index=para_index, rows=rows,
                    is_study_schema=is_schema, adam_annotations=tbl_annotations,
                ))
                para_index += 1

        return self._assemble(file_path, paragraphs, tables, has_diagram,
                              had_any_del, all_annotations)

    def _parse_xml(self, file_path: Path) -> ParsedDocument:
        try:
            with zipfile.ZipFile(str(file_path), "r") as zf:
                if "word/document.xml" not in zf.namelist():
                    return self._empty(file_path)
                xml_bytes = zf.read("word/document.xml")
        except Exception as exc:
            logger.error("Cannot open DOCX: %s", exc)
            return self._empty(file_path)
        try:
            root = ET.fromstring(xml_bytes)
        except ET.ParseError as exc:
            logger.error("XML parse failed: %s", exc)
            return self._empty(file_path)

        body = root.find(f".//{_qn('body')}")
        if body is None: return self._empty(file_path)

        _p = _qn("p"); _tbl = _qn("tbl")
        _tr = _qn("tr"); _tc = _qn("tc")
        _pStyle = _qn("pStyle"); _pPr = _qn("pPr"); _val = _qn("val")

        paragraphs: List[ParsedParagraph] = []
        tables: List[ParsedTable] = []
        para_index = 0; has_diagram = False
        all_annotations: List[str] = []; had_any_del = False

        for element in body:
            if element.tag == _p:
                raw_text, had_del, annotations = _para_text_strip_deleted(element)
                text = clean_text(raw_text)
                if had_del: had_any_del = True
                all_annotations.extend(annotations)
                has_draw = _has_drawing(element)
                if has_draw:
                    has_diagram = True
                    if not text: text = "[DIAGRAM]"
                if not text:
                    para_index += 1; continue
                style = "Normal"
                pPr = element.find(_pPr)
                if pPr is not None:
                    ps = pPr.find(_pStyle)
                    if ps is not None: style = ps.get(_val, "Normal")
                paragraphs.append(ParsedParagraph(
                    paragraph_id=f"para_{para_index:05d}",
                    text=text, style=style,
                    level=_detect_heading_level(style, text),
                    page_estimate=_estimate_page(para_index, self.avg),
                    index=para_index,
                    has_hyperlink=_has_hyperlink(element),
                    bookmark_id=_bookmark_name(element),
                    is_toc_entry=bool(_TOC_STYLE_RE.search(style)),
                    has_drawing=has_draw, adam_annotations=annotations,
                ))
                para_index += 1

            elif element.tag == _tbl:
                rows = []; tbl_ann: List[str] = []
                for tr in element.iter(_tr):
                    row = []
                    for tc in tr.findall(_tc):
                        parts = []
                        for p in tc.iter(_p):
                            t, _, ann = _para_text_strip_deleted(p)
                            ct = clean_text(t)
                            if ct: parts.append(ct)
                            tbl_ann.extend(ann)
                        row.append(" ".join(parts))
                    if row: rows.append(row)
                all_annotations.extend(tbl_ann)
                is_schema = len(rows)==1 and len(rows[0])==1 and not rows[0][0].strip()
                if is_schema: has_diagram = True
                tables.append(ParsedTable(
                    table_id=f"tbl_{len(tables):04d}",
                    page_estimate=_estimate_page(para_index, self.avg),
                    paragraph_index=para_index, rows=rows,
                    is_study_schema=is_schema, adam_annotations=tbl_ann,
                ))
                para_index += 1

        return self._assemble(file_path, paragraphs, tables, has_diagram,
                              had_any_del, all_annotations)

    def _assemble(self, file_path, paragraphs, tables, has_diagram,
                  had_del, all_annotations) -> ParsedDocument:
        sections = self._build_sections(paragraphs, tables)
        full_text = "\n".join(p.text for p in paragraphs)

        # Extract SAP version and amendment from preamble
        preamble = full_text[:3000]
        sap_version = None; sap_amendment = None
        vm = _VERSION_RE.search(preamble)
        if vm: sap_version = vm.group(1)
        am = _AMENDMENT_RE.search(preamble)
        if am: sap_amendment = am.group(1)

        toc_map, cross_refs = self._build_toc_map(paragraphs, sections)
        app_ids = list({s.section_id for s in sections if s.is_appendix})

        return ParsedDocument(
            file_name=file_path.name, file_type="docx",
            file_size_bytes=file_path.stat().st_size,
            paragraphs=paragraphs, tables=tables, sections=sections,
            full_text=full_text,
            total_pages=_estimate_page(len(paragraphs), self.avg),
            toc_map=toc_map, cross_refs=cross_refs,
            has_study_schema_diagram=has_diagram,
            appendix_sections=app_ids,
            tracked_changes_stripped=had_del,
            sap_version=sap_version, sap_amendment=sap_amendment,
            all_adam_annotations=list(dict.fromkeys(all_annotations)),
        )

    def _build_sections(self, paragraphs, tables) -> List[ParsedSection]:
        sections: List[ParsedSection] = []
        stack: List[ParsedSection] = []
        orphans: List[ParsedParagraph] = []
        tbl_by_idx = {t.paragraph_index: t for t in tables}
        app_counter = 0; _letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

        for para in paragraphs:
            if para.level > 0:
                while stack and stack[-1].level >= para.level:
                    stack.pop()
                parent_id = stack[-1].section_id if stack else None
                sec_id = f"sec_{len(sections):04d}"
                m = _APPENDIX_RE.match(para.text.strip())
                is_app = bool(m)
                app_label = None
                if is_app:
                    explicit = (m.group(1) or "").strip().upper()
                    if explicit: app_label = explicit
                    else:
                        app_label = _letters[min(app_counter, 25)]
                        app_counter += 1
                sec = ParsedSection(
                    section_id=sec_id, title=para.text, level=para.level,
                    parent_id=parent_id, page_start=para.page_estimate,
                    is_appendix=is_app, appendix_label=app_label,
                )
                sections.append(sec); stack.append(sec)
            else:
                if stack:
                    stack[-1].paragraphs.append(para)
                    stack[-1].adam_annotations.extend(para.adam_annotations)
                    if para.index in tbl_by_idx:
                        t = tbl_by_idx[para.index]
                        stack[-1].tables.append(t)
                        stack[-1].adam_annotations.extend(t.adam_annotations)
                else:
                    orphans.append(para)

        # Parallel full_text build for large docs
        self._build_section_texts_parallel(sections)

        # Deduplicate appendix sections (TOC entries vs real content)
        _seen_app: Dict[str, str] = {}
        for s in sections:
            if s.is_appendix: _seen_app[s.title] = s.section_id
        real_app = set(_seen_app.values())
        for s in sections:
            if s.is_appendix and s.section_id not in real_app:
                s.is_appendix = False; s.appendix_label = None

        if orphans:
            pre = ParsedSection(
                section_id="sec_preamble", title="Document Preamble",
                level=0, parent_id=None, page_start=1, paragraphs=orphans,
            )
            pre.full_text = " ".join(p.text for p in orphans)
            sections.insert(0, pre)
        return sections

    @staticmethod
    def _build_section_texts_parallel(sections: List[ParsedSection]) -> None:
        if len(sections) <= 20:
            for s in sections: s.full_text = " ".join(p.text for p in s.paragraphs)
            return
        sid_map = {s.section_id: s for s in sections}
        def _b(sec): return sec.section_id, " ".join(p.text for p in sec.paragraphs)
        with ThreadPoolExecutor(max_workers=4) as pool:
            for fut in as_completed({pool.submit(_b, s) for s in sections}):
                try:
                    sid, txt = fut.result(); sid_map[sid].full_text = txt
                except Exception as exc: logger.warning("Section text build: %s", exc)

    @staticmethod
    def _build_toc_map(paragraphs, sections):
        title_to_sid = {s.title: s.section_id for s in sections}
        toc_map = {}; cross_refs = {}
        for p in paragraphs:
            if p.bookmark_id and p.level > 0:
                sid = title_to_sid.get(p.text)
                if sid: toc_map[p.bookmark_id] = sid
        for s in sections:
            m = re.match(r"^(\d+(?:\.\d+)*)\s+", s.title)
            if m: cross_refs[m.group(1)] = s.section_id
        return toc_map, cross_refs

    def _text_to_paragraphs(self, text: str) -> List[ParsedParagraph]:
        paras = []
        for i, line in enumerate(l.strip() for l in text.splitlines() if l.strip()):
            anns = _ADAM_INLINE_RE.findall(line)
            paras.append(ParsedParagraph(
                paragraph_id=f"para_{i:05d}", text=line, style="Normal",
                level=_detect_heading_level("", line),
                page_estimate=_estimate_page(len(paras), self.avg),
                index=len(paras), adam_annotations=anns,
            ))
        return paras

    @staticmethod
    def _empty(file_path: Path) -> ParsedDocument:
        return ParsedDocument(
            file_name=file_path.name, file_type="docx",
            file_size_bytes=file_path.stat().st_size if file_path.exists() else 0,
        )


# ── RTF / Text parsers ────────────────────────────────────────────────────────
class RtfParser:
    _RTF = re.compile(r"\\[a-zA-Z]+(?:-?\d+)?\s?|[{}]|\\\'[0-9a-fA-F]{2}")
    _NL  = re.compile(r"\\(par|line|pard)\b")
    def parse(self, fp: Path) -> ParsedDocument:
        try:
            raw = fp.read_bytes().decode("latin-1", errors="replace")
            text = re.sub(r"\n{3,}", "\n\n", self._RTF.sub("", self._NL.sub("\n", raw))).strip()
            dp = DocxParser()
            paras = dp._text_to_paragraphs(text)
            secs = dp._build_sections(paras, [])
            return ParsedDocument(
                file_name=fp.name, file_type="rtf", file_size_bytes=fp.stat().st_size,
                paragraphs=paras, sections=secs,
                full_text="\n".join(p.text for p in paras), total_pages=max(1,len(paras)//9),
            )
        except Exception as exc:
            logger.error("RTF: %s", exc)
            return DocxParser._empty(fp)

class TextParser:
    def parse(self, fp: Path) -> ParsedDocument:
        try:
            raw = fp.read_text(encoding="utf-8", errors="replace")
            dp = DocxParser()
            paras = dp._text_to_paragraphs(raw)
            secs = dp._build_sections(paras, [])
            return ParsedDocument(
                file_name=fp.name, file_type="txt", file_size_bytes=fp.stat().st_size,
                paragraphs=paras, sections=secs,
                full_text="\n".join(p.text for p in paras), total_pages=max(1,len(paras)//9),
            )
        except Exception as exc:
            logger.error("Text: %s", exc)
            return DocxParser._empty(fp)

class ExcelParser:
    """Parse ADaM template Excel — extract dataset/variable specs."""
    def parse(self, fp: Path) -> Dict[str, Any]:
        try:
            import openpyxl
            wb = openpyxl.load_workbook(str(fp), read_only=True, data_only=True)
            result: Dict[str, Any] = {"datasets": {}, "file": fp.name}
            for ws in wb.worksheets:
                rows = [[str(c.value or "") for c in row] for row in ws.iter_rows()]
                if rows:
                    result["datasets"][ws.title] = {"rows": rows[:200], "headers": rows[0] if rows else []}
            return result
        except Exception as exc:
            logger.error("Excel parse: %s", exc)
            return {"datasets": {}, "file": fp.name, "error": str(exc)}


def parse_document(fp: Path) -> ParsedDocument:
    suffix = fp.suffix.lower()
    if suffix == ".docx": return DocxParser().parse(fp)
    elif suffix == ".rtf": return RtfParser().parse(fp)
    elif suffix in (".txt",".text",".md"): return TextParser().parse(fp)
    else:
        logger.warning("Unknown extension %s", suffix)
        return TextParser().parse(fp)
