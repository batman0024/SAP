"""
CTI v5 QC Engine — Fixed readiness scoring logic.
CRITICAL FIX: score no longer starts at 1.0 and adds bonuses.
Now builds from 0 based on evidence quality.
New checks: Part J additions (shell coverage, method-dataset mismatch, estimand completeness).
"""
from __future__ import annotations
import re
from typing import Dict, List, Optional, Set
from src.models.schema import (
    AnalysisOutput, ClinicalIntelligenceSchema, Endpoint, Population,
    QCIssue, QCReport, QCSeverity, VisitWindow, EndpointClassification,
    RuleType,
)
from src.utils import get_logger
logger = get_logger(__name__)

CONFIDENCE_THRESHOLD = 0.65
MIN_OUTPUTS = 3


class QCEngine:
    def __init__(self, confidence_threshold: float = CONFIDENCE_THRESHOLD,
                 min_outputs: int = MIN_OUTPUTS) -> None:
        self.threshold = confidence_threshold
        self.min_outputs = min_outputs

    def run(self, schema: ClinicalIntelligenceSchema) -> QCReport:
        logger.info("QC v5: %d outputs, %d pops, %d endpoints, %d rules",
                    len(schema.outputs_master), len(schema.populations),
                    len(schema.endpoints), len(schema.rule_engine_output))
        issues: List[QCIssue] = []
        issues.extend(self._check_study_metadata(schema))
        issues.extend(self._check_populations(schema))
        issues.extend(self._check_endpoints(schema))
        issues.extend(self._check_outputs(schema))
        issues.extend(self._check_output_completeness(schema))
        issues.extend(self._check_duplicate_outputs(schema))
        issues.extend(self._check_population_consistency(schema))
        issues.extend(self._check_visit_schedule(schema))
        issues.extend(self._check_rule_coverage(schema))
        issues.extend(self._check_confidence_thresholds(schema))
        issues.extend(self._check_tracked_changes(schema))
        issues.extend(self._check_inline_annotations(schema))
        issues.extend(self._check_population_dataset_alignment(schema))  # Part J
        issues.extend(self._check_analysis_method_dataset_mismatch(schema))  # Part J
        issues.extend(self._check_estimand_completeness(schema))  # Part J
        issues.extend(self._check_adam_spec(schema))  # new
        issues.extend(self._check_flag_defaults(schema))  # restored

        errors   = sum(1 for i in issues if i.severity == QCSeverity.ERROR)
        warnings = sum(1 for i in issues if i.severity == QCSeverity.WARNING)
        infos    = sum(1 for i in issues if i.severity == QCSeverity.INFO)
        n = len(schema.outputs_master)
        low_conf = sum(1 for o in schema.outputs_master if o.confidence_score < self.threshold)

        # Completeness
        complete = sum(
            1 for o in schema.outputs_master
            if o.population and o.data_specification and o.data_specification.input_datasets
        )
        completeness = (complete / n * 100) if n else 0.0

        # ── FIXED READINESS SCORING (starts from 0, builds from evidence) ────────
        # Was: base=1.0 then subtract errors/warnings — could still return 1.0 with errors
        # Now: Build from components, errors cap the maximum

        score_components = []

        # 1. Population extraction quality (0-20%)
        if schema.populations:
            pop_q = min(1.0, len(schema.populations) / 4)
            pop_q *= (1.0 - 0.1 * sum(1 for p in schema.populations
                                       if not p.adam_flag_variable) / max(len(schema.populations),1))
            score_components.append(("populations", pop_q * 0.20))
        else:
            score_components.append(("populations", 0.0))

        # 2. Endpoint extraction quality (0-20%)
        if schema.endpoints:
            ep_q = min(1.0, len(schema.endpoints) / 3)
            has_primary = any(e.classification == "Primary" for e in schema.endpoints)
            ep_q = ep_q * (1.1 if has_primary else 0.7)
            ep_q = min(1.0, ep_q)
            score_components.append(("endpoints", ep_q * 0.20))
        else:
            score_components.append(("endpoints", 0.0))

        # 3. Output extraction quality (0-25%)
        if n >= self.min_outputs:
            out_q = min(1.0, n / 10)
            out_q *= completeness / 100
            score_components.append(("outputs", out_q * 0.25))
        else:
            out_q = (n / self.min_outputs) * 0.3 if n else 0.0
            score_components.append(("outputs", out_q * 0.25))

        # 4. Rule extraction quality (0-20%)
        if schema.rule_engine_output:
            rule_types = {r.rule_type.value for r in schema.rule_engine_output}
            coverage = len(rule_types & {"baseline_definition","censoring","date_imputation",
                                          "derivation","filter","flag"}) / 6
            score_components.append(("rules", coverage * 0.20))
        else:
            score_components.append(("rules", 0.0))

        # 5. Study metadata quality (0-10%)
        meta = schema.study_metadata
        meta_q = sum([bool(meta.protocol_id), bool(meta.phase),
                      bool(meta.sap_version), bool(meta.nct_number)]) / 4
        score_components.append(("metadata", meta_q * 0.10))

        # 6. Visit schedule (0-5%)
        score_components.append(("visits", min(1.0, len(schema.visit_schedule)/3) * 0.05))

        base_score = sum(v for _, v in score_components)

        # Error penalties: each ERROR costs 6%, WARNING costs 1.5%
        penalty = errors * 0.06 + warnings * 0.015
        # Low confidence penalty
        if n > 0:
            penalty += (low_conf / n) * 0.10

        readiness = max(0.0, min(1.0, base_score - penalty))

        return QCReport(
            total_outputs=n, total_issues=len(issues),
            errors=errors, warnings=warnings, infos=infos,
            overall_readiness_score=readiness,
            completeness_pct=completeness,
            low_confidence_count=low_conf,
            issues=issues,
        )

    # ── Checks ────────────────────────────────────────────────────────────────

    def _check_study_metadata(self, schema) -> List[QCIssue]:
        issues = []
        meta = schema.study_metadata
        if not meta.protocol_id:
            issues.append(QCIssue(severity=QCSeverity.WARNING, category="Study Metadata",
                message="Protocol ID not extracted",
                suggested_fix="Ensure SAP header contains 'Protocol Number: ABC-123'"))
        if not meta.phase:
            issues.append(QCIssue(severity=QCSeverity.INFO, category="Study Metadata",
                message="Study phase not detected"))
        if not meta.sap_version:
            issues.append(QCIssue(severity=QCSeverity.INFO, category="Study Metadata",
                message="SAP version not extracted"))
        if not meta.nct_number:
            issues.append(QCIssue(severity=QCSeverity.INFO, category="Study Metadata",
                message="NCT number not found"))
        return issues

    def _check_populations(self, schema) -> List[QCIssue]:
        issues = []
        pops = schema.populations
        if not pops:
            issues.append(QCIssue(severity=QCSeverity.ERROR, category="Populations",
                message="No analysis populations extracted",
                suggested_fix="Check 'Analysis Sets' section for population definitions"))
            return issues
        if len(pops) < 2:
            issues.append(QCIssue(severity=QCSeverity.WARNING, category="Populations",
                message=f"Only {len(pops)} population(s); expected >=2"))
        abbrevs = {p.abbreviation for p in pops}
        if not abbrevs & {"ITT","FAS","ENRL","RAND"}:
            issues.append(QCIssue(severity=QCSeverity.WARNING, category="Populations",
                message="No primary efficacy population (ITT/FAS/ENRL) detected"))
        if not abbrevs & {"SAF","SAFETY"}:
            issues.append(QCIssue(severity=QCSeverity.WARNING, category="Populations",
                message="No safety population (SAF) detected"))
        for pop in pops:
            if not pop.adam_flag_variable:
                issues.append(QCIssue(severity=QCSeverity.WARNING, category="Populations",
                    message=f"Population '{pop.abbreviation}' missing ADaM flag variable"))
            if pop.confidence < 0.60:
                issues.append(QCIssue(severity=QCSeverity.INFO, category="Populations",
                    message=f"Low confidence for '{pop.abbreviation}': {pop.confidence:.0%}"))
        return issues

    def _check_endpoints(self, schema) -> List[QCIssue]:
        issues = []
        eps = schema.endpoints
        if not eps:
            issues.append(QCIssue(severity=QCSeverity.ERROR, category="Endpoints",
                message="No endpoints extracted",
                suggested_fix="v5 extracts from 2-column objective|endpoint tables and prose. Check SAP section 1.1."))
            return issues
        if not any(e.classification == "Primary" for e in eps):
            issues.append(QCIssue(severity=QCSeverity.WARNING, category="Endpoints",
                message="No primary endpoint identified"))
        from_tables = sum(1 for e in eps if e.from_table)
        if from_tables > 0:
            issues.append(QCIssue(severity=QCSeverity.INFO, category="Endpoints",
                message=f"{from_tables}/{len(eps)} endpoints extracted from structured tables"))
        return issues

    def _check_outputs(self, schema) -> List[QCIssue]:
        issues = []
        n = len(schema.outputs_master)
        if n == 0:
            issues.append(QCIssue(severity=QCSeverity.ERROR, category="Outputs",
                message="No outputs (TLFs) extracted",
                suggested_fix="Verify SAP has 'Table X.X.X:' entries with titles"))
            return issues
        if n < self.min_outputs:
            issues.append(QCIssue(severity=QCSeverity.WARNING, category="Outputs",
                message=f"Only {n} outputs; expected >={self.min_outputs}"))
        no_pop = sum(1 for o in schema.outputs_master if not o.population)
        if no_pop:
            issues.append(QCIssue(severity=QCSeverity.WARNING, category="Outputs",
                message=f"{no_pop}/{n} outputs have no population assigned"))
        return issues

    def _check_output_completeness(self, schema) -> List[QCIssue]:
        issues = []
        for o in schema.outputs_master:
            missing = [f for f, v in [("title", o.title), ("population", o.population),
                                       ("number", o.output_number)] if not v]
            if missing:
                issues.append(QCIssue(severity=QCSeverity.INFO, category="Output Completeness",
                    output_id=o.output_id,
                    message=f"Output {o.output_id} missing: {', '.join(missing)}",
                    auto_fixable=False))
        return issues

    def _check_duplicate_outputs(self, schema) -> List[QCIssue]:
        issues = []
        seen: Dict[str, str] = {}
        for o in schema.outputs_master:
            key = f"{o.output_type.value[0]}_{o.output_number}"
            if o.output_number and key in seen:
                issues.append(QCIssue(severity=QCSeverity.WARNING, category="Duplicate Outputs",
                    output_id=o.output_id,
                    message=f"Duplicate: {o.output_type.value} {o.output_number}"))
            elif o.output_number:
                seen[key] = o.output_id
        return issues

    def _check_population_consistency(self, schema) -> List[QCIssue]:
        issues = []
        pop_abbrevs = {p.abbreviation for p in schema.populations}
        for o in schema.outputs_master:
            if o.population and o.population.abbreviation not in pop_abbrevs:
                issues.append(QCIssue(severity=QCSeverity.WARNING, category="Population Consistency",
                    output_id=o.output_id,
                    message=f"Output uses unknown population '{o.population.abbreviation}'"))
        return issues

    def _check_visit_schedule(self, schema) -> List[QCIssue]:
        issues = []
        if not schema.visit_schedule:
            issues.append(QCIssue(severity=QCSeverity.WARNING, category="Visit Schedule",
                message="No visit schedule extracted",
                suggested_fix="Check for 'Visit Windows' section or visit window tables"))
        return issues

    def _check_rule_coverage(self, schema) -> List[QCIssue]:
        issues = []
        if not schema.rule_engine_output:
            issues.append(QCIssue(severity=QCSeverity.ERROR, category="Rules",
                message="No programming rules extracted"))
            return issues
        rule_types = {r.rule_type.value for r in schema.rule_engine_output}
        for rt in ["baseline_definition", "date_imputation", "censoring"]:
            if rt not in rule_types:
                issues.append(QCIssue(severity=QCSeverity.WARNING, category="Rules",
                    message=f"No '{rt}' rules found"))
        inline = sum(1 for r in schema.rule_engine_output if r.rule_type.value == "inline_annotation")
        if inline > 0:
            issues.append(QCIssue(severity=QCSeverity.INFO, category="Rules",
                message=f"{inline} inline ADaM annotation rules extracted"))
        return issues

    def _check_confidence_thresholds(self, schema) -> List[QCIssue]:
        issues = []
        low = [o for o in schema.outputs_master if o.confidence_score < self.threshold]
        if len(low) > 3:
            issues.append(QCIssue(severity=QCSeverity.WARNING, category="Confidence",
                message=f"{len(low)} outputs below confidence threshold ({self.threshold:.0%})"))
        return issues

    def _check_tracked_changes(self, schema) -> List[QCIssue]:
        if schema.tracked_changes_stripped:
            return [QCIssue(severity=QCSeverity.INFO, category="Document Quality",
                message="Tracked changes detected and stripped from extraction")]
        return []

    def _check_inline_annotations(self, schema) -> List[QCIssue]:
        n = schema.inline_annotations_count
        if n > 0:
            return [QCIssue(severity=QCSeverity.INFO, category="ADaM Annotations",
                message=f"{n} inline ADaM annotations extracted (ADSL.FLAG='Y' patterns)")]
        return []

    def _check_population_dataset_alignment(self, schema) -> List[QCIssue]:
        """Part J: PK outputs should use PKFL, safety → SAFFL, etc."""
        issues = []
        CLASS_POP = {"PK":"PK","Safety":"SAF","Immunogenicity":"IMMU","ECG":"SAF"}
        for o in schema.outputs_master:
            expected_pop = CLASS_POP.get(o.output_class.value)
            if expected_pop and o.population:
                actual = o.population.abbreviation
                if actual not in (expected_pop, "SAF", "ENRL", "FAS"):
                    issues.append(QCIssue(severity=QCSeverity.WARNING,
                        category="Population-Class Mismatch", output_id=o.output_id,
                        message=f"{o.output_type.value} {o.output_number}: "
                                f"class='{o.output_class.value}' but population='{actual}' "
                                f"(expected ~{expected_pop})",
                        auto_fixable=False))
        return issues

    def _check_analysis_method_dataset_mismatch(self, schema) -> List[QCIssue]:
        """Part J: MMRM requires repeated-measures dataset; Cox requires ADTTE."""
        issues = []
        METHOD_DS = {
            "MMRM":              ["ADEFF","ADLB","ADVS","ADRS"],
            "Kaplan-Meier":      ["ADTTE"],
            "Cox Proportional Hazards":["ADTTE"],
            "NCA":               ["ADPC","ADPP"],
            "Population PK":     ["ADPC"],
        }
        for o in schema.outputs_master:
            if not o.analysis or not o.data_specification: continue
            for method in o.analysis.methods:
                expected_ds = METHOD_DS.get(method)
                if expected_ds:
                    actual_ds = o.data_specification.input_datasets
                    if not any(d in actual_ds for d in expected_ds):
                        issues.append(QCIssue(severity=QCSeverity.WARNING,
                            category="Method-Dataset Mismatch", output_id=o.output_id,
                            message=f"Method '{method}' but dataset is {actual_ds} "
                                    f"(expected one of {expected_ds})",
                            suggested_fix=f"Verify dataset for {method} analysis"))
        return issues

    def _check_estimand_completeness(self, schema) -> List[QCIssue]:
        """Part J: Phase 3 primary endpoints need all 5 ICH E9(R1) estimand attributes."""
        issues = []
        meta = schema.study_metadata
        if meta.phase not in ("3","2/3","3B","3A","PHASE 3"): return issues
        for ep in schema.endpoints:
            if ep.classification != "Primary": continue
            if not ep.estimand:
                issues.append(QCIssue(severity=QCSeverity.WARNING,
                    category="Estimand Completeness", output_id=ep.endpoint_id,
                    message=f"Phase 3 primary endpoint missing ICH E9(R1) estimand definition",
                    suggested_fix="Define all 5 estimand attributes: population, variable, "
                                  "summary measure, intercurrent events, missing data handling"))
        return issues

    def _check_adam_spec(self, schema) -> List[QCIssue]:
        issues = []
        if schema.adam_spec_registry:
            n_ds = len(schema.adam_spec_registry.datasets)
            n_var = sum(len(d.variables) for d in schema.adam_spec_registry.datasets.values())
            issues.append(QCIssue(severity=QCSeverity.INFO, category="ADaM Spec",
                message=f"ADaM spec loaded: {n_ds} datasets, {n_var} variables — "
                        f"dataset inference enhanced"))
        else:
            issues.append(QCIssue(severity=QCSeverity.INFO, category="ADaM Spec",
                message="No ADaM spec Excel loaded — upload ADAM_SPEC.xlsx for enhanced accuracy",
                suggested_fix="Upload ADaM spec via optional ADaM Excel input"))
        return issues

    def _check_flag_defaults(self, schema) -> List[QCIssue]:
        """Restored from v3.1: warn that flag names may be defaults."""
        issues = []
        for pop in schema.populations:
            if getattr(pop, 'flag_verification_required', True):
                if pop.adam_flag_variable and not pop.formal_definition:
                    issues.append(QCIssue(severity=QCSeverity.INFO,
                        category="Flag Verification",
                        message=f"Population '{pop.abbreviation}': flag '{pop.adam_flag_variable}' "
                                f"is a default — verify against study ADaM spec",
                        auto_fixable=False))
        return issues
