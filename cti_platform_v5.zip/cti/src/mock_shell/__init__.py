"""
Mock shell parser: extracts table structure (columns, rows, footnotes,
treatment arms, visits) from SAP shell tables.
"""
from __future__ import annotations

import re
from typing import List, Optional

from src.models.schema import MockShell, MockShellColumn, MockShellRow
from src.parsers import ParsedDocument, ParsedTable
from src.utils import clean_text, get_logger, truncate

logger = get_logger(__name__)

# Patterns for detecting column content types
_FORMAT_PATTERNS = {
    "count": re.compile(r"\bN\b|\bcount\b|\bn\b", re.IGNORECASE),
    "percentage": re.compile(r"%|percent", re.IGNORECASE),
    "mean": re.compile(r"\bmean\b|\baverage\b", re.IGNORECASE),
    "sd": re.compile(r"\bSD\b|\bstd\b|\bstandard\s+deviation\b", re.IGNORECASE),
    "median": re.compile(r"\bmedian\b", re.IGNORECASE),
    "range": re.compile(r"\brange\b|\bmin\b.{0,10}\bmax\b", re.IGNORECASE),
    "ci": re.compile(r"CI|confidence\s+interval", re.IGNORECASE),
    "pvalue": re.compile(r"p.?value|p\b", re.IGNORECASE),
    "lsmean": re.compile(r"LS\s*[Mm]ean|least\s+squares\s+mean", re.IGNORECASE),
}

_FOOTNOTE_MARKERS = re.compile(r"^[a-zA-Z\d]{1,2}[.)\]]|^\*+|^Note\s*:|^[a-z] [A-Za-z]")
_TREATMENT_INDICATORS = re.compile(r"placebo|active|treatment|drug|dose|mg|mcg|mg/kg", re.IGNORECASE)
_VISIT_INDICATORS = re.compile(r"week\s+\d+|day\s+\d+|month\s+\d+|baseline|screening|eot", re.IGNORECASE)


class MockShellParser:
    """Parse mock shell tables from parsed document tables."""

    def parse_all(self, document: ParsedDocument, output_ids: List[str]) -> List[MockShell]:
        """Parse all tables in document as mock shells."""
        shells: List[MockShell] = []
        for i, table in enumerate(document.tables):
            if table.num_rows < 2 or table.num_cols < 2:
                continue
            shell = self._parse_table(table, f"shell_{i:04d}")
            if shell.columns:
                shells.append(shell)
        return shells

    def parse_for_output(
        self,
        table: ParsedTable,
        table_id: str
    ) -> Optional[MockShell]:
        """Parse a single table as a mock shell."""
        if table.num_rows < 2 or table.num_cols < 2:
            return None
        return self._parse_table(table, table_id)

    def _parse_table(self, table: ParsedTable, table_id: str) -> MockShell:
        rows = table.rows
        if not rows:
            return MockShell(table_id=table_id, parse_confidence=0.0)

        # Detect header row(s)
        header_rows, body_rows, footnote_rows = self._split_rows(rows)

        columns = self._extract_columns(header_rows)
        data_rows = self._extract_rows(body_rows)
        footnotes = self._extract_footnotes(footnote_rows)
        visits = self._detect_visits(rows)
        treatment_arms = self._detect_treatment_arms(rows)
        spanning = self._detect_spanning_headers(header_rows)

        # Parse confidence
        confidence = self._compute_confidence(columns, data_rows, footnotes)

        return MockShell(
            table_id=table_id,
            columns=columns,
            rows=data_rows,
            visits=visits,
            treatment_arms=treatment_arms,
            spanning_headers=spanning,
            footnotes=footnotes,
            raw_text=truncate(str(rows), 500),
            parse_confidence=confidence,
        )

    @staticmethod
    def _split_rows(
        rows: List[List[str]]
    ):
        """Heuristically split table rows into header, body, footnotes."""
        if not rows:
            return [], [], []

        footnote_start = len(rows)
        for i, row in enumerate(rows):
            first_cell = row[0].strip() if row else ""
            if _FOOTNOTE_MARKERS.match(first_cell) or first_cell.lower().startswith("note"):
                footnote_start = i
                break

        body_rows = rows[:footnote_start]
        footnote_rows = rows[footnote_start:]

        # Detect header rows: usually first 1-2 rows with no numeric content
        header_count = 0
        for row in body_rows[:3]:
            all_text = all(not re.search(r"\d{2,}", cell) for cell in row)
            if all_text:
                header_count += 1
            else:
                break

        header_count = max(1, header_count)
        return body_rows[:header_count], body_rows[header_count:], footnote_rows

    @staticmethod
    def _extract_columns(header_rows: List[List[str]]) -> List[MockShellColumn]:
        if not header_rows:
            return []

        # Use last header row for column headers
        headers = header_rows[-1] if len(header_rows) >= 1 else header_rows[0]
        columns: List[MockShellColumn] = []

        for i, header in enumerate(headers):
            header = clean_text(header)
            if not header:
                header = f"Column {i + 1}"

            # Detect data type
            dtype = "string"
            format_mask = None
            for fmt_name, pattern in _FORMAT_PATTERNS.items():
                if pattern.search(header):
                    dtype = fmt_name
                    if fmt_name in ("count",):
                        format_mask = "NNN"
                    elif fmt_name == "percentage":
                        format_mask = "xx.x%"
                    elif fmt_name in ("mean", "lsmean"):
                        format_mask = "xx.x (xx.x)"
                    elif fmt_name == "pvalue":
                        format_mask = "x.xxxx"
                    elif fmt_name == "ci":
                        format_mask = "(xx.x, xx.x)"
                    break

            alignment = "right" if dtype != "string" else "left"
            columns.append(MockShellColumn(
                position=i + 1,
                header=header,
                alignment=alignment,
                format_mask=format_mask,
                data_type=dtype,
            ))
        return columns

    @staticmethod
    def _extract_rows(body_rows: List[List[str]]) -> List[MockShellRow]:
        rows: List[MockShellRow] = []
        for i, row in enumerate(body_rows):
            if not row or not any(cell.strip() for cell in row):
                continue
            label = clean_text(row[0]) if row else f"Row {i + 1}"
            # Detect indent from leading spaces or bullet
            indent = 0
            if row[0].startswith("    "):
                indent = 1
            elif row[0].startswith("        "):
                indent = 2

            is_header = bool(re.match(r"^[A-Z][A-Z\s]{3,}$", label))
            is_total = bool(re.search(r"\btotal\b|\boverall\b|\ball\b", label, re.IGNORECASE))

            rows.append(MockShellRow(
                position=i + 1,
                label=label,
                indent_level=indent,
                is_header=is_header,
                is_total=is_total,
            ))
        return rows

    @staticmethod
    def _extract_footnotes(footnote_rows: List[List[str]]) -> List[str]:
        footnotes: List[str] = []
        for row in footnote_rows:
            combined = " ".join(cell.strip() for cell in row if cell.strip())
            if combined:
                footnotes.append(clean_text(combined))
        return footnotes

    @staticmethod
    def _detect_visits(rows: List[List[str]]) -> List[str]:
        visits: set = set()
        for row in rows:
            for cell in row:
                matches = _VISIT_INDICATORS.findall(cell)
                for m in matches:
                    visits.add(m.strip().title())
        return sorted(visits)

    @staticmethod
    def _detect_treatment_arms(rows: List[List[str]]) -> List[str]:
        arms: set = set()
        for row in rows:
            for cell in row:
                if _TREATMENT_INDICATORS.search(cell) and len(cell.strip()) < 60:
                    arms.add(clean_text(cell))
        return sorted(arms)

    @staticmethod
    def _detect_spanning_headers(header_rows: List[List[str]]) -> List[dict]:
        if len(header_rows) < 2:
            return []
        spanning = []
        first_row = header_rows[0]
        for i, cell in enumerate(first_row):
            if cell.strip():
                spanning.append({"text": clean_text(cell), "col_index": i})
        return spanning

    @staticmethod
    def _compute_confidence(
        columns: List[MockShellColumn],
        rows: List[MockShellRow],
        footnotes: List[str]
    ) -> float:
        score = 0.0
        if columns:
            score += 0.40
        if rows:
            score += 0.30
        if len(columns) >= 3:
            score += 0.10
        if footnotes:
            score += 0.10
        any_format = any(c.format_mask for c in columns)
        if any_format:
            score += 0.10
        return min(1.0, score)
