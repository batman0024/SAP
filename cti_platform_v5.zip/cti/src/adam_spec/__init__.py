"""
CTI v5 — ADaM Spec Excel Parser (Part A from PDF spec)
Parses CDISC ADaM spec Excel files. Auto-detects format.
"""
from __future__ import annotations
import re
from pathlib import Path
from typing import Any, Dict, List, Optional
from src.models.schema import ADaMVariable, ADaMDatasetSpec, ADaMSpecRegistry, ExtractedRule, RuleType
from src.utils import get_logger, clean_text, truncate
logger = get_logger(__name__)

_COL_SYNONYMS = {
    "dataset":    ["dataset","domain","data set"],
    "variable":   ["variable name","var name","variable","var","field name"],
    "label":      ["variable label","label","description"],
    "type":       ["type","data type","variable type","dtype","sas type"],
    "length":     ["length","var length","sas length"],
    "format":     ["format","display format","sas format"],
    "origin":     ["origin","derivation type","source"],
    "derivation": ["derivation","derivation algorithm","rule","computation method",
                   "derivation/comment","algorithm","mapping rule"],
    "core":       ["core","required/expected/permissible","r/e/p"],
    "codelist":   ["codelist","controlled terms","code list name"],
    "sdtm_source":["sdtm variable","source variable","input variable","input variables"],
    "key_seq":    ["key seq","key sequence"],
}
_VAR_RULE_TYPE = {
    "BASE":"baseline_definition","ABLFL":"flag","CHG":"derivation","PCHG":"derivation",
    "CNSR":"censoring","TRTEMFL":"flag","ANL01FL":"flag","ONTRTFL":"flag",
    "DTYPE":"missing_data","ADY":"study_day","TRTSDT":"derivation",
    "AVAL":"derivation","PARAMCD":"derivation","ARELTM":"pk_rule","LLOQ":"pk_rule",
}

class ADaMSpecExcelParser:
    def parse(self, file_path: Path) -> ADaMSpecRegistry:
        logger.info("Parsing ADaM spec: %s", file_path.name)
        try:
            import openpyxl
            wb = openpyxl.load_workbook(str(file_path), read_only=True, data_only=True)
        except Exception as exc:
            logger.error("ADaM spec parse error: %s", exc)
            return ADaMSpecRegistry(file_name=file_path.name)
        
        registry = ADaMSpecRegistry(file_name=file_path.name)
        fmt = self._detect_format(wb)
        
        for ws_name in wb.sheetnames:
            ws = wb[ws_name]
            ds_name = ws_name.upper().strip()
            if ds_name in ("STUDY","STANDARDS","TOC","CODELIST","CODELISTS","COVER",
                           "INSTRUCTIONS","README","COMPUTATION","<DS>","ADADA"):
                continue
            rows = list(ws.iter_rows(values_only=True))
            if not rows: continue
            hdr_idx = self._find_header(rows)
            if hdr_idx is None: continue
            col_map = self._map_cols([str(c or "") for c in rows[hdr_idx]])
            if "variable" not in col_map: continue
            
            for row in rows[hdr_idx+1:]:
                ds = (str(row[col_map["dataset"]] or "").strip().upper()
                      if "dataset" in col_map else ds_name)
                if not ds: ds = ds_name
                var = self._parse_row(row, col_map, ds)
                if var and var.variable:
                    spec = registry.datasets.setdefault(ds, ADaMDatasetSpec(dataset=ds))
                    spec.variables.append(var)
                    registry.variable_index.setdefault(var.variable, []).append(ds)
        
        for ds_spec in registry.datasets.values():
            for var in ds_spec.variables:
                if var.derivation_text and len(var.derivation_text) > 10:
                    registry.derivation_rules.append(
                        f"{ds_spec.dataset}.{var.variable}: {var.derivation_text[:200]}"
                    )
        logger.info("ADaM spec: %d datasets, %d variables",
                    len(registry.datasets), sum(len(d.variables) for d in registry.datasets.values()))
        return registry

    def _detect_format(self, wb) -> str:
        ds_sheets = sum(1 for n in wb.sheetnames if re.match(r"^AD[A-Z]{1,6}$", n.upper().strip()))
        return "per_dataset" if ds_sheets >= 2 else "multi_dataset"

    def _find_header(self, rows: list) -> Optional[int]:
        for i, row in enumerate(rows[:15]):
            cells = [str(c or "").lower().strip() for c in row]
            if any(kw in cells for kw in ["variable","variable name","var name","field name"]):
                return i
        return None

    def _map_cols(self, headers: List[str]) -> Dict[str, int]:
        result: Dict[str, int] = {}
        lower = [h.lower().strip() for h in headers]
        for fname, synonyms in _COL_SYNONYMS.items():
            for syn in synonyms:
                if syn in lower:
                    result[fname] = lower.index(syn)
                    break
        return result

    def _parse_row(self, row: tuple, col_map: Dict[str, int], ds: str) -> Optional[ADaMVariable]:
        def get(f):
            idx = col_map.get(f)
            if idx is None or idx >= len(row): return ""
            return clean_text(str(row[idx] or ""))
        vname = get("variable").upper().strip()
        if not vname or vname in ("VARIABLE","VARIABLE NAME","VAR","FIELD NAME"): return None
        var = ADaMVariable(
            dataset=ds, variable=vname,
            label=get("label"), type=get("type") or "Char",
            origin=get("origin") or "Derived",
            derivation_text=get("derivation"),
            core=get("core") or "Expected",
            codelist=get("codelist") or None,
        )
        try:
            l = get("length")
            if l: var.length = int(l)
        except: pass
        if get("format"): var.format = get("format")
        sdtm = get("sdtm_source")
        if sdtm: var.sdtm_source = [s.strip() for s in re.split(r"[,;]", sdtm) if s.strip()]
        try:
            ks = get("key_seq")
            if ks: var.key_sequence = int(ks)
        except: pass
        return var

    def parse_derivation_to_rule(self, derivation_text: str, variable: str, dataset: str) -> Optional[ExtractedRule]:
        if not derivation_text or len(derivation_text) < 5: return None
        from src.models.schema import RuleType as RT
        rt_map = {k: getattr(RT, v.upper(), RT.DERIVATION) for k,v in _VAR_RULE_TYPE.items()}
        rule_type = rt_map.get(variable, RT.DERIVATION)
        return ExtractedRule(
            rule_type=rule_type,
            rule_text_verbatim=truncate(derivation_text, 300),
            pseudocode=derivation_text.strip() if "=" in derivation_text and len(derivation_text)<200 else None,
            applies_to_datasets=[dataset], applies_to_variables=[variable],
            confidence=0.95, validated=True,
        )
