"""
CTI v5 Rule Engine — 12 new patterns from Part D + restored v3.1 patterns.
Also now actually uses PK_PARAMETER_PATTERNS and STUDY_DAY_PATTERNS (dead code fixed).
Table-based rule extraction for censoring + date imputation tables.
"""
from __future__ import annotations
import re, uuid
from dataclasses import dataclass, field
from typing import List, Optional, Tuple
from src.models.schema import ExtractedRule, RuleType
from src.parsers import ParsedDocument, ParsedTable
from src.utils import (
    DATE_IMPUTATION_PATTERNS, CENSORING_PATTERNS, STUDY_DAY_PATTERNS,
    PK_PARAMETER_PATTERNS, clean_text, get_logger, truncate, compute_confidence,
)
logger = get_logger(__name__)


@dataclass
class RulePattern:
    pattern: str
    rule_type: RuleType
    description: str
    confidence_base: float = 0.80
    adam_variables: List[str] = field(default_factory=list)
    datasets: List[str] = field(default_factory=list)
    pseudocode: Optional[str] = None


RULE_PATTERNS: List[RulePattern] = [
    # Baseline
    RulePattern(
        pattern=r"baseline.{0,60}last\s+non.missing\s+(?:value|assessment|observation)\s+prior\s+to",
        rule_type=RuleType.BASELINE_DEFINITION, description="Baseline: last non-missing pre-dose",
        adam_variables=["BASE","ABLFL","BASETYPE"], datasets=["ADLB","ADVS","ADRS","ADEFF"],
        pseudocode="if ABLFL = 'Y' then BASE = AVAL;", confidence_base=0.95,
    ),
    RulePattern(
        pattern=r"baseline.{0,30}(?:pre.dose|predose).{0,50}(?:Day\s*1|first\s+dose)",
        rule_type=RuleType.BASELINE_DEFINITION, description="Baseline: pre-dose Day 1",
        adam_variables=["BASE","ABLFL"], datasets=["ADLB","ADVS"],
        pseudocode="/* select pre-dose record on Day 1 */", confidence_base=0.90,
    ),
    # Visit windows
    RulePattern(
        pattern=r"(?:visit\s+)?window.{0,50}(?:week|day|cycle)\s+(\d+).{0,60}(?:day|week)\s+(\d+)\s+to\s+(?:day|week)\s+(\d+)",
        rule_type=RuleType.VISIT_WINDOW, description="Visit window definition",
        adam_variables=["AVISIT","AVISITN","ADT"], datasets=["ADLB","ADEFF"],
        pseudocode="if nominal-pre <= ADT <= nominal+post then AVISIT = 'WEEK N';",
        confidence_base=0.90,
    ),
    RulePattern(
        pattern=r"multiple.{0,60}(?:records|assessments).{0,80}(?:closest|nearest)\s+to\s+(?:the\s+)?nominal",
        rule_type=RuleType.VISIT_WINDOW, description="Multiple records: use closest to nominal",
        adam_variables=["ADT","AVISITN","DTYPE"],
        pseudocode="/* min(|ADT - nominal|); if tie use closest_to_nominal rule */",
        confidence_base=0.87,
    ),
    # Filters
    RulePattern(
        pattern=r"(?:ITT|FAS|safety|per.protocol|all\s+enrolled|DLT|PK|immunogenicity).{0,60}(?:analysis\s+)?set.{0,60}([A-Z]{2,8}FL)\s*=\s*['\"]?Y",
        rule_type=RuleType.FILTER, description="Population flag filter",
        adam_variables=["ITTFL","SAFFL","FASFL","PKFL","DLTFL"],
        pseudocode="where FLAGFL = 'Y';", confidence_base=0.95,
    ),
    # Derivations
    RulePattern(
        pattern=r"change\s+from\s+baseline.{0,30}(?:CHG\s*=\s*AVAL\s*-\s*BASE|AVAL\s*-\s*BASE|calculated\s+as)",
        rule_type=RuleType.DERIVATION, description="CHG = AVAL - BASE",
        adam_variables=["CHG","AVAL","BASE"], datasets=["ADEFF","ADLB","ADVS"],
        pseudocode="CHG = AVAL - BASE;", confidence_base=0.97,
    ),
    RulePattern(
        pattern=r"percent\s+change.{0,60}(?:PCHG|100\s*[*x]\s*(?:CHG\s*/\s*BASE|\(AVAL\s*-\s*BASE\)))",
        rule_type=RuleType.DERIVATION, description="PCHG = 100*(AVAL-BASE)/BASE",
        adam_variables=["PCHG","CHG","AVAL","BASE"],
        pseudocode="PCHG = 100 * (AVAL - BASE) / BASE; /* if BASE ne 0 */",
        confidence_base=0.93,
    ),
    RulePattern(
        pattern=r"PFS\s+in\s+months\s*=\s*\(Date\s+of\s+event.{0,80}\+\s*1\)\s*/\s*30",
        rule_type=RuleType.DERIVATION, description="PFS = (event date - first dose + 1)/30.4375",
        adam_variables=["AVAL","ADT","STARTDT"], datasets=["ADTTE"],
        pseudocode="AVAL = (ADT - STARTDT + 1) / 30.4375;", confidence_base=0.95,
    ),
    # Flags
    RulePattern(
        pattern=r"ANL0\dFL\s*=\s*['\"]?Y['\"]?|primary\s+analysis\s+flag",
        rule_type=RuleType.FLAG, description="Primary analysis flag ANL0xFL",
        adam_variables=["ANL01FL","ANL02FL"],
        pseudocode="if ITTFL='Y' and AVISITN in (...) and DTYPE='' then ANL01FL='Y';",
        confidence_base=0.93,
    ),
    RulePattern(
        pattern=r"ABLFL\s*=\s*['\"]?Y['\"]?|baseline\s+record\s+flag",
        rule_type=RuleType.FLAG, description="Baseline record flag ABLFL",
        adam_variables=["ABLFL"],
        pseudocode="if ADT <= TRTSDT and AVAL ne . then ABLFL='Y';", confidence_base=0.93,
    ),
    RulePattern(
        pattern=r"(?:treatment.emergent|TEAE).{0,60}(?:onset|start).{0,60}(?:on\s+or\s+after\s+first\s+dose|TRTSDT|TRTEMFL)",
        rule_type=RuleType.FLAG, description="TRTEMFL: treatment-emergent AE flag",
        adam_variables=["TRTEMFL"], datasets=["ADAE"],
        pseudocode="if ASTDT >= TRTSDT then TRTEMFL='Y';", confidence_base=0.92,
    ),
    # Missing data
    RulePattern(
        pattern=r"(?:LOCF|last\s+observation\s+carried\s+forward)",
        rule_type=RuleType.MISSING_DATA, description="LOCF imputation",
        adam_variables=["DTYPE","AVAL"],
        pseudocode="if DTYPE='LOCF' then AVAL = (last observed AVAL);", confidence_base=0.92,
    ),
    RulePattern(
        pattern=r"(?:BOCF|baseline\s+observation\s+carried\s+forward)",
        rule_type=RuleType.MISSING_DATA, description="BOCF imputation",
        adam_variables=["DTYPE","AVAL","BASE"],
        pseudocode="if DTYPE='BOCF' then AVAL=BASE;", confidence_base=0.92,
    ),
    RulePattern(
        pattern=r"multiple\s+imputation.{0,80}(?:\d+|1000|500)\s+imputation",
        rule_type=RuleType.MISSING_DATA, description="Multiple Imputation (MI)",
        adam_variables=["DTYPE","AVAL"],
        pseudocode="/* proc mi / proc mianalyze; MAR assumption */", confidence_base=0.88,
    ),
    # Study day
    RulePattern(
        pattern=r"[Dd]ay\s+1\s*=\s*(?:first\s+)?dose|[Dd]ate\s+of\s+first\s+dose\s*=\s*Day\s+1",
        rule_type=RuleType.STUDY_DAY, description="Day 1 = first dose date",
        adam_variables=["ADY","TRTSDT"],
        pseudocode="ADY = ADT - TRTSDT + 1; /* if ADT >= TRTSDT */", confidence_base=0.90,
    ),
    # PK
    RulePattern(
        pattern=r"BLoQ|[Bb]elow\s+(?:the\s+)?[Ll]imit\s+of\s+[Qq]uantification",
        rule_type=RuleType.PK_RULE, description="BLoQ handling rule",
        adam_variables=["DTYPE","AVAL","LLOQ"], datasets=["ADPC","ADPK"],
        pseudocode="if AVAL < LLOQ then AVAL = LLOQ/2; /* or 0 for predose */",
        confidence_base=0.88,
    ),
    # ── Part D: 12 NEW RULE PATTERNS ────────────────────────────────────────────
    # D-1: TRTSDT
    RulePattern(
        pattern=r"(?:treatment\s+start|first\s+dose)\s+date.{0,50}(?:TRTSDT|EX\.EXSTDTC|EXSTDTC)",
        rule_type=RuleType.DERIVATION,
        description="TRTSDT: treatment start date from EX domain",
        adam_variables=["TRTSDT","TRTSDT"], datasets=["ADSL"],
        pseudocode="TRTSDT = min(EXSTDTC) where EXDOSE > 0; /* from EX domain */",
        confidence_base=0.93,
    ),
    # D-2: LDRELD / last dose
    RulePattern(
        pattern=r"last\s+(?:dose|administration).{0,50}date.{0,30}(?:LDRELD|TRTEDTM|EXENDTC)",
        rule_type=RuleType.DERIVATION,
        description="LDRELD: last dose date from EX",
        adam_variables=["LDRELD","TRTEDTM"], datasets=["ADSL"],
        pseudocode="LDRELD = max(EXENDTC) where EXDOSE > 0; /* last dose from EX */",
        confidence_base=0.90,
    ),
    # D-3: EOSSTT
    RulePattern(
        pattern=r"(?:EOSSTT|end\s+of\s+study\s+status|completion\s+status).{0,80}(?:completed|discontinued|withdrawn)",
        rule_type=RuleType.DISPOSITION,
        description="EOSSTT: end of study completion status",
        adam_variables=["EOSSTT","DCSREAS","DTHFL"], datasets=["ADSL"],
        pseudocode="/* from DS where DSCAT='DISPOSITION EVENT' */",
        confidence_base=0.88,
    ),
    # D-4: PARAMCD
    RulePattern(
        pattern=r"PARAMCD\s*=\s*['\"]?([A-Z0-9]{1,8})['\"]?|parameter\s+code.{0,30}['\"]([A-Z0-9]{1,8})['\"]",
        rule_type=RuleType.DERIVATION,
        description="PARAMCD: analysis parameter code",
        adam_variables=["PARAMCD","PARAM","PARAMN"], datasets=["ADLB","ADVS","ADEFF","ADRS"],
        pseudocode="PARAMCD = LBTESTCD; PARAM = LBTEST; /* map from SDTM */",
        confidence_base=0.91,
    ),
    # D-5: DTYPE
    RulePattern(
        pattern=r"(?:DTYPE|record\s+type).{0,60}(?:LOCF|BOCF|WOCF|imputed|supplementary|unscheduled|AVERAGE)",
        rule_type=RuleType.FLAG,
        description="DTYPE: record type for supplementary/imputed records",
        adam_variables=["DTYPE"], datasets=["ADLB","ADVS","ADEFF"],
        pseudocode="DTYPE='' for original; 'LOCF'/'BOCF' for imputed; 'UNSCHEDULED' for unplanned;",
        confidence_base=0.90,
    ),
    # D-6: ONTRTFL
    RulePattern(
        pattern=r"(?:ONTRTFL|on.treatment\s+flag|on\s+treatment).{0,80}(?:TRTSDT|TRTEDTM|first\s+dose)",
        rule_type=RuleType.FLAG,
        description="ONTRTFL: on-treatment period flag",
        adam_variables=["ONTRTFL","TRTSDT","TRTEDTM"], datasets=["ADLB","ADVS","ADAE"],
        pseudocode="if TRTSDT <= ADT <= TRTEDTM then ONTRTFL='Y'; else ONTRTFL='';",
        confidence_base=0.90,
    ),
    # D-7: Stratification factors
    RulePattern(
        pattern=r"stratif(?:ication|ied).{0,80}(?:factor|variable|STRATCD|region|age|sex|prior)",
        rule_type=RuleType.DERIVATION,
        description="Stratification factor variables for stratified analyses",
        adam_variables=["STRATCD","STRAT1","STRAT2","STR01","STR02"], datasets=["ADSL"],
        pseudocode="/* From randomisation system; stratification factors in ADSL */",
        confidence_base=0.87,
    ),
    # D-8: Response rate
    RulePattern(
        pattern=r"(?:responder|response\s+rate|ORR|DCR|CR\s+rate).{0,80}(?:AVALC|AVAL|RSSTRESC|CR|PR)",
        rule_type=RuleType.DERIVATION,
        description="Response: AVALC categorical, AVAL=1 for binary responder",
        adam_variables=["AVAL","AVALC","RSSTRESC"], datasets=["ADRS"],
        pseudocode="AVALC=RSSTRESC; AVAL=(RSSTRESC in ('CR','PR')); /* for ORR */",
        confidence_base=0.89,
    ),
    # D-9: Subgroup flag
    RulePattern(
        pattern=r"subgroup.{0,80}(?:analysis|population|defined\s+as|flag|SUBGRP)",
        rule_type=RuleType.FLAG,
        description="Subgroup analysis: SUBGRPFL or by-variable",
        adam_variables=["SUBGRPFL","AGEGR1","SEXN","RACEN","REGION1"], datasets=["ADSL"],
        pseudocode="/* Subgroup variables derived in ADSL from demographics */",
        confidence_base=0.82,
    ),
    # D-10: Relative dose intensity
    RulePattern(
        pattern=r"(?:relative\s+dose\s+intensity|RDI|dose\s+intensity).{0,80}(?:EXDOSE|cumulative|planned)",
        rule_type=RuleType.EXPOSURE,
        description="RDI = actual cumulative dose / planned cumulative dose * 100",
        adam_variables=["AVAL","EXDOSE","PLNDOSE"], datasets=["ADEX"],
        pseudocode="RDI = (sum(EXDOSE) / planned_dose) * 100;",
        confidence_base=0.88,
    ),
    # D-11: Multiple testing correction
    RulePattern(
        pattern=r"(?:Hochberg|Bonferroni|Holm|Benjamini|Westfall|gatekeeping).{0,80}(?:correction|procedure|alpha|type\s+I)",
        rule_type=RuleType.MULTIPLICITY,
        description="Multiple testing procedure: adjusted p-values",
        adam_variables=["AVAL","PROBT","ADJP"], datasets=["ADEFF"],
        pseudocode="/* proc multtest or manual Hochberg step-up; alpha=0.05 family */",
        confidence_base=0.88,
    ),
    # D-12: No post-baseline assessment censoring
    RulePattern(
        pattern=r"no\s+(?:adequate\s+)?(?:post.?baseline|tumor)\s+assessment.{0,80}(?:censored|censor|first\s+dose)",
        rule_type=RuleType.CENSORING,
        description="No post-baseline assessment: censored at first dose (CNSR=1, ADT=TRTSDT)",
        adam_variables=["CNSR","ADT","TRTSDT"], datasets=["ADTTE"],
        pseudocode="if no_postbase_assess then CNSR=1; ADT=TRTSDT;",
        confidence_base=0.91,
    ),
]


class RuleEngine:
    def __init__(self, confidence_threshold: float = 0.65):
        self.threshold = confidence_threshold

    def extract_all(self, document: ParsedDocument) -> List[ExtractedRule]:
        rules: List[ExtractedRule] = []
        seen: set = set()

        for sec in document.sections:
            text = sec.get_text()
            if not text: continue
            rules.extend(self._from_text(text, sec.section_id, sec.page_start))
            for tbl in sec.tables:
                rules.extend(self._from_table(tbl, sec.section_id, sec.page_start))

        # ADaM inline annotations → filter rules (from parser)
        for ann in document.all_adam_annotations:
            m = re.match(r"(ADSL?\.)?([A-Z]{2,12}FL)\s*=\s*['\"]?Y", ann, re.IGNORECASE)
            if m:
                flag = m.group(2).upper()
                rules.append(ExtractedRule(
                    rule_type=RuleType.INLINE_ANNOTATION,
                    rule_text_verbatim=ann,
                    rule_logic_structured={"flag": flag, "value": "Y"},
                    pseudocode=f"where {flag} = 'Y';",
                    applies_to_variables=[flag], applies_to_datasets=["ADSL"],
                    confidence=0.92,
                ))

        # Deduplicate
        unique: List[ExtractedRule] = []
        for r in rules:
            key = r.rule_text_verbatim[:70].lower().strip()
            if key not in seen and r.confidence >= self.threshold:
                seen.add(key)
                unique.append(r)

        logger.info("Rules: %d unique", len(unique))
        return unique

    def _from_text(self, text: str, section_id: str, page: int) -> List[ExtractedRule]:
        rules = []
        for rp in RULE_PATTERNS:
            for m in re.finditer(rp.pattern, text, re.IGNORECASE | re.DOTALL):
                snippet = truncate(m.group(0), 250)
                conf = min(1.0, rp.confidence_base + min(0.05, len(m.group(0))/1000))
                rules.append(ExtractedRule(
                    rule_type=rp.rule_type,
                    rule_text_verbatim=snippet,
                    rule_logic_structured={"description": rp.description},
                    pseudocode=rp.pseudocode,
                    applies_to_datasets=rp.datasets,
                    applies_to_variables=rp.adam_variables,
                    confidence=conf, source_section=section_id, source_page=page,
                ))

        # Date imputation patterns (now actually used — fixed dead code)
        for pattern, description, variables in DATE_IMPUTATION_PATTERNS:
            for m in re.finditer(pattern, text, re.IGNORECASE | re.DOTALL):
                rules.append(ExtractedRule(
                    rule_type=RuleType.DATE_IMPUTATION,
                    rule_text_verbatim=truncate(m.group(0), 250),
                    rule_logic_structured={"description": description},
                    applies_to_variables=variables,
                    applies_to_datasets=["ADAE","ADEFF","ADLB"],
                    confidence=0.88, source_section=section_id, source_page=page,
                ))

        # Censoring patterns
        for pattern, description, variables in CENSORING_PATTERNS:
            for m in re.finditer(pattern, text, re.IGNORECASE | re.DOTALL):
                rules.append(ExtractedRule(
                    rule_type=RuleType.CENSORING,
                    rule_text_verbatim=truncate(m.group(0), 250),
                    rule_logic_structured={"description": description},
                    applies_to_variables=variables, applies_to_datasets=["ADTTE"],
                    confidence=0.87, source_section=section_id, source_page=page,
                ))

        # Study day patterns (fixed dead code — now actually iterated)
        for pattern, description in STUDY_DAY_PATTERNS:
            for m in re.finditer(pattern, text, re.IGNORECASE | re.DOTALL):
                rules.append(ExtractedRule(
                    rule_type=RuleType.STUDY_DAY,
                    rule_text_verbatim=truncate(m.group(0), 200),
                    rule_logic_structured={"description": description},
                    applies_to_variables=["ADY","TRTSDT"],
                    applies_to_datasets=["ADSL","ADLB","ADAE"],
                    confidence=0.88, source_section=section_id, source_page=page,
                ))

        # PK parameter patterns (fixed dead code — now actually iterated)
        for pattern, param_list in PK_PARAMETER_PATTERNS:
            for m in re.finditer(pattern, text, re.IGNORECASE):
                rules.append(ExtractedRule(
                    rule_type=RuleType.PK_RULE,
                    rule_text_verbatim=truncate(m.group(0), 150),
                    rule_logic_structured={"parameters": param_list},
                    applies_to_variables=param_list,
                    applies_to_datasets=["ADPP","ADPC"],
                    confidence=0.85, source_section=section_id, source_page=page,
                ))

        return rules

    def _from_table(self, tbl: ParsedTable, section_id: str, page: int) -> List[ExtractedRule]:
        rules = []
        if tbl.num_cols < 2: return rules
        hdr = [c.lower() for c in tbl.rows[0]] if tbl.rows else []
        has_outcome = any("outcome" in h or "censor" in h or "event" in h for h in hdr)
        has_date = any("date" in h or "imputation" in h for h in hdr)

        for row in tbl.rows[1:]:
            if not row or not any(c.strip() for c in row): continue
            row_text = " | ".join(c.strip() for c in row if c.strip())
            if has_outcome:
                outcome = row[1].strip() if len(row) > 1 else ""
                date_info = row[2].strip() if len(row) > 2 else ""
                situation = row[0].strip()
                if situation and (outcome or date_info):
                    cnsr_val = "0" if "event" in outcome.lower() else "1"
                    rules.append(ExtractedRule(
                        rule_type=RuleType.CENSORING,
                        rule_text_verbatim=truncate(row_text, 300),
                        rule_logic_structured={"situation": situation, "outcome": outcome,
                                               "date": date_info, "CNSR": cnsr_val},
                        pseudocode=f"/* {situation} → CNSR={cnsr_val}, ADT={date_info} */",
                        applies_to_variables=["CNSR","ADT","EVNTDESC"],
                        applies_to_datasets=["ADTTE"],
                        confidence=0.90, source_section=section_id, source_page=page,
                    ))
            elif has_date:
                rules.append(ExtractedRule(
                    rule_type=RuleType.DATE_IMPUTATION,
                    rule_text_verbatim=truncate(row_text, 300),
                    rule_logic_structured={"table_row": row_text},
                    applies_to_variables=["ASTDT","AENDT","ASTDTF","AENDTF"],
                    applies_to_datasets=["ADAE","ADCM"],
                    confidence=0.85, source_section=section_id, source_page=page,
                ))
        return rules
