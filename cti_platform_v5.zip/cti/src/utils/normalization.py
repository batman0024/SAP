"""
CTI v4 — Extended normalization maps.
v4 adds: DYNAMIC_POP_PATTERNS for non-standard populations (DLT, All Enrolled, Immunogenicity).
"""
from __future__ import annotations
from typing import Dict, List, Tuple

# ── Population maps (fixed canonical list) ────────────────────────────────────
POPULATION_NORMALIZATION: Dict[str, Tuple[str, str, int]] = {
    r"\bintent.to.treat\b|\bITT\b":                          ("Intent-to-Treat",        "ITT",  1),
    r"\bfull.analysis.set\b|\bFAS\b":                        ("Full Analysis Set",       "FAS",  1),
    r"\bmodified.intent.to.treat\b|\bmITT\b":                ("Modified Intent-to-Treat","mITT", 2),
    r"\bper.protocol\b|\bPP\b.{0,20}(?:population|set)":     ("Per Protocol",            "PP",   3),
    r"\bsafety\b.{0,20}(?:analysis\s+)?(?:set|population)|\bSAF\b": ("Safety",           "SAF",  2),
    r"\bpharmacokinetic\b|\bPK\b.{0,20}(?:analysis\s+)?(?:set|population)": ("Pharmacokinetic","PK",4),
    r"\bpharmacodyn|\bPD\b.{0,20}(?:analysis\s+)?(?:set|population)": ("Pharmacodynamic","PD",  4),
    r"\bevaluable\b":                                         ("Evaluable",              "EVAL", 5),
    r"\ball\s+enrolled\b|\bENRL\b":                           ("All Enrolled",            "ENRL", 1),
    r"\brandomized\b.{0,20}(?:set|population)|\bRAND\b":      ("Randomized",             "RAND", 1),
    r"\bbiomarker.evaluable\b|\bBME\b":                       ("Biomarker Evaluable",    "BME",  6),
    r"\bimmunogenicity\b.{0,20}(?:analysis\s+)?set":          ("Immunogenicity",         "IMMU", 5),
    r"\bdose.limiting\s+toxicity\b|\bDLT\b.{0,20}(?:analysis\s+)?set": ("DLT",           "DLT",  3),
    r"\bexploratory\b.{0,20}(?:analysis\s+)?set":             ("Exploratory",            "EXP",  6),
}

# NEW: Dynamic population patterns — detect ANY "X Analysis Set" / "X Population"
DYNAMIC_POP_PATTERNS = [
    r"(?:The\s+)?(?P<name>[A-Z][A-Za-z\s\-/]{3,50}?)\s+(?:Analysis\s+Set|Population)\s+(?:includes?|is\s+defined\s+as|consists?\s+of)\s+(?P<def>.{20,400}?)(?:\.|;|\n\n)",
    r"(?P<name>[A-Z][A-Za-z\s\-/]{3,40}?)\s+(?:Analysis\s+Set|Population)\s*\((?P<abbrev>[A-Z]{2,8})\)\s+(?:includes?|is|:)\s+(?P<def>.{15,400}?)(?:\.|;|\n)",
    r"(?P<abbrev>[A-Z]{2,8}FL)\s*=\s*['\"]?Y['\"]?\s+(?:for\s+)?(?P<name>[A-Za-z\s\-/]{5,50}?)(?:\.|;|\n)",
]

POPULATION_FLAG_MAP: Dict[str, str] = {
    "ITT":"ITTFL","FAS":"FASFL","mITT":"MITTFL","PP":"PPROTFL",
    "SAF":"SAFFL","PK":"PKFL","PD":"PDFL","EVAL":"EVALFL",
    "ENRL":"ENRLFL","RAND":"RANDFL","BME":"BMEFL",
    "IMMU":"IMMUNFL","DLT":"DLTFL","EXP":"EXPFL",
}
POPULATION_DATASET_MAP: Dict[str, str] = {k: "ADSL" for k in POPULATION_FLAG_MAP}

# ── Method normalization ───────────────────────────────────────────────────────
METHOD_NORMALIZATION: Dict[str, str] = {
    r"\bANCOVA\b|\banalysis\s+of\s+covariance\b": "ANCOVA",
    r"\bMMRM\b|\bmixed.model.repeat|\bmixed\s+model\s+for\s+repeated": "MMRM",
    r"\bmixed\s+effects?\s+model\b": "Mixed Effects Model",
    r"\blogistic\s+regression\b": "Logistic Regression",
    r"\bCox\s+(proportional\s+hazards?|regression)\b": "Cox Proportional Hazards",
    r"\bKaplan.Meier\b|\bKM\s+curve": "Kaplan-Meier",
    r"\bWilcoxon\b": "Wilcoxon Rank-Sum",
    r"\bCochran.Mantel.Haenszel\b|\bCMH\b": "CMH Test",
    r"\bFisher.s\s+exact\b": "Fisher's Exact Test",
    r"\bchi.square\b|\bchi2\b": "Chi-Square Test",
    r"\bt.test\b|\bstudent.s\s+t\b": "t-Test",
    r"\bANOVA\b(?!\s+model)": "ANOVA",
    r"\bmultiple\s+imputation\b|\bMI\b(?!\s+(?:population|set))": "Multiple Imputation",
    r"\bLOCF\b|\blast\s+observation\s+carried\s+forward": "LOCF",
    r"\bBOCF\b|\bbaseline\s+observation\s+carried\s+forward": "BOCF",
    r"\bNCA\b|\bnon.compartmental\s+analysis": "NCA",
    r"\bpopulation\s+PK\b|\bpopPK\b|\bNONMEM\b": "Population PK",
    r"\bdescriptive\s+statistics\b|\bsummar(?:y|ized)\s+descriptively\b": "Descriptive Statistics",
    r"\bExact\s+(?:binomial\s+)?CI\b|\bClopper.Pearson\b": "Exact Binomial CI",
}

# ── ADaM dataset hints ─────────────────────────────────────────────────────────
ADAM_DATASET_HINTS: Dict[str, List[str]] = {
    "ADSL":  ["demographics","disposition","baseline characteristics","subject level","enrollment","randomization"],
    "ADAE":  ["adverse event","AE","safety","toxicity","TEAE","SAE","DLT"],
    "ADLB":  ["laboratory","lab","hematology","chemistry","urinalysis","analyte"],
    "ADVS":  ["vital signs","blood pressure","heart rate","weight","BMI","ECG"],
    "ADEFF": ["efficacy","primary endpoint","symptom score","response","responder","change from baseline"],
    "ADTTE": ["time to event","time-to-event","survival","progression","relapse","death","PFS","OS","censoring"],
    "ADPK":  ["pharmacokinetic","PK","concentration","AUC","Cmax","half-life","NCA","serum","plasma"],
    "ADQS":  ["questionnaire","PRO","patient reported","quality of life","QoL","score","ECOG"],
    "ADCM":  ["concomitant medication","prior medication","rescue","treatment","regimen"],
    "ADEX":  ["exposure","dose","duration","compliance","relative dose intensity"],
    "ADIE":  ["immunogenicity","antibody","ADA","anti-drug"],
    "ADEG":  ["ECG","electrocardiogram","QT","QTcF","QTcB"],
    "ADPC":  ["PK concentration","serum concentration","plasma concentration","ADPC"],
    "ADPP":  ["PK parameter","AUClast","AUCinf","Cmax","NCA parameter"],
    "ADRS":  ["response","tumor response","ORR","CR","PR","PD","SD","RECIST"],
}

# ── Output class hints ────────────────────────────────────────────────────────
OUTPUT_CLASS_HINTS: Dict[str, List[str]] = {
    "Efficacy":        ["efficacy","primary","secondary","endpoint","responder","score","change from baseline","ORR","PFS","OS"],
    "Safety":          ["safety","adverse event","AE","TEAE","SAE","toxicity","death","discontinuation","DLT"],
    "Demographics":    ["demographic","baseline characteristic","age","sex","race","weight","medical history"],
    "Disposition":     ["disposition","discontinued","withdrawal","completion","enrolled","randomized"],
    "PK":              ["pharmacokinetic","PK","concentration","AUC","Cmax","NCA","dose proportionality"],
    "QoL":             ["quality of life","PRO","questionnaire","patient reported","QoL","ECOG"],
    "Biomarker":       ["biomarker","genomic","proteomic","marker"],
    "Subgroup":        ["subgroup","stratification","forest plot","by age","by sex","by region"],
    "Immunogenicity":  ["immunogenicity","antibody","ADA","anti-drug"],
    "ECG":             ["ECG","electrocardiogram","QT","QTcF","cardiac"],
    "Laboratory":      ["laboratory","lab","hematology","chemistry","urinalysis","liver","renal","Hy"],
    "Exposure":        ["exposure","dose intensity","compliance","duration","cumulative"],
}

# ── Rule patterns ─────────────────────────────────────────────────────────────
DATE_IMPUTATION_PATTERNS = [
    (r"partial.{0,30}start.{0,40}(?:day|DD).{0,20}01", "Partial start date: impute day as 01", ["ASTDT","ASTDTF"]),
    (r"partial.{0,30}end.{0,40}last\s+day\s+of\s+(?:the\s+)?month", "Partial end date: impute day as last day of month", ["AENDT","AENDTF"]),
    (r"(?:only\s+)?year.{0,30}(?:impute|set).{0,30}(?:January\s*1|01.01|Dec(?:ember)?\s*31)", "Year-only date imputation", ["ASTDT","AENDT","ASTDTF"]),
    (r"(?:ASTDTF|AENDTF|ADTF)\s*=\s*['\"]?([MDHY]+)['\"]?", "Date imputation flag", ["ASTDTF","AENDTF","ADTF"]),
    (r"imputed\s+date.{0,60}(?:after|min)\s*\(death\s+date", "Date imputation capped at death/cutoff", ["ASTDT","AENDT"]),
    (r"missing.{0,30}stop\s+date.{0,60}(?:ongoing|continuing)", "Missing stop date → ongoing", ["AENDT"]),
]

CENSORING_PATTERNS = [
    (r"(?:withdrew|withdrawal).{0,50}consent.{0,80}CNSR\s*=\s*1", "Withdrawal of consent: CNSR=1", ["CNSR","ADT"]),
    (r"lost.{0,30}follow.?up.{0,80}CNSR\s*=\s*1", "Lost to follow-up: CNSR=1", ["CNSR","ADT"]),
    (r"administrative.{0,30}(?:censoring|censor).{0,80}(?:data\s+cut|cutoff)", "Administrative censoring: CNSR=1", ["CNSR","ADT"]),
    (r"CNSR\s*=\s*0", "Event observed: CNSR=0", ["CNSR","ADT"]),
    (r"CNSR\s*=\s*1", "Censored observation: CNSR=1", ["CNSR","ADT"]),
    (r"competing.{0,40}event.{0,80}CNSR\s*=\s*1", "Competing event: CNSR=1", ["CNSR","ADT","EVNTDESC"]),
    (r"no\s+(?:adequate\s+)?(?:baseline|tumor)\s+assessment.{0,60}(?:censor|first\s+dose)", "No baseline assessment: censored at first dose", ["CNSR","ADT"]),
    (r"(?:new\s+)?anti.cancer\s+therapy.{0,80}(?:censor|initiation)", "New anti-cancer therapy censoring", ["CNSR","ADT"]),
    (r"PFS\s+in\s+months\s*=\s*\(Date\s+of\s+event", "PFS formula extraction", ["AVAL","CNSR","ADT"]),
]

STUDY_DAY_PATTERNS = [
    (r"Day\s+1\s*=\s*(?:first\s+)?dose|first\s+dose\s+(?:date\s+)?=\s*Day\s+1", "Day 1 = first dose convention"),
    (r"ADY\s*=\s*ADT\s*-\s*TRTSDT", "ADY derivation: ADY = ADT - TRTSDT"),
    (r"(?:treatment.emergent|TEAE).{0,60}(?:on\s+or\s+after\s+first\s+dose|TRTSDT)", "TEAE window definition"),
    (r"(?:30|60|90)\s+days?\s+after\s+(?:last\s+)?dose", "Post-dose follow-up window"),
]

PK_PARAMETER_PATTERNS = [
    (r"\bAUC(?:last|inf|tau|0.inf|0.t)\b", ["AUClast","AUCinf","AUCtau"]),
    (r"\bCmax\b", ["Cmax"]),
    (r"\bTmax\b", ["Tmax"]),
    (r"\bt(?:1/2|half)\b|\bhalf.life\b", ["t1/2"]),
    (r"\bCL/F\b|\bCL\b(?!\s+and)", ["CL/F"]),
    (r"\bVz/F\b|\bVd/F\b", ["Vz/F"]),
    (r"\bBLoQ\b|\bbelow\s+(?:the\s+)?limit\s+of\s+quantification", ["BLoQ"]),
    (r"\bLLOQ\b|\blower\s+limit\s+of\s+quantification", ["LLOQ"]),
]
