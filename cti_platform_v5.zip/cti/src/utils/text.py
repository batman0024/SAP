"""
Text processing utilities: cleaning, truncation, slugification.
All functions are pure/stateless — safe to import anywhere.
"""
from __future__ import annotations

import re
import unicodedata
from typing import Optional


def clean_text(text: str) -> str:
    """Normalize unicode, collapse whitespace, fix smart quotes."""
    if not isinstance(text, str):
        return ""
    text = unicodedata.normalize("NFKD", text)
    text = re.sub(r"[\u2018\u2019]", "'", text)
    text = re.sub(r"[\u201c\u201d]", '"', text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def truncate(text: str, max_chars: int = 300) -> str:
    """Truncate with ellipsis. Used for traceability storage — never for analysis."""
    if not text:
        return ""
    if len(text) <= max_chars:
        return text
    return text[:max_chars].rstrip() + "..."


def slugify(text: str) -> str:
    """Convert text to a safe lowercase identifier slug."""
    text = text.lower().strip()
    text = re.sub(r"[^\w\s-]", "", text)
    text = re.sub(r"[\s_-]+", "_", text)
    text = re.sub(r"^_|_$", "", text)
    return text or "unknown"


def normalize_output_number(raw: str) -> str:
    """Normalize output numbers like 'Table 14.1.1', '14.1.1', 'T14.1.1'."""
    raw = raw.strip()
    raw = re.sub(r"^(table|listing|figure|appendix)\s*", "", raw, flags=re.IGNORECASE)
    raw = re.sub(r"^[TLFA](?=\d)", "", raw)
    return raw.strip()


def extract_number_from_title(title: str) -> Optional[str]:
    """Extract table/listing/figure number from a title string."""
    patterns = [
        r"(?:Table|Listing|Figure|Appendix)\s+(\d+(?:\.\d+)*)",
        r"^(\d+(?:\.\d+)+)\s",
        r"[TLFA](\d+(?:\.\d+)+)",
    ]
    for pattern in patterns:
        match = re.search(pattern, title, re.IGNORECASE)
        if match:
            return match.group(1)
    return None


def compute_confidence(matches: int, total: int, base: float = 0.5) -> float:
    """
    Simple confidence estimator based on count of matched fields vs total possible.
    Returns value clamped to [0.0, 1.0].
    """
    if total <= 0:
        return max(0.0, min(1.0, base))
    ratio = matches / total
    return round(min(1.0, base + ratio * (1.0 - base)), 4)
