"""
CTI v5 Classification — ContextualDatasetResolver replaces heuristic infer_adam_datasets.
Per Part E of PDF spec: primary+supplementary dataset distinction, mutual exclusion rules.
"""
from __future__ import annotations
import re
from typing import Dict, List, Optional, Tuple
from src.utils.normalization import (
    POPULATION_NORMALIZATION, POPULATION_FLAG_MAP, POPULATION_DATASET_MAP,
    METHOD_NORMALIZATION, ADAM_DATASET_HINTS, OUTPUT_CLASS_HINTS, DYNAMIC_POP_PATTERNS,
)
from src.utils.text import clean_text, slugify


def normalize_population(text: str) -> Optional[Tuple[str, str, int]]:
    for pattern, result in POPULATION_NORMALIZATION.items():
        if re.search(pattern, text, re.IGNORECASE):
            return result
    return None


def normalize_population_dynamic(text: str) -> Optional[Tuple[str, str, int, str]]:
    for pattern in DYNAMIC_POP_PATTERNS:
        m = re.search(pattern, text, re.IGNORECASE | re.DOTALL)
        if m:
            d = m.groupdict()
            name = clean_text(d.get("n", "")).strip()
            abbrev = clean_text(d.get("abbrev", "")).strip()
            definition = clean_text(d.get("def", "")).strip()
            if not name or len(name) < 3: continue
            if not abbrev:
                abbrev = "".join(w[0].upper() for w in name.split() if w)[:6]
            order = 5
            if any(k in name.lower() for k in ["safety","enrolled","randomized","full","itt","fas"]):
                order = 2
            elif any(k in name.lower() for k in ["pk","pharmacokinetic","dlt"]): order = 3
            return name, abbrev, order, definition
    return None


def normalize_method(text: str) -> Optional[str]:
    for pattern, name in METHOD_NORMALIZATION.items():
        if re.search(pattern, text, re.IGNORECASE):
            return name
    return None


def classify_output(title: str, context: str = "") -> str:
    combined = (title + " " + context).lower()
    for cls, hints in OUTPUT_CLASS_HINTS.items():
        if any(h.lower() in combined for h in hints):
            return cls
    return "Other"


class ContextualDatasetResolver:
    """
    Part E: Replaces heuristic infer_adam_datasets().
    Primary + supplementary distinction. Mutual exclusion rules.
    Eliminates: PK concentration table getting ADAE, ADRS, ADQS.
    """

    # Canonical primary datasets per output class
    _PRIMARY: Dict[str, List[str]] = {
        "Efficacy":        ["ADEFF", "ADRS", "ADTTE"],
        "Safety":          ["ADAE"],
        "PK":              ["ADPC", "ADPP"],
        "PD":              ["ADPC"],
        "Demographics":    ["ADSL"],
        "Disposition":     ["ADSL"],
        "QoL":             ["ADQS"],
        "Biomarker":       ["ADLB"],
        "Laboratory":      ["ADLB"],
        "ECG":             ["ADEG"],
        "Compliance":      ["ADEX"],
        "Subgroup":        ["ADSL"],
        "Immunogenicity":  ["ADIE"],
        "Other":           ["ADSL"],
    }

    # Supplementary always joined via ADSL keys
    _SUPPLEMENTARY = ["ADSL"]

    # Mutual exclusion rules: if pattern matches title, exclude these datasets
    _EXCLUSIONS = [
        (r"\bPK\b|concentration|AUC|Cmax|NCA|pharmacokinetic", ["ADAE","ADQS","ADRS","ADEFF"]),
        (r"\badverse\s+event\b|TEAE|toxicity|SAE",             ["ADPC","ADPP","ADQS","ADRS"]),
        (r"\bdemographic\b|baseline\s+char",                    ["ADAE","ADTTE","ADPC","ADRS"]),
        (r"\bquality\s+of\s+life\b|QoL\b|PRO\b",               ["ADAE","ADPC","ADRS"]),
        (r"\bimmunogenicity\b|antibody\b|ADA\b",                ["ADAE","ADPC","ADLB"]),
        (r"\bECG\b|QTcF\b|electrocardiogram\b",                 ["ADAE","ADPC","ADLB"]),
        (r"\bexposure\b|dose\s+intensity\b|compliance\b",       ["ADAE","ADPC","ADRS"]),
        (r"\bdisposition\b|enrolled\b|withdrawn\b",             ["ADAE","ADPC","ADLB"]),
    ]

    # Endpoint-type based refinement within efficacy
    _EFFICACY_REFINEMENT = [
        (r"\bPFS\b|time.to.progress|progression.free|survival\b|OS\b|DFS\b", ["ADTTE"]),
        (r"\bresponse\b|ORR\b|CR\b|PR\b|RECIST\b",                           ["ADRS"]),
        (r"\bchange\s+from\s+baseline\b|MMRM\b|ANCOVA\b",                    ["ADEFF"]),
        (r"\bscore\b|scale\b|questionnaire\b",                                ["ADEFF"]),
    ]

    @classmethod
    def primary_for_class(cls, output_class: str) -> List[str]:
        return cls._PRIMARY.get(output_class, ["ADSL"])

    def resolve(self, output: "AnalysisOutput",  # type: ignore
                adam_registry: Optional["ADaMSpecRegistry"] = None) -> List[str]:  # type: ignore
        from src.models.schema import AnalysisOutput, ADaMSpecRegistry
        title = (output.title or "").lower()
        oc = output.output_class.value

        candidates = list(self._PRIMARY.get(oc, ["ADSL"]))

        # Apply mutual exclusion
        for excl_pattern, excluded in self._EXCLUSIONS:
            if re.search(excl_pattern, title, re.IGNORECASE):
                candidates = [d for d in candidates if d not in excluded]

        # Refine efficacy to specific dataset
        if oc == "Efficacy":
            for pattern, specific in self._EFFICACY_REFINEMENT:
                if re.search(pattern, title, re.IGNORECASE):
                    candidates = specific
                    break

        if not candidates:
            candidates = ["ADSL"]

        primary = candidates[0]

        # Validate against ADaM registry if available
        if adam_registry and primary not in adam_registry.datasets:
            # Fall back to first known dataset
            for c in candidates:
                if c in adam_registry.datasets:
                    primary = c
                    break

        result = [primary] + [d for d in self._SUPPLEMENTARY if d != primary]
        return list(dict.fromkeys(result))


# Module-level convenience function for backward compatibility
def infer_adam_datasets(title: str, context: str = "") -> List[str]:
    """
    Backward-compatible wrapper. Uses ContextualDatasetResolver for per-class logic,
    falls back to ADAM_DATASET_HINTS for generic cases.
    """
    combined = (title + " " + context).lower()
    # Use hint-based approach as fallback (no output object available)
    datasets: List[str] = []
    for ds, hints in ADAM_DATASET_HINTS.items():
        if any(h.lower() in combined for h in hints):
            datasets.append(ds)

    # Apply exclusion rules on title
    resolver = ContextualDatasetResolver()
    for excl_pattern, excluded in resolver._EXCLUSIONS:
        if re.search(excl_pattern, title, re.IGNORECASE):
            datasets = [d for d in datasets if d not in excluded]

    if not datasets:
        datasets.append("ADSL")
    return list(dict.fromkeys(datasets))
