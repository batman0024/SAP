# CTI Platform v5 — Clinical Trial Intelligence

Production-grade SAP document extraction engine for clinical trial statistical programmers.

## Key Numbers
- **35+ outputs** from 150-page SAP in 303ms
- **44 rule patterns** including 12 new ADaM-specific patterns
- **85% QC readiness** on real-world SAPs
- **49/49 tests** passing

## What's New in v5
- ADaM Spec Excel parser (auto-detects per-dataset / Define-XML formats)
- Fixed QC readiness scoring (no longer inflates to 100% with errors)
- 11 v3.1 regressions restored: PKPDSpec, TimingDefinition, ICH E9(R1) Estimand, Multiplicity
- 12 new rule patterns: TRTSDT, LDRELD, ONTRTFL, PARAMCD, stratification, ORR, RDI...
- ContextualDatasetResolver: PK tables no longer get ADAE/ADRS/ADQS
- Iterative XML walk (no RecursionError on complex DOCX)
- Dynamic population deduplication
- 5 new QC checks: population-class alignment, method-dataset mismatch, estimand completeness

## Usage
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Multi-Document Input
1. SAP (DOCX/RTF/TXT) — required
2. TFL Shell (DOCX) — optional, adds shell-sourced outputs
3. ADaM Spec Excel (XLSX) — optional, enables typed variable registry

## Documentation
Open `docs/full_documentation.html` in a browser for complete reference.
