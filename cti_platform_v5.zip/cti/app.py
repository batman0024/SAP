"""
CTI Platform v4 — Streamlit Dashboard
Multi-document upload: SAP + TFL Shell + ADaM Excel
HTML & Excel download
Tracked-change stripping
Dynamic population extraction
Real-world SAP accuracy improvements
"""
from __future__ import annotations
import hashlib, json, sys, tempfile, time
from pathlib import Path
from typing import List, Optional

import streamlit as st

sys.path.insert(0, str(Path(__file__).parent))

from src.models.schema import ClinicalIntelligenceSchema, OutputType, QCSeverity
from src.services import ExtractionPipeline, PipelineConfig
from src.export import ExportManager

st.set_page_config(page_title="CTI Platform v4", page_icon="⬡",
                   layout="wide", initial_sidebar_state="expanded")

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600&family=IBM+Plex+Sans:wght@300;400;600;700&display=swap');
html,body,[class*="css"]{font-family:'IBM Plex Sans',sans-serif;}
.stApp{background:#0a0e1a;color:#e2e8f0;}
.main .block-container{padding:1.5rem 2rem;max-width:1400px;}
[data-testid="stSidebar"]{background:#0f172a;border-right:1px solid #1e293b;}
[data-testid="stMetricValue"]{color:#06b6d4;font-family:'IBM Plex Mono',monospace;font-size:1.8rem;}
[data-testid="stMetricLabel"]{color:#64748b;font-size:.7rem;text-transform:uppercase;letter-spacing:.05em;}
[data-testid="stMetric"]{background:#0f172a;border:1px solid #1e293b;border-radius:10px;padding:.8rem;}
.stTabs [data-baseweb="tab-list"]{background:#0f172a;border-bottom:1px solid #1e293b;}
.stTabs [data-baseweb="tab"]{color:#64748b;padding:.65rem 1.1rem;font-size:.82rem;}
.stTabs [aria-selected="true"]{color:#06b6d4;border-bottom:2px solid #06b6d4;}
.streamlit-expanderHeader{background:#0f172a;border:1px solid #1e293b;border-radius:8px;color:#e2e8f0;}
.stProgress>div>div{background:linear-gradient(90deg,#06b6d4,#6366f1);}
[data-testid="stFileUploaderDropzone"]{background:#0f172a;border:2px dashed #334155;border-radius:10px;}
.stButton>button{background:linear-gradient(135deg,#06b6d4,#6366f1);color:#fff;border:none;border-radius:8px;font-weight:600;padding:.5rem 1.2rem;}
.badge-e{background:#ef444422;color:#ef4444;border:1px solid #ef444433;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600;}
.badge-w{background:#f59e0b22;color:#f59e0b;border:1px solid #f59e0b33;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600;}
.badge-i{background:#06b6d422;color:#06b6d4;border:1px solid #06b6d433;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600;}
.badge-ok{background:#10b98122;color:#10b981;border:1px solid #10b98133;padding:2px 8px;border-radius:4px;font-size:11px;font-weight:600;}
.sec-hdr{font-family:'IBM Plex Mono',monospace;font-size:.65rem;font-weight:600;color:#475569;
         text-transform:uppercase;letter-spacing:.1em;margin-bottom:.4rem;
         border-bottom:1px solid #1e293b;padding-bottom:3px;}
.tracked-ok{background:rgba(16,185,129,.08);border:1px solid rgba(16,185,129,.3);
            border-radius:6px;padding:.4rem .8rem;font-size:12px;color:#6ee7b7;margin-bottom:.75rem;}
.annotation-tag{background:#1e1b4b;color:#a5b4fc;border:1px solid #4338ca33;
                padding:2px 7px;border-radius:3px;font-family:monospace;font-size:10px;margin:1px;}
</style>
""", unsafe_allow_html=True)

# ── Session state ─────────────────────────────────────────────────────────────
for k,v in {"schema":None,"error":None,"file_hash":None,"html_report":None}.items():
    if k not in st.session_state: st.session_state[k] = v

def _fhash(*files) -> str:
    h = hashlib.md5()
    for f in files:
        if f: h.update(f.getvalue()[:8192])
    return h.hexdigest()[:12]

def _conf_badge(s: float) -> str:
    if s>=.88: return f'<span class="badge-ok">✓ {s:.0%}</span>'
    elif s>=.70: return f'<span class="badge-i">~ {s:.0%}</span>'
    elif s>=.55: return f'<span class="badge-w">! {s:.0%}</span>'
    return f'<span class="badge-e">✗ {s:.0%}</span>'

def _rc(score: float) -> str:
    return "#10b981" if score>=.80 else "#f59e0b" if score>=.60 else "#ef4444"

# ── Sidebar ───────────────────────────────────────────────────────────────────
def _sidebar():
    with st.sidebar:
        st.markdown("""
        <div style="padding:.8rem 0 .3rem;">
          <div style="font-weight:700;font-size:14px;color:#f1f5f9;">⬡ CTI Platform v4</div>
          <div style="font-size:10px;color:#475569;">SAP Intelligence · Multi-Document</div>
        </div>""", unsafe_allow_html=True)
        st.divider()

        st.markdown('<div class="sec-hdr">Primary SAP Document</div>', unsafe_allow_html=True)
        sap_file = st.file_uploader("SAP (DOCX/RTF/TXT)", type=["docx","rtf","txt"],
                                    key="sap_up", label_visibility="collapsed",
                                    help="Main SAP document — required")

        st.markdown('<div class="sec-hdr" style="margin-top:.8rem;">Optional Documents</div>',
                    unsafe_allow_html=True)
        c1,c2 = st.columns(2)
        with c1:
            shell_file = st.file_uploader("TFL Shell (DOCX)",type=["docx","rtf"],
                                          key="shell_up", label_visibility="collapsed",
                                          help="TFL shell document")
        with c2:
            adam_file = st.file_uploader("ADaM Excel",type=["xlsx","xls"],
                                         key="adam_up", label_visibility="collapsed",
                                         help="ADaM variable spec Excel")

        st.markdown('<div class="sec-hdr" style="margin-top:.8rem;">Pipeline Options</div>',
                    unsafe_allow_html=True)
        run_qc     = st.checkbox("Run QC Engine", True)
        run_shell  = st.checkbox("Parse Mock Shells", True)
        parallel   = st.checkbox("Parallel Extraction", True)
        conf       = st.slider("Confidence Threshold", 0.50, 0.95, 0.65, 0.05, format="%.2f")

        st.markdown('<div class="sec-hdr" style="margin-top:.8rem;">Export Options</div>',
                    unsafe_allow_html=True)
        exp_json  = st.checkbox("Export JSON",  False)
        exp_xl    = st.checkbox("Export Excel", False)
        exp_html  = st.checkbox("Export HTML",  False)
        exp_sas   = st.checkbox("Export SAS",   False)

        st.markdown("")
        run_btn  = st.button("⬡ Run Extraction", use_container_width=True,
                             disabled=not bool(sap_file))
        demo_btn = st.button("⚡ Demo SAP",       use_container_width=True)

        schema = st.session_state.get("schema")
        if schema:
            meta = schema.get("study_metadata",{})
            qc   = schema.get("qc_report",{}) or {}
            rs   = qc.get("overall_readiness_score", 0)
            color = _rc(rs)
            st.divider()
            st.markdown(f"""
            <div style="font-size:11px;color:#94a3b8;line-height:2;">
              <b style="color:#f1f5f9;">{meta.get('protocol_id','N/A')}</b><br>
              Phase {meta.get('phase','?')} &nbsp;·&nbsp; v{meta.get('sap_version','?')}<br>
              {len(schema.get('outputs_master',[]))} outputs &nbsp;·&nbsp;
              {len(schema.get('populations',[]))} pops<br>
              {len(schema.get('endpoints',[]))} endpoints &nbsp;·&nbsp;
              {len(schema.get('rule_engine_output',[]))} rules
            </div>
            <div style="margin-top:.5rem;padding:7px 10px;background:#0a0e1a;
                        border:1px solid #1e293b;border-left:3px solid {color};border-radius:0 5px 5px 0;">
              <div style="font-size:9px;color:#64748b;text-transform:uppercase;">Readiness</div>
              <div style="font-size:1.5rem;font-family:'IBM Plex Mono',monospace;color:{color};font-weight:700;">
                {rs:.0%}</div>
            </div>""", unsafe_allow_html=True)

            st.divider()
            st.markdown('<div class="sec-hdr">Downloads</div>', unsafe_allow_html=True)
            st.download_button("⬇ JSON",
                data=json.dumps(schema, indent=2, default=str),
                file_name=f"cti_{meta.get('protocol_id','schema')}.json",
                mime="application/json", use_container_width=True)

            html_rpt = st.session_state.get("html_report")
            if html_rpt:
                st.download_button("⬇ HTML Report", data=html_rpt,
                    file_name=f"cti_report_{meta.get('protocol_id','report')}.html",
                    mime="text/html", use_container_width=True)

        return (sap_file, shell_file, adam_file, run_btn, demo_btn,
                run_qc, run_shell, parallel, conf,
                exp_json, exp_xl, exp_html, exp_sas)


# ── Pipeline runners ──────────────────────────────────────────────────────────
def _run(sap_file, shell_file, adam_file, conf, run_qc, run_shell, parallel,
         exp_json, exp_xl, exp_html, exp_sas):
    key = _fhash(sap_file, shell_file, adam_file)
    if st.session_state.get("file_hash") == key and st.session_state.get("schema"):
        st.info("Cached result. Re-upload files to re-extract.")
        return

    progress = st.progress(0.0, text="Starting…")
    status = st.empty()
    def cb(msg, pct):
        progress.progress(min(pct, 1.0), text=msg)
        status.markdown(f"<div style='font-size:11px;color:#64748b;'>{msg}</div>", unsafe_allow_html=True)

    try:
        with tempfile.TemporaryDirectory() as tmp:
            paths = []
            for uf, label in [(sap_file,"sap"),(shell_file,"shell"),(adam_file,"adam")]:
                if uf:
                    p = Path(tmp) / uf.name
                    p.write_bytes(uf.getvalue())
                    paths.append(p)

            config = PipelineConfig(
                confidence_threshold=conf, run_qc=run_qc,
                run_mock_shell=run_shell, parallel_extraction=parallel,
                export_json=exp_json, export_excel=exp_xl,
                export_html=exp_html, export_sas=exp_sas,
                output_dir=Path(tmp)/"exports",
                progress_callback=cb,
            )
            pipeline = ExtractionPipeline(config)
            schema_obj = pipeline.run(paths)
            schema_dict = json.loads(schema_obj.model_dump_json())

            # Generate HTML report in memory
            import tempfile as tf2
            with tf2.TemporaryDirectory() as tmp2:
                em = ExportManager(Path(tmp2))
                html_path = em.export_html_report(schema_obj)
                html_content = html_path.read_text(encoding="utf-8")

        st.session_state["schema"] = schema_dict
        st.session_state["file_hash"] = key
        st.session_state["html_report"] = html_content
        st.session_state["error"] = None
        progress.progress(1.0, text="Complete ✓")
        status.empty()
    except Exception as exc:
        import traceback
        st.session_state["error"] = f"{exc}\n{traceback.format_exc()[-400:]}"
        progress.empty(); status.empty()


def _run_demo():
    from tests.fixtures.mock_saps.generate_fixtures import _sap1_text
    sap_text = _sap1_text() if hasattr(
        __import__('tests.fixtures.mock_saps.generate_fixtures',fromlist=['_sap1_text']),
        '_sap1_text') else None
    sap = Path('tests/fixtures/mock_saps/sap_large_150page.docx')
    if not sap.exists():
        sap = list(Path('tests/fixtures/mock_saps').glob('*.docx'))
        sap = sap[0] if sap else None
    if not sap:
        st.error("No demo fixture found. Upload a SAP document.")
        return
    config = PipelineConfig(run_qc=True, run_mock_shell=True, parallel_extraction=True)
    schema_obj = ExtractionPipeline(config).run([sap])
    schema_dict = json.loads(schema_obj.model_dump_json())
    with tempfile.TemporaryDirectory() as tmp:
        em = ExportManager(Path(tmp))
        html_path = em.export_html_report(schema_obj)
        html_content = html_path.read_text(encoding="utf-8")
    st.session_state["schema"] = schema_dict
    st.session_state["html_report"] = html_content
    st.session_state["file_hash"] = "demo"
    st.session_state["error"] = None


# ── Render ────────────────────────────────────────────────────────────────────
def _header(schema):
    if schema:
        meta = schema.get("study_metadata",{})
        sys_ms = schema.get("execution_time_ms", 0)
        tracked = schema.get("tracked_changes_stripped", False)
        annots  = schema.get("inline_annotations_count", 0)
        sap_ver = meta.get("sap_version","")
        amend   = meta.get("amendment_number","")
        st.markdown(f"""
        <div style="background:linear-gradient(135deg,#0f172a,#1e1b4b);border:1px solid #1e293b;
                    border-radius:12px;padding:1.1rem 1.5rem;margin-bottom:1.2rem;">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;">
            <div>
              <div style="font-size:1rem;font-weight:700;color:#f1f5f9;margin-bottom:3px;">
                {meta.get('study_title','Clinical Trial SAP Analysis')[:100]}
              </div>
              <div style="font-size:11px;color:#64748b;">
                Protocol: <span style="color:#94a3b8;">{meta.get('protocol_id','N/A')}</span>
                &nbsp;·&nbsp; Phase: <span style="color:#94a3b8;">{meta.get('phase','?')}</span>
                {f"&nbsp;·&nbsp; SAP v<span style='color:#94a3b8;'>{sap_ver}</span>" if sap_ver else ""}
                {f"&nbsp;·&nbsp; Amend: <span style='color:#94a3b8;'>{amend}</span>" if amend else ""}
                &nbsp;·&nbsp; NCT: <span style="color:#94a3b8;">{meta.get('nct_number','N/A')}</span>
              </div>
            </div>
            <div style="text-align:right;font-size:10px;color:#475569;">
              {f"Extracted in {sys_ms:,} ms" if sys_ms else ""}
            </div>
          </div>
          {"<div class='tracked-ok' style='margin-top:.6rem;'>✓ Tracked changes (strikethrough deleted text) stripped from extraction</div>" if tracked else ""}
          {f"<div style='margin-top:.4rem;font-size:11px;color:#a5b4fc;'>📎 {annots} inline ADaM variable annotations extracted</div>" if annots else ""}
        </div>""", unsafe_allow_html=True)
    else:
        st.markdown("""
        <div style="background:linear-gradient(135deg,#0f172a,#1e1b4b);border:1px solid #1e293b;
                    border-radius:12px;padding:2rem;text-align:center;margin-bottom:1.2rem;">
          <div style="font-size:2rem;margin-bottom:.4rem;">⬡</div>
          <div style="font-size:1.2rem;font-weight:700;color:#f1f5f9;margin-bottom:.4rem;">
            Clinical Trial Intelligence Platform v4</div>
          <div style="font-size:12px;color:#64748b;max-width:550px;margin:0 auto;">
            Upload a SAP document. Supports DOCX/RTF/TXT + optional TFL Shell + ADaM Excel.
            Extracts endpoints from structured tables, dynamic populations, tracks changes,
            inline ADaM annotations, SAP versioning. Target readiness &gt;90%.
          </div>
        </div>""", unsafe_allow_html=True)


def _metrics(schema):
    qc = schema.get("qc_report") or {}
    cols = st.columns(9)
    vals = [
        ("Outputs",     len(schema.get("outputs_master",[]))),
        ("Populations", len(schema.get("populations",[]))),
        ("Endpoints",   len(schema.get("endpoints",[]))),
        ("Rules",       len(schema.get("rule_engine_output",[]))),
        ("Visits",      len(schema.get("visit_schedule",[]))),
        ("Sections",    len(schema.get("sections",[]))),
        ("ADaM Annots", schema.get("inline_annotations_count",0)),
        ("QC Errors",   qc.get("errors",0)),
        ("Readiness",   f"{qc.get('overall_readiness_score',0):.0%}"),
    ]
    for col,(lbl,val) in zip(cols,vals):
        with col: st.metric(lbl,val)


def _tab_outputs(schema):
    import pandas as pd
    outs = schema.get("outputs_master",[])
    c1,c2,c3 = st.columns([2,2,2])
    with c1:
        type_f = st.multiselect("Type",["Table","Listing","Figure"],
                                default=["Table","Listing","Figure"],key="tf")
    with c2:
        pops_avail = sorted({(o.get("population") or {}).get("abbreviation","?")
                             for o in outs if o.get("population")})
        pop_f = st.multiselect("Population", pops_avail, default=pops_avail, key="pf")
    with c3:
        conf_f = st.slider("Min Conf", 0.0, 1.0, 0.0, 0.05, key="cf")
    filtered = [o for o in outs
                if o.get("output_type","Table") in type_f
                and (not pops_avail or (o.get("population") or {}).get("abbreviation","?") in pop_f)
                and o.get("confidence_score",0) >= conf_f]
    st.caption(f"Showing {len(filtered)}/{len(outs)} outputs")
    for o in filtered:
        pop = (o.get("population") or {}).get("abbreviation","?")
        ds  = ", ".join((o.get("data_specification") or {}).get("input_datasets",[]))[:60]
        mth = ", ".join((o.get("analysis") or {}).get("methods",[]))[:50] or "—"
        icon = {"Table":"▦","Listing":"≡","Figure":"◈"}.get(o.get("output_type","Table"),"▦")
        anns = (o.get("data_specification") or {}).get("adam_annotations",[])[:3]
        ann_html = " ".join(f'<span class="annotation-tag">{a}</span>' for a in anns)
        shell_flag = " 🔗" if o.get("from_shell_doc") else ""
        with st.expander(f"{icon} {o.get('output_number','?')} — {(o.get('title') or '')[:75]}{shell_flag}"):
            ca,cb,cc = st.columns([3,2,1])
            with ca:
                st.markdown(f"""
                <div style="font-size:11px;line-height:2.2;">
                  <b style="color:#94a3b8;">Type:</b> {o.get('output_type')} · {o.get('output_class')}<br>
                  <b style="color:#94a3b8;">Population:</b> {pop}<br>
                  <b style="color:#94a3b8;">Methods:</b> {mth}<br>
                  <b style="color:#94a3b8;">Datasets:</b> {ds or '—'}<br>
                  {f"<b style='color:#94a3b8;'>ADaM:</b> {ann_html}" if ann_html else ""}
                </div>""", unsafe_allow_html=True)
            with cb:
                rules = o.get("programming_rules",[])[:4]
                if rules:
                    st.markdown('<div style="font-size:10px;color:#64748b;margin-bottom:3px;">Programming Rules</div>',
                                unsafe_allow_html=True)
                    for r in rules:
                        st.markdown(f"""
                        <div style="font-family:'IBM Plex Mono',monospace;font-size:10px;
                                    background:#0a0e1a;padding:3px 7px;border-radius:4px;
                                    border-left:2px solid #f97316;margin-bottom:2px;color:#94a3b8;">
                          {r.get('rule','')}
                        </div>""", unsafe_allow_html=True)
            with cc:
                st.markdown(_conf_badge(o.get("confidence_score",0)), unsafe_allow_html=True)
                if o.get("from_shell_doc"):
                    st.markdown('<span style="font-size:9px;color:#6ee7b7;">From Shell</span>',
                                unsafe_allow_html=True)

def _tab_populations(schema):
    pops = schema.get("populations",[])
    st.caption(f"{sum(1 for p in pops if not p.get('is_dynamic'))} fixed + {sum(1 for p in pops if p.get('is_dynamic'))} dynamic populations")
    for pop in pops:
        dyn_badge = ' <span style="background:#8b5cf615;color:#c4b5fd;border:1px solid #8b5cf633;padding:1px 5px;border-radius:3px;font-size:9px;">DYNAMIC</span>' if pop.get('is_dynamic') else ''
        with st.expander(f"👥 {pop.get('abbreviation')} — {pop.get('label')}{dyn_badge.replace('<','<').replace('>','>')}"):
            ca,cb = st.columns([3,1])
            with ca:
                st.markdown(f"""
                <div style="font-size:11px;line-height:2.2;">
                  <b style="color:#94a3b8;">ADaM Flag:</b>
                  <code style="background:#0a0e1a;padding:2px 6px;border-radius:3px;color:#06b6d4;">
                    {pop.get('adam_flag_variable','N/A')} = 'Y'
                  </code><br>
                  <b style="color:#94a3b8;">Dataset:</b> {pop.get('adam_dataset','ADSL')}<br>
                  <b style="color:#94a3b8;">Derivation:</b>
                  <code style="background:#0a0e1a;padding:2px 5px;border-radius:3px;color:#10b981;font-size:10px;">
                    {pop.get('derivation_rule','N/A')}
                  </code>
                </div>""", unsafe_allow_html=True)
                if pop.get('formal_definition'):
                    st.markdown(f"""
                    <div style="background:#0a0e1a;border-left:3px solid #ec4899;
                                border-radius:0 5px 5px 0;padding:6px 10px;margin-top:6px;
                                font-size:10px;color:#94a3b8;font-style:italic;">
                      {pop['formal_definition'][:200]}</div>""", unsafe_allow_html=True)
            with cb:
                st.markdown(_conf_badge(pop.get('confidence',0)), unsafe_allow_html=True)
                if pop.get('is_dynamic'):
                    st.markdown('<span style="font-size:9px;color:#c4b5fd;">Dynamically extracted</span>',
                                unsafe_allow_html=True)

def _tab_endpoints(schema):
    eps = schema.get("endpoints",[])
    if not eps:
        st.warning("No endpoints extracted. Check that SAP contains objective/endpoint section or table (Primary Objectives | Primary Endpoints).")
        return
    from_tbl = sum(1 for e in eps if e.get("from_table"))
    st.caption(f"{from_tbl} from structured tables (high accuracy), {len(eps)-from_tbl} from prose")
    cls_colors = {"Primary":"#ec4899","Key Secondary":"#f97316","Secondary":"#06b6d4",
                  "Exploratory":"#8b5cf6","Safety":"#ef4444","PK":"#f59e0b","PD":"#10b981"}
    for ep in eps:
        cls  = ep.get("classification","Secondary")
        color= cls_colors.get(cls,"#94a3b8")
        src  = "📊 Table" if ep.get("from_table") else "📄 Prose"
        with st.expander(f"🎯 [{cls}] {src} | {ep.get('description','')[:80]}"):
            ca,cb = st.columns([3,1])
            with ca:
                st.markdown(f"""
                <div style="font-size:11px;line-height:2.2;color:#94a3b8;">
                  <b>Description:</b> {ep.get('description','')}
                </div>""", unsafe_allow_html=True)
                if ep.get("timepoints"):
                    st.markdown(f'<div style="font-size:10px;color:#6ee7b7;margin-top:4px;">⏱ {", ".join(ep["timepoints"][:4])}</div>',
                                unsafe_allow_html=True)
            with cb:
                st.markdown(_conf_badge(ep.get("confidence",0)), unsafe_allow_html=True)

def _tab_rules(schema):
    rules = schema.get("rule_engine_output",[])
    if not rules:
        st.warning("No programming rules extracted.")
        return
    rt_all = sorted({r.get("rule_type","") for r in rules})
    sel = st.multiselect("Filter by Type", rt_all, default=rt_all, key="rt_sel")
    filtered = [r for r in rules if r.get("rule_type","") in sel]
    st.caption(f"{len(filtered)} rules")
    colors = {"baseline_definition":"#8b5cf6","date_imputation":"#f97316",
              "censoring":"#ef4444","filter":"#06b6d4","derivation":"#10b981",
              "flag":"#6366f1","LOCF":"#ec4899","BOCF":"#f59e0b",
              "inline_annotation":"#a5b4fc","study_day":"#94a3b8","pk_rule":"#fbbf24"}
    for r in filtered:
        rt = r.get("rule_type","")
        color = colors.get(rt,"#94a3b8")
        snippet = r.get("rule_text_verbatim","")[:65]
        with st.expander(f"[{rt}] {snippet}…"):
            ca,cb = st.columns([3,1])
            with ca:
                st.markdown(f'<div style="font-size:11px;color:#94a3b8;font-style:italic;">{r.get("rule_text_verbatim","")}</div>',
                            unsafe_allow_html=True)
                if r.get("pseudocode"):
                    st.code(r["pseudocode"], language="sas")
                vars_s = ", ".join(r.get("applies_to_variables",[])[:6]) or "N/A"
                ds_s   = ", ".join(r.get("applies_to_datasets",[])[:5]) or "N/A"
                st.markdown(f'<div style="font-size:10px;color:#64748b;margin-top:6px;">Variables: <span style="color:{color};">{vars_s}</span> · Datasets: {ds_s}</div>',
                            unsafe_allow_html=True)
            with cb:
                st.markdown(_conf_badge(r.get("confidence",0)), unsafe_allow_html=True)

def _tab_visits(schema):
    import pandas as pd
    visits = schema.get("visit_schedule",[])
    if not visits:
        st.info("No visit schedule extracted.")
        return
    rows = [{"Label":v.get("visit_label",""), "Type":v.get("visit_type",""),
             "Nominal":v.get("nominal_day","—"),
             "Window":f"-{v['window_pre_days']}/+{v['window_post_days']}" if v.get('window_pre_days') else "—",
             "AVISIT":v.get("adam_visit_value",""),"AVISITN":v.get("adam_visitnum",""),
             "Analysis":"✓" if v.get("analysis_visit_flag") else "",
             "Primary":"⭐" if v.get("primary_timepoint") else "",
             "Conf":f"{v.get('confidence',0):.2f}"}
            for v in visits]
    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)

def _tab_qc(schema):
    qc = schema.get("qc_report")
    if not qc:
        st.warning("QC not run.")
        return
    rs = qc.get("overall_readiness_score",0)
    color = _rc(rs)
    c1,c2,c3,c4,c5,c6 = st.columns(6)
    with c1:
        st.markdown(f"""
        <div style="background:#0f172a;border:2px solid {color};border-radius:8px;
                    padding:10px;text-align:center;">
          <div style="font-size:1.6rem;font-family:'IBM Plex Mono',monospace;color:{color};font-weight:700;">
            {rs:.0%}</div>
          <div style="font-size:9px;color:#64748b;text-transform:uppercase;">Readiness</div>
        </div>""", unsafe_allow_html=True)
    for col,val,lbl in [
        (c2,qc.get("completeness_pct",0),"Completeness"),
        (c3,qc.get("errors",0),"Errors"),
        (c4,qc.get("warnings",0),"Warnings"),
        (c5,qc.get("infos",0),"Info"),
        (c6,qc.get("low_confidence_count",0),"Low Conf"),
    ]:
        with col: st.metric(lbl, f"{val:.0f}" if isinstance(val,float) else val)
    st.markdown("")
    issues = qc.get("issues",[])
    sev_map = {"ERROR":"badge-e","WARNING":"badge-w","INFO":"badge-i"}
    sev_f = st.multiselect("Severity",["ERROR","WARNING","INFO"],default=["ERROR","WARNING"],key="qc_sev")
    shown = [i for i in issues if i.get("severity","") in sev_f]
    for i in shown:
        sev = i.get("severity","INFO")
        bd  = sev_map.get(sev,"badge-i")
        st.markdown(f"""
        <div style="background:#0f172a;border:1px solid #1e293b;border-radius:6px;
                    padding:.5rem .75rem;margin-bottom:.4rem;font-size:11px;">
          <span class="{bd}">{sev}</span>
          <span style="color:#64748b;margin-left:.5rem;font-size:10px;">{i.get('category','')}</span>
          <span style="color:#cbd5e1;margin-left:.75rem;">{i.get('message','')}</span>
          {f"<div style='font-size:10px;color:#475569;margin-top:2px;'>Fix: {i.get('suggested_fix','')}</div>" if i.get('suggested_fix') else ""}
        </div>""", unsafe_allow_html=True)
    if not shown:
        st.success("✓ No issues at selected severity level.")

def _tab_adam(schema):
    from collections import defaultdict
    ds_map = defaultdict(lambda: {"outputs":[],"pops":set()})
    for o in schema.get("outputs_master",[]):
        ds_spec = o.get("data_specification") or {}
        pop_abbr = (o.get("population") or {}).get("abbreviation","")
        for ds in (ds_spec.get("input_datasets") or []):
            ds_map[ds]["outputs"].append(o.get("output_number","?"))
            if pop_abbr: ds_map[ds]["pops"].add(pop_abbr)

    icons = {"ADSL":"👤","ADAE":"⚠","ADLB":"🧪","ADEFF":"🎯","ADTTE":"⏱",
             "ADPK":"💊","ADVS":"❤","ADQS":"📋","ADCM":"💉","ADEX":"📊",
             "ADPC":"🔬","ADPP":"📈","ADRS":"🏥","ADIE":"🔬","ADEG":"❤"}

    pops = schema.get("populations",[])
    st.markdown(f"**{len(ds_map)} ADaM datasets** referenced across {len(schema.get('outputs_master',[]))} outputs")

    for ds_name, info in sorted(ds_map.items()):
        icon = icons.get(ds_name,"🗃")
        with st.expander(f"{icon} **{ds_name}** — {len(info['outputs'])} outputs"):
            ca,cb = st.columns([2,1])
            with ca:
                if info["outputs"]:
                    nums = sorted(info["outputs"])[:15]
                    html = " ".join(f'<code style="font-size:10px;background:#1e293b;padding:1px 4px;border-radius:3px;">{n}</code>' for n in nums)
                    st.markdown(f'<div style="font-size:11px;margin-bottom:.3rem;">Outputs: {html}</div>', unsafe_allow_html=True)
            with cb:
                if info["pops"]:
                    st.markdown(f'<div style="font-size:11px;color:#94a3b8;">Populations: {", ".join(sorted(info["pops"]))}</div>',
                                unsafe_allow_html=True)

def _tab_structure(schema):
    import pandas as pd
    secs = schema.get("sections",[])
    st.caption(f"{len([s for s in secs if not s.get('is_appendix')])} main sections · {len([s for s in secs if s.get('is_appendix')])} appendix sections")
    df = pd.DataFrame([{"ID":s.get("section_id",""),"Lv":s.get("level",0),
                         "Title":s.get("title","")[:85],"Page":s.get("page_start",""),
                         "App":"✓ "+s.get("appendix_label","") if s.get("is_appendix") else "",
                         "Annotations":len(s.get("adam_annotations",[]))}
                        for s in secs])
    st.dataframe(df, use_container_width=True, hide_index=True, height=450)

    cr = schema.get("cross_refs",{})
    if cr:
        with st.expander(f"Cross-References ({len(cr)})"):
            st.dataframe(pd.DataFrame([{"Number":k,"Section":v} for k,v in list(cr.items())[:40]]),
                         use_container_width=True, hide_index=True)


# ── Main ──────────────────────────────────────────────────────────────────────
def main():
    (sap_file, shell_file, adam_file, run_btn, demo_btn,
     run_qc, run_shell, parallel, conf,
     exp_json, exp_xl, exp_html, exp_sas) = _sidebar()

    if run_btn and sap_file:
        _run(sap_file, shell_file, adam_file, conf, run_qc, run_shell, parallel,
             exp_json, exp_xl, exp_html, exp_sas)
        st.rerun()

    if demo_btn:
        with st.spinner("Running demo pipeline…"):
            try: _run_demo()
            except Exception as exc:
                import traceback
                st.session_state["error"] = f"{exc}\n{traceback.format_exc()[-400:]}"
        st.rerun()

    if st.session_state.get("error"):
        st.error(f"Pipeline error:\n{st.session_state['error']}")

    schema = st.session_state.get("schema")
    _header(schema)

    if schema is None:
        features = [
            ("📄","150-Page SAP","O(n) parsing, XML streaming, parallel extraction. Handles 277-page shell docs."),
            ("✂️","Tracked Changes","Strikethrough red text (w:del) stripped. Only final text extracted."),
            ("📊","Table Endpoints","Primary/Secondary objective-endpoint 2-col tables parsed directly."),
            ("🔗","Multi-Document","SAP + TFL Shell + ADaM Excel combined for higher accuracy."),
            ("🏷️","Dynamic Populations","DLT, All Enrolled, Immunogenicity — no fixed list assumption."),
            ("📎","ADaM Annotations","Inline ADSL.SAFFL='Y' green-text annotations extracted as rules."),
            ("📋","SAP Versioning","Version 0.1, Amendment 2 extracted from document header."),
            ("🗂️","Table Rules","Censoring rule tables (Table 5-1 style) parsed row-by-row."),
            ("⬇️","HTML Export","Interactive dark-theme HTML report downloadable from sidebar."),
            ("✓","QC Engine","40+ checks targeting >90% readiness on real-world SAPs."),
        ]
        cols = st.columns(5)
        for i,(icon,title,desc) in enumerate(features):
            with cols[i%5]:
                st.markdown(f"""
                <div style="background:#0f172a;border:1px solid #1e293b;border-radius:10px;
                            padding:1rem;margin-bottom:.75rem;min-height:120px;">
                  <div style="font-size:1.3rem;margin-bottom:.3rem;">{icon}</div>
                  <div style="font-size:11px;font-weight:700;color:#f1f5f9;margin-bottom:.2rem;">{title}</div>
                  <div style="font-size:10px;color:#64748b;">{desc}</div>
                </div>""", unsafe_allow_html=True)
        return

    _metrics(schema)
    st.markdown("")

    tabs = st.tabs(["📊 Outputs","📑 Structure & TOC","👥 Populations",
                    "🎯 Endpoints","⚡ Rules","📅 Visits","✓ QC Report","🗃 ADaM Spec"])
    with tabs[0]: _tab_outputs(schema)
    with tabs[1]: _tab_structure(schema)
    with tabs[2]: _tab_populations(schema)
    with tabs[3]: _tab_endpoints(schema)
    with tabs[4]: _tab_rules(schema)
    with tabs[5]: _tab_visits(schema)
    with tabs[6]: _tab_qc(schema)
    with tabs[7]: _tab_adam(schema)


if __name__ == "__main__":
    main()
